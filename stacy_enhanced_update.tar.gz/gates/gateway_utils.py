"""
Gateway Utilities - Unified interface for all gateway improvements
Integrates stealth, circuit breaker, response parsing, and connection pooling
"""

import time
import random
from typing import Tuple, Optional, Dict, Any, Callable
from functools import wraps

from gates.stealth import (
    StealthSession, 
    get_random_headers, 
    random_delay,
    get_stripe_headers,
    get_braintree_headers,
    get_paypal_headers,
)
from gates.circuit_breaker import (
    is_gateway_available,
    record_gateway_success,
    record_gateway_failure,
    get_gateway_status_report,
    with_circuit_breaker,
)
from gates.response_parser import (
    ParsedResponse,
    CardStatus,
    parse_stripe_response,
    parse_paypal_response,
    parse_braintree_response,
    parse_generic_response,
    auto_parse_response,
)
from gates.retry import RetryConfig, retry_with_backoff


# Token/key cache with TTL
_token_cache: Dict[str, Tuple[Any, float]] = {}
_cache_ttl = 300  # 5 minutes default


def cache_token(key: str, value: Any, ttl: Optional[float] = None) -> None:
    """Cache a token or key with expiration"""
    _token_cache[key] = (value, time.time() + (ttl or _cache_ttl))


def get_cached_token(key: str) -> Optional[Any]:
    """Get a cached token if not expired"""
    if key in _token_cache:
        value, expires = _token_cache[key]
        if time.time() < expires:
            return value
        del _token_cache[key]
    return None


def clear_token_cache() -> None:
    """Clear all cached tokens"""
    _token_cache.clear()


class GatewaySession:
    """
    Enhanced session for gateway requests with integrated stealth and tracking.
    """
    
    def __init__(self, gateway_name: str, proxy: Optional[str] = None):
        self.gateway_name = gateway_name
        self.proxy = proxy
        self.stealth = StealthSession()
        self.request_count = 0
        self.success_count = 0
        self.failure_count = 0
        self.last_error: Optional[str] = None
        
        # Import requests here to avoid circular imports
        import requests
        self.session = requests.Session()
        self.session.verify = False
        
        if proxy:
            self._setup_proxy(proxy)
    
    def _setup_proxy(self, proxy: str) -> None:
        """Configure proxy from various formats"""
        if "://" in proxy:
            self.session.proxies = {"http": proxy, "https": proxy}
        elif proxy.count(":") == 3:
            # host:port:user:pass format
            parts = proxy.split(":")
            proxy_url = f"http://{parts[2]}:{parts[3]}@{parts[0]}:{parts[1]}"
            self.session.proxies = {"http": proxy_url, "https": proxy_url}
        else:
            # host:port format
            self.session.proxies = {"http": f"http://{proxy}", "https": f"http://{proxy}"}
    
    def get(self, url: str, **kwargs) -> 'requests.Response':
        """Make GET request with stealth headers"""
        return self._request("GET", url, **kwargs)
    
    def post(self, url: str, **kwargs) -> 'requests.Response':
        """Make POST request with stealth headers"""
        return self._request("POST", url, **kwargs)
    
    def _request(self, method: str, url: str, **kwargs) -> 'requests.Response':
        """Internal request method with stealth and tracking"""
        import requests
        
        # Check circuit breaker
        if not is_gateway_available(self.gateway_name):
            raise CircuitOpenError(f"Gateway {self.gateway_name} circuit is open")
        
        # Add delay if configured
        self.stealth.pre_request_delay()
        
        # Build headers
        referer = kwargs.pop("referer", None)
        origin = kwargs.pop("origin", None)
        api_mode = bool(kwargs.get("data") or kwargs.get("json"))
        
        headers = self.stealth.get_headers(referer=referer, origin=origin, api_mode=api_mode)
        if "headers" in kwargs:
            headers.update(kwargs.pop("headers"))
        
        kwargs["headers"] = headers
        
        try:
            response = self.session.request(method, url, **kwargs)
            self.stealth.post_request()
            self.request_count += 1
            return response
            
        except (requests.exceptions.Timeout, requests.exceptions.ConnectionError) as e:
            self.failure_count += 1
            self.last_error = str(e)
            record_gateway_failure(self.gateway_name)
            raise
    
    def record_result(self, parsed: ParsedResponse) -> None:
        """Record result for circuit breaker tracking"""
        if parsed.is_live or parsed.is_ccn:
            self.success_count += 1
            record_gateway_success(self.gateway_name)
        elif parsed.status in [CardStatus.ERROR, CardStatus.TIMEOUT, CardStatus.RATE_LIMITED]:
            self.failure_count += 1
            record_gateway_failure(self.gateway_name)
        else:
            # Declines don't count as failures for circuit breaker
            record_gateway_success(self.gateway_name)


class CircuitOpenError(Exception):
    """Raised when circuit breaker is open"""
    pass


def enhanced_gateway(gateway_name: str):
    """
    Decorator to add all enhancements to a gateway function.
    
    Adds:
    - Circuit breaker protection
    - Automatic retry with backoff
    - Response parsing
    - Request timing jitter
    
    Usage:
        @enhanced_gateway("stripe_auth")
        def stripe_auth_check(card_num, card_mon, card_yer, card_cvc, proxy=None):
            ...
            return result_string, proxy_ok
    """
    def decorator(func: Callable) -> Callable:
        @wraps(func)
        def wrapper(*args, **kwargs) -> Tuple[str, bool]:
            # Check circuit breaker
            if not is_gateway_available(gateway_name):
                return (f"[CIRCUIT OPEN] {gateway_name} temporarily disabled", False)
            
            # Add pre-request jitter
            random_delay(min_seconds=0.1, max_seconds=0.5)
            
            try:
                result = func(*args, **kwargs)
                
                if isinstance(result, tuple) and len(result) >= 2:
                    status_msg, proxy_ok = result[0], result[1]
                    
                    # Parse response
                    parsed = auto_parse_response(status_msg, gateway_name)
                    
                    # Update circuit breaker
                    if parsed.status in [CardStatus.ERROR, CardStatus.TIMEOUT]:
                        record_gateway_failure(gateway_name)
                    else:
                        record_gateway_success(gateway_name)
                    
                    # Return enhanced status if confidence is high
                    if parsed.confidence >= 0.8:
                        return (parsed.to_display(), proxy_ok)
                    
                    return result
                else:
                    record_gateway_success(gateway_name)
                    return result
                    
            except Exception as e:
                record_gateway_failure(gateway_name)
                return (f"Error: {str(e)[:50]}", False)
        
        return wrapper
    return decorator


def format_result(
    status: CardStatus,
    card_num: str,
    bin_info: Optional[Dict] = None,
    extra: Optional[str] = None
) -> str:
    """Format a standardized result string"""
    emoji = {
        CardStatus.LIVE: "✅",
        CardStatus.CCN: "🔵",
        CardStatus.CVV_MISMATCH: "⚠️",
        CardStatus.INSUFFICIENT: "💰",
        CardStatus.EXPIRED: "📅",
        CardStatus.THREE_DS: "🔐",
        CardStatus.DECLINED: "❌",
        CardStatus.ERROR: "⚠️",
    }.get(status, "❓")
    
    status_text = {
        CardStatus.LIVE: "APPROVED",
        CardStatus.CCN: "CCN",
        CardStatus.CVV_MISMATCH: "CVV Mismatch",
        CardStatus.INSUFFICIENT: "Insufficient Funds",
        CardStatus.EXPIRED: "Expired",
        CardStatus.THREE_DS: "3D Secure",
        CardStatus.DECLINED: "DECLINED",
        CardStatus.ERROR: "Error",
    }.get(status, "Unknown")
    
    result = f"{emoji} {status_text}"
    
    if bin_info:
        bin_str = bin_info.get("formatted", "")
        if bin_str:
            result += f" ({bin_str})"
    
    if extra:
        result += f" - {extra}"
    
    return result


def with_retry(
    func: Callable,
    max_retries: int = 2,
    base_delay: float = 1.0,
) -> Callable:
    """
    Wrap a function with retry logic.
    
    Args:
        func: Function to wrap
        max_retries: Maximum retry attempts
        base_delay: Base delay between retries
    
    Returns:
        Wrapped function with retry logic
    """
    config = RetryConfig(
        max_retries=max_retries,
        base_delay=base_delay,
        max_delay=10.0,
        jitter=0.2,
    )
    
    @wraps(func)
    def wrapper(*args, **kwargs):
        return retry_with_backoff(func, args, kwargs, config=config)
    
    return wrapper


# Convenience exports
__all__ = [
    # Session management
    'GatewaySession',
    'CircuitOpenError',
    
    # Decorators
    'enhanced_gateway',
    'with_retry',
    'with_circuit_breaker',
    
    # Caching
    'cache_token',
    'get_cached_token',
    'clear_token_cache',
    
    # Headers
    'get_random_headers',
    'get_stripe_headers',
    'get_braintree_headers',
    'get_paypal_headers',
    
    # Response parsing
    'ParsedResponse',
    'CardStatus',
    'parse_stripe_response',
    'parse_paypal_response',
    'parse_braintree_response',
    'parse_generic_response',
    'auto_parse_response',
    
    # Utilities
    'random_delay',
    'format_result',
    'get_gateway_status_report',
]
