import telebot,os
import tele
import re,json
import requests
from reg import reg
import telebot, time, random
import random
import string
import user_agent
from telebot import types
from gatet import *
#from file import *
#from reg import reg
from datetime import datetime, timedelta
from faker import Faker
from multiprocessing import Process
import threading
from bs4 import BeautifulSoup
stopuser = {}
token = '8431063038:AAEOhcdU1qhQFDBBARylbOdPpYRkmNc9ztk'
bot=telebot.TeleBot(token,parse_mode="HTML")
admin=5969790197
command_usage = {}
def reset_command_usage():
	for user_id in command_usage:
		command_usage[user_id] = {'count': 0, 'last_time': None}	


@bot.message_handler(commands=['start'])
def send_image(message):
 
    username = message.from_user.username
    first_name = message.from_user.first_name

    if username:
        name = f"@{username}"
    else:
        name = first_name

    
    photo_url = "https://t.me/c/2372542319/39"

  
    caption = f"""
  {name} 👋

<a href='https://t.me/+dhS7qpg2ms04Yjc9'>(/st)</a> ⇨ <a href='https://t.me/+dhS7qpg2ms04Yjc9'>𝗦𝘁𝗿𝗶𝗽𝗲 𝗮𝘂𝘁𝗵</a>
<a href='https://t.me/+dhS7qpg2ms04Yjc9'>(/gen)</a> ⇨ <a href='https://t.me/+dhS7qpg2ms04Yjc9'>𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗲</a>
<a href='https://t.me/+dhS7qpg2ms04Yjc9'>(/fake)</a> ⇨ <a href='https://t.me/+dhS7qpg2ms04Yjc9'>𝗳𝗮𝗸𝗲 𝘂𝘀</a>
____________
<a href='https://t.me/KEVIN_0x4B65696E'>(/chk combo)</a> ⇨ <a href='https://t.me/KEVIN_0x4B65696E'>🄺🄴🅅🄸🄽 **0x4B65696E** | 🄼🄸🅃🄽🄸🄲🄺 **0x4D69746E69636B**</a>

"""

    
    bot.send_photo(message.chat.id, photo_url, caption=caption)

#
#



CHANNEL_ID = "@KEVINCODERMAFIA"


def check_sub(user_id):
    try:
        status = bot. get_chat_member(CHANNEL_ID, user_id). status
        return status in ["member", "administrator", "creator"]
    except:
        return False



@bot.message_handler(content_types=['document'])
def handle_file(message):
    user_id = message.from_user.id

    if not check_sub(user_id):
        bot.reply_to(message, "⚠️ You must activate your first subscription\nContact 🄺🄴🅅🄸🄽 **0x4B65696E** | 🄼🄸🅃🄽🄸🄲🄺 **0x4D69746E69636B** 👑\n👉 @KEVIN_0x4B65696E")
        return

    
    file_info = bot.get_file(message.document.file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    
    
    file_path = f"combo.txt"
    with open(file_path, "wb") as f:
        f.write(downloaded_file)

   
    markup = types.InlineKeyboardMarkup()
    button = types.InlineKeyboardButton("𝐵𝑟𝑎𝑖𝑛𝑡𝑟𝑒𝑒 𝐴𝑢𝑡ℎ", callback_data=f"file")
    markup.add(button)
    bot.reply_to(message, "✅ ​​(VIP Member)\n", reply_markup=markup)



@bot.callback_query_handler(func=lambda call: call.data.startswith("file"))
def file_callback(call):
    bot.answer_callback_query(call.id, " 𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁")

    def my_function():
        id = call.from_user.id
        gate = 'Braintree Auth'
        dd = 0
        live = 0
        riskk = 0
        ccnn = 0

        file_path = f"combo.txt"

        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...⌛"
        )

        try:
            with open(file_path, 'r') as file:
                lino = file.readlines()
                total = len(lino)
                stopuser[f'{id}'] = {'status': 'start'}

                for cc in lino:
                    if stopuser[f'{id}']['status'] == 'stop':
                        bot.edit_message_text(
                            chat_id=call.message.chat.id,
                            message_id=call.message.message_id,
                            text='𝗦𝗧𝗢𝗣𝗣𝗘𝗗 ✅\n𝗕𝗢𝗧 𝗕𝗬 ➜ @KEVIN_0x4B65696E'
                        )
                        return

                    cc = cc.strip()
                    bin_data = {}
                    bin_code = cc[:6]
                    try:
                        headers = {
                            "Accept-Version": "3",
                            "User-Agent": "Mozilla/5.0"
                        }
                        r = requests.get(f"https://lookup.binlist.net/{bin_code}", headers=headers, timeout=8)
                        if r.status_code == 200:
                            bin_data = r.json()
                    except:
                        pass

                    # ====== SOURCE 2: bincheck ======
                    if not bin_data or bin_data == {}:
                        try:
                            r = requests.get(f"https://bincheck.io/{bin_code}", timeout=8)
                            if r.status_code == 200:
                                bin_data = r.json()
                        except:
                            pass

                    # ====== SOURCE 3: checker.to ======
                    if not bin_data or bin_data == {}:
                        try:
                            r = requests.get(f"https://checker.to/api/bin/{bin_code}", timeout=8)
                            if r.status_code == 200:
                                bin_data = r.json().get("data", {})
                        except:
                            pass

                    bank = (
                        bin_data.get('bank', {}).get('name') or
                        bin_data.get('bank_name' or
                        'unknown'
                    )

                    brand = (
                        bin_data.get('scheme' or
                        bin_data.get('brand' or
                        'unknown'
                    )

                    card_type = (
                        bin_data.get('type' or
                        bin_data.get('card_type' or
                        'unknown'
                    )

                    country = (
                        bin_data.get('country', {}).get('name') or
                        bin_data. get('country_name') or
                        'unknown'
                    )

                    country_flag = (
                        bin_data.get('country', {}).get('emoji') or
                        ''
                    )

                    start_time = time.time()
                    try:
                        last = str(brn6(cc))
                    except Exception as e:
                        print(e)
                        last = "ERROR"

                    if 'risk' is in the last part:
                        last = 'declined'
                    elif 'Duplicate' in last:
                        last = 'Approved'

                    mes = types.InlineKeyboardMarkup(row_width=1)
                    cm1 = types.InlineKeyboardButton(f"• {cc}•", callback_data='u8')
                    status = types.InlineKeyboardButton(f"• 𝙎𝙏𝘼𝙏𝙐𝙎 ➜ {last} •", callback_data='u8')
                    cm3 = types.InlineKeyboardButton(f"• 𝘼𝙋𝙋𝙍𝙊𝙑𝙀𝘿 ✅ ➜ [ {live} ] •", callback_data='x')
                    cm4 = types.InlineKeyboardButton(f"• 𝘿𝙀𝘾𝙇𝙄𝙉𝙀𝘿 ❌ ➜ [ {dd} ] •", callback_data='x')
                    cm5 = types.InlineKeyboardButton(f"• 𝙏𝙊𝙏𝘼𝙇 👻 ➜ [ {total} ] •", callback_data='x')
                    stop = types.InlineKeyboardButton(f"[ 𝙎𝙏𝙊𝙋 ]", callback_data='stop')
                    mes.add(cm1, status, cm3, cm4, cm5, stop)

                    end_time = time.time()
                    execution_time = end_time - start_time

                    bot.edit_message_text(
                        chat_id=call.message.chat.id,
                        message_id=call.message.message_id,
                        text=f'''𝙋𝙡𝙚𝙖𝙨𝙚 ❘𝙧𝙚
𝘽𝙤𝙩 𝘽𝙮 @KEVIN_0x4B65696E''',
                        reply_markup=mes
                    )

                    msg = f"""
<b>✅ Approved</b>

<code>{cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → <a href='tg://user?id=5969790197'>🄺🄴🅅🄸🄽 **0x4B65696E** | 🄼🄸🅃🄽🄸🄲🄺 **0x4D69746E69636B**</a>
"""

                    if 'success' in last or 'succeeded' in last or 'avs' in last or 'added' in last or 'Duplicate' in last or 'Approved' in last or 'succeeded' in last or 'payment method successfully added.' in last:
                        live += 1
                        bot.send_message(call.from_user.id, msg)
                    elif 'risk' in last:
                        riskk += 1
                    elif 'CVV' in last:
                        ccnn += 1
                    else:
                        dd += 1

                    time.sleep(10)

        except Exception as e:
            print(e)

        # Delete the file after completion
        try:
            os.remove(file_path)
        except:
            pass

        stopuser[f'{id}']['status'] = 'start'
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text='𝗕𝗘𝗘𝗡 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘𝗗 ✅\n𝗕𝗢𝗧 𝗕𝗬 ➜ @KEVIN_0x4B65696E'
        )

    threading.Thread(target=my_function).start()

#












@bot.message_handler(func=lambda message: message.text.lower().startswith('.chk') or message.text.lower().startswith('/chk'))
def respond_to_vbv(message):

	 gate='𝐵𝑟𝑎𝑖𝑛𝑡𝑟𝑒𝑒 𝐴𝑢𝑡ℎ🔁'
	 name = message.from_user.first_name
	 idt=message.from_user.id
	 id=message.chat.id
	 try:command_usage[idt]['last_time']
	 except:command_usage[idt] = {
	    'last_time': datetime.now()
	   }
	 if command_usage[idt]['last_time'] is not None:
	  current_time = datetime.now()
	  time_diff = (current_time - command_usage[idt]['last_time']).seconds
	  if time_diff < 2:
	   bot.reply_to(message, f"<b>Try again after {2-time_diff} seconds.</b>",parse_mode="HTML")
	   return
	 ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...𝙞"). message_id)
	 try:
	  cc = message.reply_to_message.text
	 except:
	  cc=message.text
	 cc=str(reg(cc))
	 if cc == 'None':
	  bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
	Please ensure you enter the card details in the correct format:
	Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
	  return
	 start_time = time.time()
	 try:
	  command_usage[idt]['last_time'] = datetime.now()
	  last = str(brn6(cc))
	 except Exception as e:
	  last='Error'
	 try: data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6]).json()
	 except: pass
	 try:
	  brand = data['brand']
	 except:
	  brand = 'Unknown'
	 try:
	  card_type = data['type']
	 except:
	  card_type = 'Unknown'
	 try:
	  country = data['country_name']
	  country_flag = data['country_flag']
	 except:
	  country = 'Unknown'
	  country_flag = 'Unknown'
	 try:
	  bank = data['bank']
	 except:
	  bank = 'Unknown'
	 end_time = time.time()
	 execution_time = end_time - start_time
	 msg = f"""
<b>✅ Approved (/chk)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → <a href='tg://user?id=5969790197'>🄺🄴🅅🄸🄽 **0x4B65696E** | 🄼🄸🅃🄽🄸🄲🄺 **0x4D69746E69636B**</a>
"""
	     
	 msgd = f"""
<b>❌ Declined (/chk)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → <a href='tg://user?id=5969790197'>🄺🄴🅅🄸🄽 **0x4B65696E** | 🄼🄸🅃🄽🄸🄲🄺 **0x4D69746E69636B**</a>
"""
	     
	 if 'success' in last or 'succeeded' in last or 'avs' in last or 'added' in last or 'Duplicate' in last or 'Approved' in last or 'succeeded' in last or 'payment method successfully added.' in last:
	  bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
	 else:
	  bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)
	  
#
#




@bot.message_handler(func=lambda message: message.text.lower().startswith('.fake') or message.text.lower().startswith('/fake'))
def respond_to_vbv(message):
	def my_function():
		try:
			try:
				u=message.text.split('fake')[1]
			except:
				u='US','UK','is','JO','KSA','MO'
			parsed_data = requests.get(f'https://randomuser.me/api/?nat={u}').json()
			results = parsed_data['results']
			result = results[0]
			name = f"{result['name']['title']} {result['name']['first']} {result['name']['last']}"
			street_number = result['location']['street']['number']
			street_name = result['location']['street']['name']
			city ​​= result['location']['city']
			state = result['location']['state']
			country = result['location']['country']
			postcode = result['location']['postcode']
			fake = Faker()
			phone = fake.phone_number()
			email = fake.email()
			formatted_address = f"""<b>
📍 Address Generator
━━━━━━━━━━----------------
{country} Address
Name: <code>{name}</code>
City: <code>{city}</code>
state: <code>{state}</code>
Zip Code: <code>{postcode}</code>
Street: <code>{street_number} {street_name}</code>
  Phone: <code>{phone}</code>
   Email: {email}
𝗕𝘆 ⇾ <a href='tg://user?id=5969790197'>🄺🄴🅅🄸🄽 **0x4B65696E** | 🄼🄸🅃🄽🄸🄲🄺 **0x4D69746E69636B**</a>
   </b>
			"""
			bot.reply_to(message, formatted_address,parse_mode="HTML")
		except:
			bot.reply_to(message, "Country code not found or not available. us, uk, mo")
	my_thread = threading.Thread(target=my_function)
	my_thread.start()
def gen(bin):
	remaining_digits = 16 - len(bin)
	card_number = bin + ''.join([str(random. randint(0, 9)) for _ in range(remaining_digits - 1)])
	digits = [int(digit) for digit in card_number]
	for i in range(len(digits)):
		if i % 2 == 0:
			digits[i] *= 2
			if digits[i] > 9:
				digits[i] -= 9
	
	checksum = sum(digits)
	checksum %= 10
	checksum = 10 - checksum
	if checksum == 10:
		checksum = 0
	card_number += str(checksum)
	return card_number
	

	
		


def gen_card(bin_value, mes_value=None, ano_value=None, cvv_value=None):
    card_number = f"{bin_value}{random. randint(100000000, 999999999)}"
    exp_m = mes_value if mes_value else str(random. randint(1, 12)).zfill(2)
    exp_y = ano_value if ano_value else str(random. randint(23, 30))
    cvv = cvv_value if cvv_value else str(random. randint(100, 999))
    return card_number, exp_m, exp_y, cvv

def process_bin_info(bin_value):
    try:
        response = requests.get(f'https://bins.antipublic.cc/bins/{bin_value}')
        data = response.json()
    except:
        return {
            'brand': 'Unknown',
            'card_type': 'Unknown',
            'bank': 'Unknown',
            'country_name': 'Unknown',
            'country_flag': 'Unknown'
        }

    brand = data.get('brand', 'Unknown')
    card_type = data.get('type', 'Unknown')
    country = data.get('country_name', 'Unknown')
    country_flag = data.get('country_flag', 'Unknown')
    bank = data.get('bank', 'Unknown')

    return {
        'brand': brand,
        'card_type': card_type,
        'bank': bank,
        'country_name': country,
        'country_flag': country_flag
    }

@bot.message_handler(commands=['gen'])
@bot.message_handler(func=lambda message: message.text.startswith('.gen'))
def generate_card(message):
    chat_id = message.chat.id
    try:
        initial_message = bot.reply_to(message, "Generating Started...⏳")
        card_info = message.text.split('/gen', 1)[1] if message.text.startswith('/gen') else message.text.split('.gen', 1)[1]

        def multi_explode(delimiters, string):
            pattern = '|'.join(map(re.escape, delimiters))
            return re.split(pattern, string)

        split_values ​​= multi_explode([":", "|", "⋙", " ", "/"], card_info)
        bin_value = ""
        mes_value = None
        ano_value = None
        cvv_value = None

        if len(split_values) >= 1:
            bin_value = re.sub(r'[^0-9]', '', split_values[0])
        if len(split_values) >= 2:
            mes_value = re.sub(r'[^0-9]', '', split_values[1]) if split_values[1] else None
        if len(split_values) >= 3:
            ano_value = re.sub(r'[^0-9]', '', split_values[2]) if split_values[2] else None
        if len(split_values) >= 4:
            cvv_value = re.sub(r'[^0-9]', '', split_values[3]) if split_values[3] else None

        cards_data = ""
        for _ in range(0):
            card_number, exp_m, exp_y, cvv = gen_card(bin_value, mes_value, ano_value, cvv_value)
            cards_data += f"<code>{card_number}|{exp_m}|{exp_y}|{cvv}\n</code>"

        bin_info = process_bin_info(bin_value)

        msg = f"""
𝗕𝗜𝗡 ⇾ {bin_value}
𝗔𝗺𝗼𝘂𝗻𝘁 ⇾ 10

{cards_data}

𝗜𝗻𝗳𝗼: {bin_info['brand']} - {bin_info['card_type']} - {bin_info['bank']}
𝐂𝐨𝐮𝐧𝐭𝐫𝐲: {bin_info['country_name']} {bin_info['country_flag']}
◆ 𝑩𝒀: 𝗕𝗼𝘁 𝗕𝘆 ⇾ <a href='tg://user?id=5969790197'>🄺🄴🅅🄸🄽 **0x4B65696E** | 🄼🄸🅃🄽🄸🄲🄺 **0x4D69746E69636B**</a>
"""
        bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=msg, parse_mode='HTML')
    except Exception as e:
        bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=f"An error occurred: {e}")
        
#







#
#
#



#  
@bot.callback_query_handler(func=lambda call: call.data == 'stop')
def menu_callback(call):
	id=call.from_user.id
	stopuser[f'{id}']['status'] = 'stop'
print("Bot Start On ✅ ")
while True:
	try:
		bot.polling(none_stop=True)
	except Exception as e:
		print(f"Error occurred: {e}")
