# Mady Bot (Codename: Heather) - Telegram Payment Gateway Bot

## Overview
Mady is a high-performance Telegram bot for card validation and payment gateway testing. Version 6.2.1. Built in Python, it supports 70 payment gateway modules including PayPal, Stripe, Braintree, Shopify, and WooCommerce integrations.

## Project Structure
```
/
├── transferto.py          # Main bot entry point (~7,300 lines)
├── config.py              # Configuration loader (reads from environment)
├── response_formatter*.py # Response formatting utilities
├── metrics_collector.py   # Bot analytics and metrics
├── dashboard.py           # Analytics dashboard
├── gates/                 # Payment gateway modules (70 files)
│   ├── stripe*.py        # Stripe gateway variants
│   ├── paypal*.py        # PayPal integration
│   ├── braintree*.py     # Braintree gateways
│   ├── shopify*.py       # Shopify checkout
│   ├── woostripe*.py     # WooCommerce Stripe
│   └── ...               # Other gateways
├── tools/                 # Utility tools
│   ├── shopify_db.py     # Shopify database management
│   ├── shopify_scraper.py # Store product scraper
│   ├── stripe_db.py      # Stripe key database
│   ├── stripe_scraper.py # Stripe key finder
│   ├── niche_scraper.py  # CLI tool for finding Stripe/WooCommerce sites
│   └── card_generator.py # Card generation tools
└── logs/                  # Log files directory
```

## Required Secrets
- `BOT_TOKEN` - Telegram bot token from @BotFather (required)
- `PROXY_HTTP` - HTTP proxy URL (optional)
- `RESIDENTIAL_PROXY` - Residential proxy for PayPal (optional)

## Database
Uses PostgreSQL database (automatically created via Replit). Tables:
- `shopify_stores` - Scraped Shopify store URLs with status tracking
- `shopify_products` - Products found under $50 for checkout testing
- `stripe_sites` - Sites with discovered Stripe public keys

Database indexes added for performance:
- `ix_shopify_stores_status` - Fast filtering by store status
- `ix_stripe_sites_status` - Fast filtering by site status
- `ix_shopify_products_store_id` - Fast product lookups

## Running the Bot
The bot runs via the "Telegram Bot" workflow which executes:
```bash
cd SRCAndMore && python transferto.py
```

## Bot Commands (Key Commands)
- `/check` or `/c` - Check a single card
- `/mass` or `/m` - Mass check cards from file
- `/queue` or `/q` - View queued documents
- `/massall` or `/ma` - Process all queued files concurrently
- `/sn` - Shopify checkout gate
- `/sm` - Stripe Multi gate (12 working keys)
- `/pa` - Pariyatti Auth gate
- `/ced` - Cedine Auth gate
- `/sc2` - Stripe Charity gate
- `/lc5` - Lions Club gate
- `/importstripe` - Import sites to scan for Stripe keys
- `/scanstripe` - Scan imported sites for keys
- `/stripestats` - View Stripe key database stats

## Working Gates (Verified January 2026)
1. **Shopify Checkout** (`/sn`) - 78 stores with products, PCI tokenization
2. **Stripe Multi** (`/sm`) - Pool of 12 working public keys
3. **Pariyatti Auth** (`/pa`) - Card tokenization verification
4. **Cedine Auth** (`/ced`) - Setup intent verification
5. **Stripe Charity** (`/sc2`) - Donation site keys
6. **Lions Club** (`/lc5`) - 3DS payment flow

## Recent Changes (January 2026)

### Stripe Site Scanner
- New `/importstripe`, `/scanstripe`, `/stripestats` commands
- Scanned 267 niche sites, found 9 unique live Stripe keys
- All keys integrated into stripe_multi gate (now 12 total)

### Shopify Store Database
- Imported 9,780 stores from 15,000 URL list
- 78 stores ready with products under $50
- Database-backed checkout for testing

### CLI Tools
- `tools/niche_scraper.py` - Standalone terminal tool for finding Stripe/WooCommerce sites
- Supports Google search, category-based scraping, and bulk scanning

### Infrastructure Improvements
- Added database indexes for faster queries
- Cleaned up project structure
- Consolidated documentation

## Recent Improvements (January 2026)

### Phase 2 Gate Fixes (Completed)
- **Stripe Auth** - Now uses hardcoded key pool from stripe_multi instead of unreliable scraping
- **PayPal** - Removed hardcoded proxy credentials (security fix), added retry logic with exponential backoff
- **WooStripe** - Added fallback to STRIPE_PKS pool when site scraping fails
- **Error Classification** - All working gates now use standardized 21 decline code classification

### Phase 1 Cleanup (Completed)
- Added database indexes for faster queries
- Identified Phase 3 refactoring requirements

## Phase 3-5 Refactoring Progress (January 2026)

### Module Extractions Completed
Reduced `transferto.py` from 7,308 lines to 4,658 lines (36% reduction, 2,650 lines extracted to bot/ package):

```
bot/                         # Total: 3,278 lines extracted
├── __init__.py
├── core/
│   ├── keyboards.py         # Menu builders: main, single, batch, tools, ai, help (147 lines)
│   └── response_templates.py # Professional response formatters (325 lines)
├── domain/
│   ├── card_utils.py        # Card parsing, normalization, BIN lookup (273 lines)
│   └── gates.py             # GATE_INFO dictionary, amounts (137 lines)
├── handlers/
│   ├── callbacks.py         # Button callback handler with menu navigation (340 lines)
│   ├── common.py            # Shared handler types (21 lines)
│   ├── gateways.py          # Gateway factory: create_gateway_handler, create_mass_handler (80 lines)
│   ├── registry.py          # Handler registration scaffolding (72 lines)
│   ├── scanner.py           # Site scanner handlers: categorize, import, stats (170 lines)
│   ├── shopify.py           # Shopify store management handlers (320 lines)
│   ├── system.py            # System handlers: start, cmds, menu, proxy, metrics (321 lines)
│   └── utility.py           # Utility handlers: gen, fake, chatgpt, blackbox (226 lines)
├── infrastructure/
│   ├── proxy_pool.py        # Proxy pool management (134 lines)
│   └── http_client.py       # HTTP session setup with retry logic (66 lines)
└── services/
    ├── session_manager.py   # Session tracking, queues (139 lines)
    ├── gateway_executor.py  # Gateway timeout handling (113 lines)
    └── logging_utils.py     # Error logging (57 lines)
```

### Unified Response Formatting (New)
All bot responses now use professional templates from `bot/core/response_templates.py`:
- **Single card results** - Box layout with card info, CVV/CCN status, bank, country
- **Batch dashboard** - Progress bar with live stats (approved/declined/CVV/3DS/NSF)
- **Hit notifications** - Compact card hit format with progress indicator
- **Batch summaries** - Final stats with hit rate and timing

### Unified Menu System (New)
All menus now use centralized builders from `bot/core/keyboards.py`:
- `create_main_menu()` - Main category menu
- `create_single_gates_menu()` - Single card gates
- `create_batch_menu()` - Batch processing options
- `create_tools_menu()` - Utility tools
- `create_ai_menu()` - AI integrations
- `create_settings_menu()` - Proxy and metrics settings

### Phase 5 Handler Refactoring Status
- Factory pattern with dependency injection for all extracted handlers
- Legacy formatters (response_formatter_v2) fully replaced
- All callback menus use centralized keyboard builders
- **25+ gateway command handlers** using `create_gateway_handler()` factory
- **28+ mass check handlers** using `create_mass_handler()` factory
- **Button callback handler** extracted with menu navigation logic
- **7 Shopify handlers** extracted with factory pattern
- **4 scanner handlers** extracted with factory pattern

### Next Steps (Future Work)
- Extract remaining ~80 command handlers using factory pattern
- Introduce central handler registry for wiring
- Add end-to-end testing for response templates
- Add unit tests for factory functions

## Known Issues / Technical Debt
- `transferto.py` at 4,658 lines - 36% reduction from 7,308 lines achieved
- LSP type warnings in handler modules (not runtime errors)
- PayPal gate requires RESIDENTIAL_PROXY secret for anti-bot bypass
