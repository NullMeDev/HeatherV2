"""
Utility Handlers Module

Contains utility commands: gen, fake, chatgpt, blackbox.
"""

import os
import asyncio
import httpx
from telegram import Update
from telegram.ext import ContextTypes

from tools.card_generator import generate_cards, lookup_bin, format_gen_response
from tools.fake_identity import generate_fake_identity, format_fake_response

__all__ = [
    'create_gen_handler',
    'create_fake_handler',
    'create_chatgpt_handler',
    'create_blackbox_handler',
]


def create_gen_handler():
    """Factory to create gen command handler."""
    async def gen_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /gen command - Generate Luhn-valid cards from BIN"""
        if not context.args:
            await update.message.reply_text(
                "<b>Card Generator</b>\n\n"
                "Usage: <code>/gen BIN [amount]</code>\n\n"
                "Examples:\n"
                "<code>/gen 414720</code> - Generate 10 cards\n"
                "<code>/gen 414720xxxxxxxxxx 25</code> - Generate 25 cards\n"
                "<code>/gen 414720|12|xx|xxx 10</code> - With month fixed",
                parse_mode='HTML'
            )
            return
        
        bin_input = context.args[0]
        amount = 10
        if len(context.args) > 1 and context.args[1].isdigit():
            amount = min(int(context.args[1]), 100)
        
        parts = bin_input.split('|')
        bin_pattern = parts[0].replace("-", "").replace(" ", "").ljust(16, 'x')
        mes = parts[1] if len(parts) > 1 else None
        ano = parts[2] if len(parts) > 2 else None
        cvv = parts[3] if len(parts) > 3 else None
        
        processing = await update.message.reply_text("Generating cards...")
        
        bin_info = await asyncio.to_thread(lookup_bin, bin_pattern[:6])
        brand = bin_info['brand'] if bin_info else ""
        
        cards = generate_cards(bin_pattern, mes, ano, cvv, amount, brand)
        
        if amount > 10:
            cards_text = '\n'.join(cards)
            filename = f"/tmp/gen_{update.message.from_user.id}_{amount}.txt"
            with open(filename, 'w') as f:
                f.write(cards_text)
            
            await processing.delete()
            await update.message.reply_document(
                document=open(filename, 'rb'),
                filename=f"{bin_pattern[:6]}_{amount}_cards.txt",
                caption=format_gen_response(cards, bin_info, bin_pattern, amount),
                parse_mode='HTML'
            )
            os.remove(filename)
        else:
            response = format_gen_response(cards, bin_info, bin_pattern, amount)
            await processing.edit_text(response, parse_mode='HTML')
    
    return gen_command


def create_fake_handler():
    """Factory to create fake command handler."""
    async def fake_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /fake command - Generate fake identity"""
        country_code = context.args[0].lower() if context.args else "us"
        
        processing = await update.message.reply_text("Generating fake identity...")
        
        identity = await asyncio.to_thread(generate_fake_identity, country_code)
        response = format_fake_response(identity, country_code)
        
        await processing.edit_text(response, parse_mode='HTML')
    
    return fake_command


def create_chatgpt_handler():
    """Factory to create chatgpt command handler."""
    async def chatgpt_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /cg command - Chat with ChatGPT"""
        if not context.args:
            await update.message.reply_text(
                "<b>ChatGPT</b>\n\n"
                "Usage: <code>/cg your question here</code>\n\n"
                "Example: <code>/cg What is the capital of France?</code>",
                parse_mode='HTML'
            )
            return
        
        prompt = ' '.join(context.args)
        processing = await update.message.reply_text("Thinking...")
        
        try:
            import urllib.parse
            encoded_prompt = urllib.parse.quote(prompt)
            api_url = f"https://api-chatgpt4.eternalowner06.workers.dev/?prompt={encoded_prompt}"
            
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.get(api_url)
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        if isinstance(data, dict):
                            answer = data.get('response', data.get('answer', data.get('message', str(data))))
                        else:
                            answer = str(data)
                    except:
                        answer = response.text
                    
                    if len(answer) > 4000:
                        answer = answer[:4000] + "..."
                    
                    await processing.edit_text(
                        f"<b>ChatGPT</b>\n\n"
                        f"<b>Q:</b> <i>{prompt[:200]}{'...' if len(prompt) > 200 else ''}</i>\n\n"
                        f"<b>A:</b> {answer}",
                        parse_mode='HTML'
                    )
                else:
                    await processing.edit_text(
                        f"API Error: {response.status_code}\n\nTry again later.",
                        parse_mode='HTML'
                    )
        except httpx.TimeoutException:
            await processing.edit_text("Request timed out. Please try again.", parse_mode='HTML')
        except Exception as e:
            await processing.edit_text(f"Error: {str(e)[:200]}", parse_mode='HTML')
    
    return chatgpt_command


def create_blackbox_handler():
    """Factory to create blackbox command handler."""
    async def blackbox_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
        """Handle /bb command - Chat with Blackbox AI"""
        if not context.args:
            await update.message.reply_text(
                "<b>Blackbox AI</b>\n\n"
                "Usage: <code>/bb your question here</code>\n\n"
                "Example: <code>/bb How do I fix this Python error?</code>",
                parse_mode='HTML'
            )
            return
        
        prompt = ' '.join(context.args)
        processing = await update.message.reply_text("Thinking...")
        
        try:
            blackbox_api_key = os.environ.get('BLACKBOX_API_KEY', '')
            if not blackbox_api_key:
                await processing.edit_text("Blackbox API key not configured.", parse_mode='HTML')
                return
            
            headers = {
                'Authorization': f'Bearer {blackbox_api_key}',
                'Content-Type': 'application/json'
            }
            
            payload = {
                'messages': [{'role': 'user', 'content': prompt}],
                'model': 'blackboxai/openai/gpt-4',
                'temperature': 0.7,
                'max_tokens': 2048,
                'stream': False
            }
            
            async with httpx.AsyncClient(timeout=60.0) as client:
                response = await client.post(
                    'https://api.blackbox.ai/chat/completions',
                    headers=headers,
                    json=payload
                )
                
                if response.status_code == 200:
                    try:
                        data = response.json()
                        if isinstance(data, dict):
                            choices = data.get('choices', [])
                            if choices:
                                answer = choices[0].get('message', {}).get('content', str(data))
                            else:
                                answer = data.get('response', str(data))
                        else:
                            answer = str(data)
                    except:
                        answer = response.text
                    
                    if len(answer) > 4000:
                        answer = answer[:4000] + "..."
                    
                    await processing.edit_text(
                        f"<b>Blackbox AI</b>\n\n"
                        f"<b>Q:</b> <i>{prompt[:200]}{'...' if len(prompt) > 200 else ''}</i>\n\n"
                        f"<b>A:</b> {answer}",
                        parse_mode='HTML'
                    )
                else:
                    await processing.edit_text(
                        f"API Error: {response.status_code}\n\nTry again later.",
                        parse_mode='HTML'
                    )
        except httpx.TimeoutException:
            await processing.edit_text("Request timed out. Please try again.", parse_mode='HTML')
        except Exception as e:
            await processing.edit_text(f"Error: {str(e)[:200]}", parse_mode='HTML')
    
    return blackbox_command
