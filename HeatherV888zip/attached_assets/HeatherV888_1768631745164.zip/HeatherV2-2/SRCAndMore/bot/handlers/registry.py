"""
Handler Registration Module

Provides functions to register command handlers in organized groups.
This module serves as the foundation for modular handler organization.

Current approach: Handlers remain in transferto.py but registration
is organized by group for future extraction.
"""

from telegram.ext import Application, CommandHandler, CallbackQueryHandler, MessageHandler, filters

__all__ = [
    'register_system_handlers',
    'register_gateway_handlers', 
    'register_utility_handlers',
    'register_document_handlers',
]


def register_system_handlers(app: Application, handlers: dict):
    """
    Register system/core handlers (start, menu, proxy, metrics).
    
    Args:
        app: Telegram Application instance
        handlers: Dict mapping command names to handler functions
    """
    system_commands = ['start', 'menu', 'cmds', 'proxy', 'setproxy', 'sp', 'metrics']
    for cmd in system_commands:
        if cmd in handlers:
            app.add_handler(CommandHandler(cmd, handlers[cmd]))


def register_gateway_handlers(app: Application, handlers: dict):
    """
    Register payment gateway handlers.
    
    Args:
        app: Telegram Application instance  
        handlers: Dict mapping command names to handler functions
    """
    # Gateway commands are registered directly for now
    for cmd, handler in handlers.items():
        app.add_handler(CommandHandler(cmd, handler))


def register_utility_handlers(app: Application, handlers: dict):
    """
    Register utility handlers (gen, fake, cards, etc).
    
    Args:
        app: Telegram Application instance
        handlers: Dict mapping command names to handler functions
    """
    for cmd, handler in handlers.items():
        app.add_handler(CommandHandler(cmd, handler))


def register_document_handlers(app: Application, document_handler, message_handler):
    """
    Register document and message handlers.
    
    Args:
        app: Telegram Application instance
        document_handler: Handler for document uploads
        message_handler: Handler for text messages
    """
    if document_handler:
        app.add_handler(MessageHandler(filters.Document.ALL, document_handler))
    if message_handler:
        app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
