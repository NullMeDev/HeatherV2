"""
Gateway command handlers using factory pattern.
All gateway commands follow the same pattern of extracting card input
and calling process_cards_with_gateway().
"""
from telegram import Update
from telegram.ext import ContextTypes
from typing import Callable, Tuple, List

__all__ = [
    'create_gateway_handler',
    'create_mass_handler',
    'extract_card_input',
]


def extract_card_input(update: Update, context: ContextTypes.DEFAULT_TYPE, prefixes: List[str]) -> str:
    """
    Extract card input from message text.
    Handles command prefixes and multiline input.
    
    Args:
        update: Telegram update object
        context: Command context
        prefixes: List of command prefixes to strip (e.g., ['/c1 ', '/charge1 '])
    
    Returns:
        Raw card input text
    """
    raw_text = update.message.text
    
    for prefix in prefixes:
        if raw_text.lower().startswith(prefix):
            return raw_text[len(prefix):].strip()
    
    if '\n' in raw_text:
        return raw_text.split('\n', 1)[1].strip()
    elif context.args:
        return ' '.join(context.args)
    
    return ''


def create_gateway_handler(
    gateway_fn: Callable,
    gateway_name: str,
    gateway_type: str,
    prefixes: List[str],
    process_cards_fn: Callable
):
    """
    Factory function to create gateway command handlers.
    
    Args:
        gateway_fn: The gateway check function
        gateway_name: Display name for the gateway
        gateway_type: Gateway type (stripe, paypal, braintree, etc.)
        prefixes: Command prefixes to strip
        process_cards_fn: The process_cards_with_gateway function
    
    Returns:
        Async handler function
    """
    async def handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
        raw_text = extract_card_input(update, context, prefixes)
        await process_cards_fn(update, raw_text, gateway_fn, gateway_name, gateway_type)
    
    return handler


def create_mass_handler(
    gateway_fn: Callable,
    gateway_name: str,
    mass_with_gateway_fn: Callable
):
    """
    Factory function to create mass check command handlers.
    
    Args:
        gateway_fn: The gateway check function (possibly with proxy argument handling)
        gateway_name: Display name for the gateway
        mass_with_gateway_fn: The mass_with_gateway function
    
    Returns:
        Async handler function
    """
    async def handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
        await mass_with_gateway_fn(update, context, gateway_fn=gateway_fn, gateway_name=gateway_name)
    
    return handler
