import os
import asyncio
import time
from concurrent.futures import ThreadPoolExecutor
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, CallbackQueryHandler, ContextTypes, filters
from checker import check_card

BOT_TOKEN = '8203652246:AAGF_kwoEz9HaErAmlwMFfyDlPw7av15-IE'

user_sessions = {}

# Thread pool for parallel card checking
executor = ThreadPoolExecutor(max_workers=6)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send welcome message when /start is issued."""
    keyboard = [
        [InlineKeyboardButton("Check Card", callback_data='check')],
        [InlineKeyboardButton("Bulk Check", callback_data='bulk')],
        [InlineKeyboardButton("Help", callback_data='help')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    welcome_text = """
<b>Welcome to Card Checker Bot</b>
━━━━━━━━━━━━━━━━

<b>Commands:</b>
/check - Check a single card
/mass - Bulk check (paste cards or upload .txt)
/status - View session stats
/help - Show help

<b>Card Format:</b>
<code>XXXX|MM|YY|CVV</code>

━━━━━━━━━━━━━━━━
<b>Gate:</b> Stripe Charge 1$
<b>Workers:</b> 6 threads
"""
    await update.message.reply_text(welcome_text, parse_mode='HTML', reply_markup=reply_markup)


async def help_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Send help message when /help is issued."""
    help_text = """
<b>Card Checker Bot - Help</b>
━━━━━━━━━━━━━━━━

<b>Available Commands:</b>

/start - Welcome message
/check - Check a single card
/mass - Bulk check cards
/status - View your session statistics
/help - Show this help message

<b>Card Format:</b>
<code>XXXXXXXXXXXX|MM|YY|CVV</code>

<b>Example:</b>
<code>4532015112830366|05|27|123</code>

<b>Bulk Check:</b>
- Upload .txt file with cards (one per line)
- OR paste cards directly (one per line)

━━━━━━━━━━━━━━━━
<b>Gate:</b> Stripe Charge 1$
<b>Workers:</b> 6 parallel threads
"""
    await update.message.reply_text(help_text, parse_mode='HTML')


async def check_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /check command - expects card in next message or as argument."""
    user_id = update.effective_user.id
    
    if context.args:
        card = ' '.join(context.args)
        await process_single_card(update, card)
    else:
        user_sessions[user_id] = user_sessions.get(user_id, {})
        user_sessions[user_id]['mode'] = 'check_single'
        await update.message.reply_text(
            "<b>Send card to check</b>\n\nFormat: <code>XXXX|MM|YY|CVV</code>",
            parse_mode='HTML'
        )


async def mass_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle /mass command - expects file upload or direct cards."""
    user_id = update.effective_user.id
    user_sessions[user_id] = user_sessions.get(user_id, {})
    user_sessions[user_id]['mode'] = 'bulk_check'
    
    await update.message.reply_text(
        "<b>Send cards for bulk check</b>\n\n"
        "Options:\n"
        "1. Upload .txt file with cards\n"
        "2. Paste cards directly (one per line)\n\n"
        "Format: <code>XXXX|MM|YY|CVV</code>",
        parse_mode='HTML'
    )


async def status_command(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Show user session statistics."""
    user_id = update.effective_user.id
    session = user_sessions.get(user_id, {})
    
    checked = session.get('checked', 0)
    approved = session.get('approved', 0)
    declined = session.get('declined', 0)
    
    status_text = f"""
<b>Session Statistics</b>
━━━━━━━━━━━━━━━━

<b>Total Checked:</b> {checked}
<b>Approved:</b> {approved}
<b>Declined:</b> {declined}

━━━━━━━━━━━━━━━━
"""
    await update.message.reply_text(status_text, parse_mode='HTML')


def format_result(result: dict) -> tuple:
    """Format result with emoji and status text."""
    if result['approved']:
        msg_lower = result['message'].lower()
        if '3d' in msg_lower or 'requires_action' in msg_lower or 'authenticate' in msg_lower:
            return "✅", "3D Secure Required"
        else:
            return "🔥", "Approved"
    else:
        return "❌", "Declined"


async def process_single_card(update: Update, card: str) -> None:
    """Process a single card check."""
    user_id = update.effective_user.id
    
    if user_id not in user_sessions:
        user_sessions[user_id] = {'checked': 0, 'approved': 0, 'declined': 0}
    
    checking_msg = await update.message.reply_text(
        "<b>Checking card...</b>",
        parse_mode='HTML'
    )
    
    start_time = time.time()
    
    # Run check in thread pool
    loop = asyncio.get_event_loop()
    result = await loop.run_in_executor(executor, check_card, card)
    
    elapsed = round(time.time() - start_time, 2)
    
    user_sessions[user_id]['checked'] = user_sessions[user_id].get('checked', 0) + 1
    
    emoji, status_text = format_result(result)
    
    if result['approved']:
        user_sessions[user_id]['approved'] = user_sessions[user_id].get('approved', 0) + 1
    else:
        user_sessions[user_id]['declined'] = user_sessions[user_id].get('declined', 0) + 1
    
    result_text = f"""
{emoji} <b>{status_text}</b>
━━━━━━━━━━━━━━━━
[>] <b>CC:</b> <code>{result['card']}</code>
[>] <b>GATES:</b> Stripe Charge1$
[>] <b>RESPONSE:</b> {result['message']}
━━━━━━━━━━━━━━━━
Time: {elapsed}s
"""
    
    keyboard = [[InlineKeyboardButton("Check Another", callback_data='check')]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await checking_msg.edit_text(result_text, parse_mode='HTML', reply_markup=reply_markup)


async def process_bulk_cards(update: Update, cards: list) -> None:
    """Process multiple cards with threading - live results."""
    user_id = update.effective_user.id
    total = len(cards)
    
    progress_msg = await update.message.reply_text(
        f"<b>Bulk Check Started</b>\n\n"
        f"Total cards: {total}\n"
        f"Workers: 6 threads\n"
        f"Processing...",
        parse_mode='HTML'
    )
    
    if user_id not in user_sessions:
        user_sessions[user_id] = {'checked': 0, 'approved': 0, 'declined': 0}
    
    approved_count = 0
    declined_count = 0
    checked_count = 0
    
    start_time = time.time()
    loop = asyncio.get_event_loop()
    
    # Process cards in batches of 6, but send results as they complete
    batch_size = 6
    
    for batch_start in range(0, total, batch_size):
        batch_end = min(batch_start + batch_size, total)
        batch = cards[batch_start:batch_end]
        
        # Create tasks for batch
        tasks = [loop.run_in_executor(executor, check_card, card) for card in batch]
        
        # Process results as they complete (live)
        for coro in asyncio.as_completed(tasks):
            result = await coro
            checked_count += 1
            user_sessions[user_id]['checked'] = user_sessions[user_id].get('checked', 0) + 1
            
            emoji, status_text = format_result(result)
            
            # Send result immediately
            result_text = f"""
{emoji} <b>{status_text}</b>
━━━━━━━━━━━━━━━━
[>] <b>CC:</b> <code>{result['card']}</code>
[>] <b>GATES:</b> Stripe Charge1$
[>] <b>RESPONSE:</b> {result['message']}
━━━━━━━━━━━━━━━━
"""
            await update.message.reply_text(result_text, parse_mode='HTML')
            
            if result['approved']:
                approved_count += 1
                user_sessions[user_id]['approved'] = user_sessions[user_id].get('approved', 0) + 1
            else:
                declined_count += 1
                user_sessions[user_id]['declined'] = user_sessions[user_id].get('declined', 0) + 1
            
            # Update progress after each card
            progress = int(checked_count / total * 10)
            bar = "=" * progress + "-" * (10 - progress)
            pct = int(checked_count / total * 100)
            
            try:
                await progress_msg.edit_text(
                    f"<b>Bulk Check In Progress</b>\n"
                    f"[{bar}] {pct}%\n\n"
                    f"🔥 Approved: {approved_count}\n"
                    f"❌ Declined: {declined_count}\n"
                    f"Remaining: {total - checked_count}",
                    parse_mode='HTML'
                )
            except:
                pass
        
        # Small delay between batches
        if batch_end < total:
            await asyncio.sleep(0.5)
    
    elapsed = round(time.time() - start_time, 2)
    
    summary = f"""
<b>Bulk Check Complete</b>
━━━━━━━━━━━━━━━━

<b>Total:</b> {total}
🔥 <b>Approved:</b> {approved_count}
❌ <b>Declined:</b> {declined_count}

<b>Time:</b> {elapsed}s
━━━━━━━━━━━━━━━━
"""
    await update.message.reply_text(summary, parse_mode='HTML')


async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle text messages."""
    user_id = update.effective_user.id
    text = update.message.text.strip()
    
    session = user_sessions.get(user_id, {})
    
    # Check if it's multiple cards (bulk mode)
    lines = [line.strip() for line in text.split('\n') if line.strip() and '|' in line]
    
    if len(lines) > 1 or session.get('mode') == 'bulk_check':
        # Multiple cards - bulk check
        if lines:
            user_sessions[user_id] = session
            user_sessions[user_id]['mode'] = None
            await process_bulk_cards(update, lines)
    elif len(lines) == 1 or (session.get('mode') == 'check_single' and '|' in text):
        # Single card
        user_sessions[user_id] = session
        user_sessions[user_id]['mode'] = None
        await process_single_card(update, lines[0] if lines else text)


async def handle_document(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle file uploads for bulk checking."""
    user_id = update.effective_user.id
    document = update.message.document
    
    if not document.file_name.endswith('.txt'):
        await update.message.reply_text(
            "<b>Invalid file</b>\n\nPlease upload a .txt file",
            parse_mode='HTML'
        )
        return
    
    file = await document.get_file()
    file_content = await file.download_as_bytearray()
    content = file_content.decode('utf-8')
    
    cards = [line.strip() for line in content.split('\n') if line.strip() and '|' in line]
    
    if not cards:
        await update.message.reply_text(
            "<b>No valid cards found</b>\n\nFormat: <code>XXXX|MM|YY|CVV</code>",
            parse_mode='HTML'
        )
        return
    
    await process_bulk_cards(update, cards)


async def button_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Handle button callbacks."""
    query = update.callback_query
    await query.answer()
    
    user_id = query.from_user.id
    
    if query.data == 'check':
        user_sessions[user_id] = user_sessions.get(user_id, {})
        user_sessions[user_id]['mode'] = 'check_single'
        await query.message.reply_text(
            "<b>Send card to check</b>\n\nFormat: <code>XXXX|MM|YY|CVV</code>",
            parse_mode='HTML'
        )
    
    elif query.data == 'bulk':
        user_sessions[user_id] = user_sessions.get(user_id, {})
        user_sessions[user_id]['mode'] = 'bulk_check'
        await query.message.reply_text(
            "<b>Send cards for bulk check</b>\n\n"
            "Options:\n"
            "1. Upload .txt file with cards\n"
            "2. Paste cards directly (one per line)\n\n"
            "Format: <code>XXXX|MM|YY|CVV</code>",
            parse_mode='HTML'
        )
    
    elif query.data == 'help':
        help_text = """
<b>Card Checker Bot - Help</b>
━━━━━━━━━━━━━━━━

<b>Available Commands:</b>

/start - Welcome message
/check - Check a single card
/mass - Bulk check cards
/status - View your session statistics
/help - Show this help message

<b>Card Format:</b>
<code>XXXXXXXXXXXX|MM|YY|CVV</code>

<b>Bulk Check:</b>
- Upload .txt file OR paste cards directly

━━━━━━━━━━━━━━━━
<b>Gate:</b> Stripe Charge 1$
<b>Workers:</b> 6 parallel threads
"""
        await query.message.reply_text(help_text, parse_mode='HTML')


def main():
    """Start the bot."""
    if not BOT_TOKEN:
        print("Error: TELEGRAM_BOT_TOKEN environment variable not set")
        print("Please set your Telegram bot token:")
        print("  export TELEGRAM_BOT_TOKEN='your_bot_token_here'")
        return
    
    application = Application.builder().token(BOT_TOKEN).build()
    
    application.add_handler(CommandHandler("start", start))
    application.add_handler(CommandHandler("help", help_command))
    application.add_handler(CommandHandler("check", check_command))
    application.add_handler(CommandHandler("mass", mass_command))
    application.add_handler(CommandHandler("bulkcheck", mass_command))  # Alias
    application.add_handler(CommandHandler("status", status_command))
    application.add_handler(CallbackQueryHandler(button_callback))
    application.add_handler(MessageHandler(filters.Document.ALL, handle_document))
    application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))
    
    print("Bot started! Press Ctrl+C to stop.")
    print("Workers: 6 threads")
    application.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == '__main__':
    main()
