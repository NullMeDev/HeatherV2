# Replit.md

## Overview

This is a Telegram bot application designed for credit card validation and testing. The bot integrates with multiple payment gateway APIs (Stripe, Braintree) to verify card information through various checking methods. It supports proxy management for request routing and includes user access control features.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Core Application Structure

The application follows a modular Python architecture with separate files handling distinct responsibilities:

- **main.py** - Central bot controller using pyTelegramBotAPI (telebot) for Telegram integration. Handles command routing, user authentication, and coordinates between different checking modules.

- **Multiple Card Checking Modules** - Each module implements a different validation strategy:
  - `stpauth.py` - Stripe authentication-based checking via WooCommerce sites
  - `stcharge.py` - Stripe charge-based validation through donation forms
  - `stc1.py` and `stc2.py` - Alternative Stripe checking implementations
  - `gatet.py` - Braintree gateway token-based validation
  - `autostripe.py` - Automated Stripe site configuration and checking

### Request Flow Pattern

All card checking modules follow a consistent pattern:
1. Generate fake user identity data using Faker library
2. Obtain session tokens/nonces from target websites
3. Create payment methods via Stripe/Braintree APIs
4. Submit validation requests and parse responses
5. Return structured result dictionaries

### User Access Control

- JSON-based user allowlist stored in `allowed.json`
- Admin user ID hardcoded for override access
- Per-user site configurations stored in `sites.json` (Stripe) and `bt_sites.json` (Braintree)

### Multi-Site Auto Gates

Users can save multiple WooCommerce sites for automatic card checking:

**Stripe Sites:**
- `/addsite https://site.com email password` - Add a Stripe site (verifies login first)
- `/mysite` - List all saved Stripe sites with slot numbers
- `/delsite N` - Delete site at slot N
- `/ast1`, `/ast2`, etc. - Check cards with specific site slot

**Braintree Sites:**
- `/addbtsite https://site.com email password` - Add a Braintree site (verifies login first)
- `/mybtsite` - List all saved Braintree sites with slot numbers
- `/delbtsite N` - Delete site at slot N
- `/abt1`, `/abt2`, etc. - Check cards with specific site slot

Sites are stored in indexed format: `user_id -> {"1": {...}, "2": {...}}`

### Proxy Management

The `proxy_manager.py` module provides:
- JSON-based proxy storage in `proxy.json`
- Proxy testing against httpbin.org
- Random proxy selection for request distribution
- Add/remove/clear operations for proxy pool management

### Data Formats

- Credit card input format: `XXXX|MM|YY|CVV` (pipe-delimited)
- `reg.py` provides regex-based card string normalization
- Card data stored in `combo.txt` for batch processing

## External Dependencies

### Third-Party Services

- **Telegram Bot API** - Primary user interface via pyTelegramBotAPI
- **Stripe API** - Payment method creation and validation (js.stripe.com endpoints)
- **Braintree API** - Alternative payment gateway for card validation
- **BIN Lookup APIs** - Card issuer information (binlist.net, lookup services)

### Target Websites

The bot interacts with various e-commerce and donation sites for obtaining valid session tokens:
- WooCommerce stores (epicalarc.com, catechdepot.com)
- Donation platforms (donorbox.org, ccfoundationorg.com)
- Various florist and retail websites for Braintree tokens

### Python Dependencies

- `pyTelegramBotAPI` - Telegram bot framework
- `requests` - HTTP client for API calls
- `beautifulsoup4` - HTML parsing for token extraction
- `Faker` - Random user data generation
- `user_agent` - User agent string generation

### Data Storage

- File-based JSON storage for configuration (no database)
- `allowed.json` - User access control
- `proxy.json` - Proxy server list
- `sites.json` - User-specific site configurations