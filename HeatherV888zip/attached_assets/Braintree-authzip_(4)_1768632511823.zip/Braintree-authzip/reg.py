import re

def reg(cc):
    regex = r'\d+'
    matches = re.findall(regex, cc)
    match = ''.join(matches)
    
    is_amex = match.startswith("34") or match.startswith("37")
    
    if is_amex:
        card_len = 15
        cvv_len = 4
        min_2yr = 15 + 2 + 2 + 4  # 23
        min_4yr = 15 + 2 + 4 + 4  # 25
    else:
        card_len = 16
        cvv_len = 3
        min_2yr = 16 + 2 + 2 + 3  # 23
        min_4yr = 16 + 2 + 4 + 3  # 25
    
    total_len = len(match)
    
    if total_len >= min_4yr:
        n = match[:card_len]
        mm = match[card_len:card_len+2]
        yy = match[card_len+2:card_len+6]
        cvc = match[card_len+6:card_len+6+cvv_len]
    elif total_len >= min_2yr:
        n = match[:card_len]
        mm = match[card_len:card_len+2]
        yy = match[card_len+2:card_len+4]
        cvc = match[card_len+4:card_len+4+cvv_len]
    else:
        return None
    
    cc = f"{n}|{mm}|{yy}|{cvc}"
    
    if is_amex:
        if not re.match(r'^\d{15}$', n):
            return None
        if not re.match(r'^\d{4}$', cvc):
            return None
    else:
        if not re.match(r'^\d{16}$', n):
            return None
        if not re.match(r'^\d{3}$', cvc):
            return None
    
    if not re.match(r'^\d{2}$', mm):
        return None
    if not re.match(r'^\d{2,4}$', yy):
        return None
    
    return cc
