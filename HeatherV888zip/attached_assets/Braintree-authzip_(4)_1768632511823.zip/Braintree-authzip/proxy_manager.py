import json
import random
import os
import requests

PROXY_FILE = 'proxy.json'

def load_proxies():
    try:
        if os.path.exists(PROXY_FILE):
            with open(PROXY_FILE, 'r') as f:
                data = json.load(f)
                return data.get('proxies', [])
    except:
        pass
    return []

def save_proxies(proxies):
    with open(PROXY_FILE, 'w') as f:
        json.dump({'proxies': proxies}, f, indent=2)

def test_proxy(proxy_str):
    try:
        proxies = {
            'http': f'http://{proxy_str}',
            'https': f'http://{proxy_str}'
        }
        response = requests.get(
            'https://httpbin.org/ip',
            proxies=proxies,
            timeout=10
        )
        if response.status_code == 200:
            data = response.json()
            return True, data.get('origin', 'Unknown IP')
        return False, 'Bad Response'
    except requests.exceptions.ProxyError:
        return False, 'Proxy Authentication Failed'
    except requests.exceptions.ConnectTimeout:
        return False, 'Connection Timeout'
    except requests.exceptions.ConnectionError:
        return False, 'Connection Error'
    except Exception as e:
        return False, str(e)[:50]

def add_proxy(proxy_str):
    proxies = load_proxies()
    if proxy_str in proxies:
        return False, 'Proxy already exists'
    
    success, result = test_proxy(proxy_str)
    if not success:
        return False, f'Proxy test failed: {result}'
    
    proxies.append(proxy_str)
    save_proxies(proxies)
    return True, result

def remove_proxy(proxy_str):
    proxies = load_proxies()
    if proxy_str in proxies:
        proxies.remove(proxy_str)
        save_proxies(proxies)
        return True
    return False

def clear_proxies():
    save_proxies([])
    return True

def get_random_proxy():
    proxies = load_proxies()
    if proxies:
        return random.choice(proxies)
    return None

def get_proxy_dict():
    proxy = get_random_proxy()
    if proxy:
        return {
            'http': f'http://{proxy}',
            'https': f'http://{proxy}'
        }
    return None

def get_all_proxies():
    return load_proxies()

def proxy_count():
    return len(load_proxies())
