<?php
echo 'FUK OFF';
?>