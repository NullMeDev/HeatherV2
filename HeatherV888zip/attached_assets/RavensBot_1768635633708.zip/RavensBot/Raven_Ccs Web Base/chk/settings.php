<?php

$channel = "test"; // user channel 
$group = "test"; // user group
$dm = "test"; // your user
$by = "test"; // your name or nickname
