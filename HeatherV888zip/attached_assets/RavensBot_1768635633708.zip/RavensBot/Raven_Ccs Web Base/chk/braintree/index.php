<?php
include "../settings.php";

$gate = "Braintree Auth";
?>
<!DOCTYPE html>
<html lang="en-gb" dir="ltr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Checker</title>
  <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../css/main.css" />
  <link rel="stylesheet" href="../css/hyper.css?v=6.2" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css" /> 
</head>
<body>

  
<?php
include("../header.php");
?>
	
<div id="hyper_progress"></div>
  <div class="uk-section uk-section-muted">
<div class="uk-container">
  <div class="uk-background-default uk-border-rounded uk-box-shadow-small">
<div class="uk-container uk-container-xsmall uk-padding-large">
  <article class="uk-article">
<center>
<div style='filter: invert(1); height: 70px; width: 70px; margin-top: -4px;margin-bottom: 40px;'><img src="../anonymousheader.svg"></div>
</center>
<div class="uk-article-content">
  <div class="uk-form-stacked uk-margin-medium-top">
<div class="uk-margin-bottom">
  <label class="uk-form-label" for="message"><span>Drop CC
      <span class="tag_required" id="lista_leb">Required</span></span>
    <span class="tag_total">Total <span id="totalCount">0</span></span>

    <span class="tag_info">Checked <span id="totalChecked">0</span></span>
  </label>
  <div class="uk-form-controls" id="lista_con">
    <textarea id="message" class="hyper_ccs uk-textarea uk-border-rounded" placeholder="XXXXXXXXXXXXX|XX|XXXX|XXX" name="lista" rows="5" minlength="10" required=""></textarea>
  </div>
</div>


   
  

<div class="row-col">
<div class="uk-margin-bottom" id="amount_container">
  <label class="uk-form-label" for="name">Telegram ID <span class="tag_optional">optional</span></label>
  <div class="uk-form-controls hyper_login">
    <input id="tg_id" class="hyper_input uk-input uk-border-rounded" name="name" type="text" placeholder="Telegram ID" required>
  </div>
</div>

<div class="uk-margin-bottom" id="amount_container">
  <label class="uk-form-label" for="name">Amount <span class="tag_optional">optional</span></label>
  <div class="uk-form-controls hyper_login">
    <input id="amount" class="hyper_input uk-input uk-border-rounded" name="number" type="text" placeholder="Enter Amount" required>
  </div>
</div>
</div>

<div class="row-col">
<div class="uk-margin-bottom" id="amount_container">
  <label class="uk-form-label" for="name">Forwarder<span class="tag_required">Types</span></label>
  <div class="uk-form-controls hyper_login">
    <select name="fwtype" id="fwtype">
      <option value="hits"><?php echo $gate; ?></option>
    </select>
  </div>
</div>

<div class="uk-margin-bottom" id="amount_container">
  <label class="uk-form-label" for="name">Currency<span class="tag_required">Choose</span></label>
  <div class="uk-form-controls hyper_login">
    <select name="curr" id="curr">
      <option value="usd">USD</option>
    </select>
  </div>
</div>
</div>



<div class="uk-text-center">
<button class="uk-button uk-button-primary uk-border-rounded" id="startbtn" type="submit">start check</button>
<button class="uk-button uk-button-primary uk-border-rounded" id="stopbtn" type="submit"> Reload It</button>
</div>
</div>



<!-- LIVE -->
  <div class="uk-card card_cvv uk-card-category hyper_mt3 uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
<h3 class="uk-card-title uk-margin-remove uk-text-primary green_title">Approved - <span id="cvvCount">0</span>
<span id="showCvv">Show</span>
<span id="saveCvv">Save</span>
</h3>
<span id="cvvList">
</span>
</div>

<?php
/*
  <!-- ccn  -->
  <div class="uk-card ccn_card uk-card-category hyper_mt3 uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
<h3 class="uk-card-title uk-margin-remove uk-text-primary warn_title">CVV/CCN - <span id="ccnCount">0</span>
  <span id="showCcn">Show</span>
  <span id="saveCcn">Save</span>
</h3>
<span id="ccnList">
</span>
</div>
*/
?>

  <!-- dead  -->
  <div class="uk-card dead_card uk-card-category hyper_mt3 uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
<h3 class="uk-card-title uk-margin-remove uk-text-primary dead_title">Dead - <span id="deadCount">0</span>
  <span id="showDead">Show</span>
</h3>
<div id="deadList">
</div>

</div>
</div>
</article>
</div>
</div>
</div>
</div>

<?php
include("../footer.php");
?>

  <script src="../js/awesomplete.js"></script>
  <script src="../js/jquery.js"></script>
  <script src="../js/hyper.js?v=1.2"></script>
  <script src="../js/hyper.notify.js?v=1.2"></script>
  <script src="./checker.js"></script>
  <script src="../js/uikit.js"></script>

</body>
</html>